package Plugins::LibraryMapper::Data;

use strict;

use File::Basename qw(dirname);
use File::Spec;

use DBI;

use Slim::Utils::Log qw(logger logError logWarning);
use Slim::Utils::Prefs;
use Slim::Utils::OSDetect;

my $log = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

my $DBH;   # dedicated plugin database handle
my $SCAN_PID = 0;   # the process number of the scan that is running

# The names the tags use when an album carries no genre at all.  They are
# not genres: the group they make is hidden by default.

# The number of items a level shows when the user asks for "unlimited": the
# library holds far less than that, so every item of the level is shown.
use constant UNLIMITED => 1000000;

my @NO_GENRE = (
	'pas de genre', 'sans genre', 'no genre', 'none', 'unknown',
	'unknown genre', 'genre inconnu', 'inconnu', 'ohne genre',
	'nicht klassifiziert', 'sin genero', 'sem genero', 'geen genre',
);

# The mapping module needs the data module, so it cannot be loaded at the
# top here: it is loaded on demand instead.
sub _mapping { require Plugins::LibraryMapper::Mapping; return 1; }

# The sort order of the artists has no Lyrion dependency either.
sub _sortkey { require Plugins::LibraryMapper::SortKey; return 1; }

# Shared accessors used by Mapping.pm
sub dbh { return $DBH; }

# --------------------------------------------------------------- the encoding
#
# The whole plugin speaks UTF-8 bytes, exactly like Lyrion itself: the names
# of the artists, of the albums and of the genres are read from the index of
# the server as UTF-8 bytes and they are stored in the database of the plugin
# as those same bytes.
#
# This is not a choice of taste: the SQLite driver of the server writes a
# text that carries the UTF-8 flag as Latin-1 bytes ("é" would be written
# e9 instead of c3 a9), so a character string must never reach the database.
#
# The characters appear at two places only, and both of them are handled
# here:
#
#   - the links of the pages: the server escapes them with
#     uri_escape_utf8, which escapes a byte string twice ("Jules Billé"
#     would become "Jules%20Bill%C3%83%C2%A9") and a character string
#     once.  The template therefore decodes the name before it escapes
#     it: [% name | utf8on | uri %].
#   - the answers in JSON: JSON::XS writes a byte string as Latin-1, so
#     the text is decoded before it is encoded.
sub _bytes {
	my $s = shift;
	return $s unless defined $s;
	utf8::encode($s) if utf8::is_utf8($s);
	return $s;
}

sub _chars {
	my $s = shift;
	return $s unless defined $s;
	utf8::decode($s) unless utf8::is_utf8($s);
	return $s;
}

# A query on the index of Lyrion.  The text of the library comes back as
# UTF-8 bytes, which is what the plugin works with.
sub _lmsQuery {
	my ($dbh, $sql, $attr, @bind) = @_;
	my $rows = eval { $dbh->selectall_arrayref($sql, $attr, @bind) };
	return [] unless $rows;
	return $rows;
}

# The text of a whole structure, decoded: JSON::XS writes a byte string as
# Latin-1, which would show "Jules BillÃ©" in the browser.
sub _jsonChars {
	my ($data) = @_;
	if (ref $data eq 'HASH') {
		$data->{$_} = _jsonChars($data->{$_}) for keys %$data;
	}
	elsif (ref $data eq 'ARRAY') {
		$data->[$_] = _jsonChars($data->[$_]) for 0 .. $#$data;
	}
	elsif (!ref $data && defined $data) {
		return _chars($data);
	}
	return $data;
}

sub to_json {
	my ($data) = @_;
	if (!ref $data) {
		# diagnose instead of dying: log the caller and answer with a JSON error
		require Carp;
		logError("LibraryMapper to_json: non-ref argument '" . ($data // 'undef') . "'\n" . Carp::longmess());
		return '{"error": "librarymapper: to_json received non-ref argument (see server log)"}';
	}
	require JSON::XS;
	my $json = JSON::XS::encode_json(_jsonChars($data));
	# The answer of the server is often put into another answer (the JSON of
	# the skins, the answers of the command line).  JSON::XS writes a byte
	# string as Latin-1, so a byte string that is put into another answer is
	# written twice ("Jules Billé" becomes "Jules BillÃ©").  The answer is
	# therefore returned as characters: the one that writes it (the server,
	# the browser) turns them into UTF-8 bytes exactly once.
	utf8::decode($json);
	return $json;
}
sub from_json {
	my ($text) = @_;
	require JSON::XS;
	# JSON::XS wants octets: a text that carries the UTF-8 flag (the text of
	# a form field, for instance) is turned into its UTF-8 bytes first.
	utf8::encode($text) if utf8::is_utf8($text);
	return JSON::XS::decode_json($text);
}

# ---------------------------------------------------------------- persist dir

sub dbPath {
	my $dir = _persistDir();
	return File::Spec->catfile($dir, 'librarymapper.db');
}

# The plugin keeps its own files in a directory of the preferences folder of
# the server: that folder survives a restart of the server and is not wiped
# with the cache.
#
# (An earlier version asked the operating system for the preferences folder
# with OSDetect->dir('prefs'), which does not exist: the answer was empty and
# the fallback was /tmp, so the database was lost at every reboot.)
sub _persistDir {
	my $base = '';

	for my $dir (eval { Slim::Utils::OSDetect::dirsFor('prefs') } || ()) {
		next unless $dir && -d $dir;
		$base = $dir;
		last;
	}

	# the preferences folder of the server, when it is not the default one
	if (!$base && $::prefsdir && -d $::prefsdir) {
		$base = $::prefsdir;
	}

	# last resort: the folder the server was started from
	if (!$base && $main::Bin && -d File::Spec->catdir($main::Bin, 'prefs')) {
		$base = File::Spec->catdir($main::Bin, 'prefs');
	}

	$base = File::Spec->catdir($base, 'LibraryMapper');
	mkdir $base unless -d $base;
	$prefs->set('dataDir', $base);
	return $base;
}

# ----------------------------------------------------------------- schema

my $SCHEMA = <<'SQL';
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS genre_groups (
	id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE,
	sort_order INTEGER DEFAULT 0, is_default INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS genre_variants (
	variant TEXT PRIMARY KEY,            -- folded display form
	occurrences INTEGER NOT NULL DEFAULT 0,   -- albums referencing it
	proposed_group TEXT, approved TEXT DEFAULT '', approved_by TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS genre_proposals (
	variant TEXT NOT NULL, part TEXT NOT NULL, pos INTEGER NOT NULL,
	group_name TEXT, PRIMARY KEY (variant, pos));
CREATE TABLE IF NOT EXISTS artist_variants (
	variant TEXT PRIMARY KEY, canonical TEXT,
	occurrences INTEGER NOT NULL DEFAULT 0, approved TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS album_artists (
	album_id INTEGER NOT NULL,
	artist_raw TEXT NOT NULL,
	n INTEGER NOT NULL DEFAULT 1,
	PRIMARY KEY (album_id, artist_raw));
CREATE INDEX IF NOT EXISTS idx_aa_album ON album_artists(album_id);
CREATE TABLE IF NOT EXISTS album_artist_map (
	album_id INTEGER PRIMARY KEY,
	artist_raw TEXT,
	resolved TEXT,
	confidence REAL,
	source TEXT);
CREATE TABLE IF NOT EXISTS album_artist_list (
	album_id INTEGER NOT NULL,
	artist TEXT NOT NULL,          -- canonical artist name
	weight INTEGER NOT NULL DEFAULT 1,
	PRIMARY KEY (album_id, artist));
CREATE INDEX IF NOT EXISTS idx_aal_artist ON album_artist_list(artist);
CREATE TABLE IF NOT EXISTS trusted_artists (
	name TEXT PRIMARY KEY,         -- as typed by the user
	added_at INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS contributor_cache (
	contributor_id INTEGER NOT NULL,
	name TEXT NOT NULL,
	role INTEGER NOT NULL,         -- 1 artist, 2 composer, 3 conductor,
	albums INTEGER NOT NULL DEFAULT 0,   -- 4 band, 5 album artist, 6 track artist
	tracks INTEGER NOT NULL DEFAULT 0,
	PRIMARY KEY (contributor_id, role));
CREATE INDEX IF NOT EXISTS idx_cc_name ON contributor_cache(name);
CREATE INDEX IF NOT EXISTS idx_cc_role ON contributor_cache(role);
CREATE TABLE IF NOT EXISTS contributor_mappings (
	role INTEGER NOT NULL,        -- 1 artist, 2 composer, 3 conductor ...
	variant TEXT NOT NULL,         -- the name as written in the tags
	canonical TEXT NOT NULL,       -- the name the user wants to see
	updated_at INTEGER NOT NULL DEFAULT 0,
	PRIMARY KEY (role, variant));
CREATE TABLE IF NOT EXISTS query_results (
	nr INTEGER PRIMARY KEY,       -- the number to use as a reference
	name TEXT NOT NULL,
	role INTEGER NOT NULL DEFAULT 0,
	roles TEXT DEFAULT '',        -- every role of that name, comma separated
	albums INTEGER NOT NULL DEFAULT 0,
	tracks INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS albums_cache (
	album_id INTEGER PRIMARY KEY,
	name TEXT NOT NULL, artist_raw TEXT, genre_raw TEXT,
	year INTEGER, added INTEGER,       -- epoch seconds, from Lyrion index
	quality TEXT,                      -- hires | cd | lossy | unknown
	artwork_track_id INTEGER,          -- the track that carries the cover art
	vpath_genre TEXT, vpath_artist TEXT, vpath_album TEXT);
CREATE INDEX IF NOT EXISTS idx_ac_group ON albums_cache(vpath_genre);
CREATE INDEX IF NOT EXISTS idx_ac_artist ON albums_cache(vpath_artist);
CREATE INDEX IF NOT EXISTS idx_ac_added ON albums_cache(added);
CREATE TABLE IF NOT EXISTS tracks_cache (
	track_id INTEGER PRIMARY KEY,
	album_id INTEGER NOT NULL,
	title TEXT, tracknum INTEGER, disc INTEGER, quality TEXT, url TEXT);
CREATE INDEX IF NOT EXISTS idx_tc_album ON tracks_cache(album_id);
SQL

# the statements of the schema, one by one, and the table each one creates
my @STATEMENTS = split /;\n/, $SCHEMA;

my %TABLE_DDL;
for my $stmt (@STATEMENTS) {
	$TABLE_DDL{$1} = $stmt if $stmt =~ /CREATE TABLE IF NOT EXISTS\s+(\w+)/i;
}

sub init {
	my $path = dbPath();
	mkdir dirname($path) unless -d dirname($path);
	$DBH = _connectDb($path) or do {
		logError("LibraryMapper: cannot open dedicated db $path: $DBI::errstr");
		return;
	};
	for my $ddl (@STATEMENTS) {
		$DBH->do($ddl) or logError("LibraryMapper DDL failed: " . $DBI::errstr);
	}
	_migrate();
	# a rebuilt table took its indexes with it: they are created again here
	for my $ddl (@STATEMENTS) {
		$DBH->do($ddl) or logError("LibraryMapper DDL failed: " . $DBI::errstr);
	}
	$log->info("LibraryMapper dedicated database: $path");
}

# The connection to the database of the plugin.  The scan runs in another
# process and opens its own connection, so this is used by both.
#
# The pragmas are the ones that make the difference on a network volume: the
# write ahead log keeps the readers out of the way of the writer, and the
# "normal" synchronisation does not write the whole journal to the disk at
# every transaction (that was the reason why the scan took hours).
sub _connectDb {
	my ($path) = @_;
	my $dbh = DBI->connect("dbi:SQLite:dbname=$path", '', '', {
		AutoCommit => 1,
		sqlite_use_immediate_transaction => 1,
		PrintError => 0,
	}) or return undef;
	$dbh->do("PRAGMA journal_mode=WAL");
	eval { $dbh->do("PRAGMA synchronous=NORMAL"); };
	eval { $dbh->do("PRAGMA busy_timeout=20000"); };
	eval { $dbh->do("PRAGMA cache_size=-16000"); };
	return $dbh;
}

# A statement that is checked: a statement that could not be prepared is an
# error that is reported, not a crash of the scan.
sub _prep {
	my ($sql) = @_;
	my $sth = $DBH->prepare($sql);
	unless ($sth) {
		my $err = $DBI::errstr || 'unknown error';
		logError("LibraryMapper: the statement could not be prepared: $err");
		die "the statement could not be prepared: $err\n";
	}
	return $sth;
}

# The schema grew over the versions: a table that was created with fewer
# columns is rebuilt instead of being left as it is.  Every table of the
# schema is checked, not only the one that changed last time.
sub _migrate {
	for my $table (sort keys %TABLE_DDL) {
		my $cols = eval {
			$DBH->selectall_arrayref("PRAGMA table_info($table)", { Slice => {} });
		};
		next unless $cols && @$cols;

		my %have = map { $_->{'name'} => 1 } @$cols;
		my $want = _expectedColumns($TABLE_DDL{$table});
		my @missing = grep { !$have{$_} } @$want;
		next unless @missing;

		$log->info("LibraryMapper: the table $table is rebuilt (missing: @missing)");
		$DBH->do("DROP TABLE $table");
		$DBH->do($TABLE_DDL{$table});
	}
}

# the columns of a CREATE TABLE statement
sub _expectedColumns {
	my ($ddl) = @_;
	my @cols;
	my ($body) = $ddl =~ /\((.*)\)/s;
	return \@cols unless $body;
	for my $line (split /\n/, $body) {
		$line =~ s/^\s+//;
		next unless length $line;
		next if $line =~ /^(?:PRIMARY|UNIQUE|FOREIGN|CHECK|CONSTRAINT)\b/i;
		my ($c) = $line =~ /^(\w+)/;
		push @cols, $c if $c;
	}
	return \@cols;
}

# ------------------------------------------------------------ initialization

# Schema-sensitive probes: Lyrion internal table/column names vary between
# versions; we probe once and remember what worked in meta.
sub _probe {
	require Slim::Schema;
	my $dbh = Slim::Schema->storage->dbh;
	return $dbh;
}

sub _tryQueries {
	my ($dbh, @candidates) = @_;
	for my $sql (@candidates) {
		# no bind parameters are passed: the trailing 3 used here previously
		# made every probe fail with 'called with 1 bind variables'
		my $rows = eval { $dbh->selectall_arrayref($sql, { Slice => {} }) };
		return $rows if $rows;
	}
	return undef;
}

# ------------------------------------------------------------ the background scan
#
# The scan reads the index of the server and fills the caches of the plugin.
# It never writes a file of the library: it only reads the index.
#
# The scan runs in the background (in a child process of the server), so that
# the music server keeps answering while it works.  The page that started it
# shows its progress: the state of the scan is written in the meta table and
# read back by the page.

# Start the scan in the background.  The function answers at once: the scan
# works on its own and writes its progress in the database.
sub startScan {
	my (%opt) = @_;

	_reapChild();

	if (_scanRunning()) {
		# a scan is already working: the library changed again, the running
		# scan does a second round when it is done
		_metaSet('scanPending', 1);
		return 0;
	}

	# The path of the database of the server.  The child process opens its own
	# connection to it: a database connection cannot be shared between two
	# processes.
	my $lmsPath = eval {
		require Slim::Schema;
		Slim::Schema->storage->dbh->{'Database'};
	};

	_metaSet('scanPending', 0);
	_metaSet('scanError', '');
	_metaSet('scanStarted', time());
	_metaSet('scanFinished', '');
	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_START', 1);

	my $pid = fork();
	if (!defined $pid) {
		logError("LibraryMapper: the scan could not be started in the background");
		_progress('error', '', 0);
		return 0;
	}

	if ($pid == 0) {
		# --- the child process ---------------------------------------------
		$0 = 'librarymapper scan';
		_closeInheritedHandles();
		my $ok = eval {
			$DBH = _connectDb(dbPath())
				or die "the database of the plugin could not be opened\n";
			my $dbh = _lmsReadHandle($lmsPath);
			# a change that arrives while the scan runs is picked up by a
			# second round
			for (my $round = 1; $round <= 5; $round++) {
				my $stats = runInitialization(dbh => $dbh);
				die(($stats->{'error'} || 'unknown error') . "\n") unless $stats->{'ok'};
				last unless _metaGet('scanPending');
				_metaSet('scanPending', 0);
			}
			1;
		};
		unless ($ok) {
			logError("LibraryMapper: the background scan failed: $@");
			$DBH = _connectDb(dbPath()) if !$DBH;
			_metaSet('scanError', _cleanError($@));
			_progress('error', '', 0);
		}
		require POSIX;
		POSIX::_exit(0);
	}

	$SCAN_PID = $pid;
	_metaSet('scanPid', $pid);
	return 1;
}

# The library changed: a file was added or removed.  The tree is brought up to
# date in the background; the mapping of the user is not touched.
sub libraryChanged {
	return 0 unless $DBH;
	# there is nothing to update as long as the library was never scanned
	return 0 unless _metaGet('lastInit');
	if (_scanRunning()) {
		_metaSet('scanPending', 1);
		return 0;
	}
	return startScan();
}

# Is a scan running?  A scan whose process is gone (the server was stopped in
# the middle of it) is not running any more.
sub _scanRunning {
	my $state = _metaGet('scanState');
	return 0 unless $state eq 'running';
	my $pid = _metaGet('scanPid');
	if ($pid && $pid =~ /^\d+$/ && $pid > 1) {
		return 1 if kill(0, $pid);
		logWarning("LibraryMapper: the scan process $pid is gone");
		_metaSet('scanState', 'error');
		_metaSet('scanError', 'the scan process stopped');
		return 0;
	}
	return 1;
}

# The state of the scan, for the progress bar of the parameter page.
sub scanStatus {
	return { state => 'none', step => '', progress => 0 } unless $DBH;
	_reapChild();
	return {
		state    => (_metaGet('scanState') || 'none'),
		step     => _metaGet('scanStep'),
		progress => (_metaGet('scanProgress') || 0),
		started  => (_metaGet('scanStarted') || 0),
		finished => (_metaGet('scanFinished') || 0),
		error    => _metaGet('scanError'),
		pending  => (_metaGet('scanPending') || 0),
	};
}

# The progress of the scan, written in the database: the page reads it and
# shows the bar.  The step is the token of a string of the plugin.
sub _progress {
	my ($state, $step, $percent) = @_;
	_metaSet('scanState', $state);
	_metaSet('scanStep', $step) if defined $step;
	_metaSet('scanProgress', $percent) if defined $percent;
}

sub _metaSet {
	my ($key, $value) = @_;
	return unless $DBH;
	$value = '' unless defined $value;
	eval {
		$DBH->do('INSERT OR REPLACE INTO meta(key, value) VALUES (?,?)', undef, $key, $value);
		1;
	} or do { logWarning("LibraryMapper: the state '$key' could not be written: $@"); };
}

sub _metaGet {
	my ($key) = @_;
	return '' unless $DBH;
	my ($v) = eval { $DBH->selectrow_array('SELECT value FROM meta WHERE key=?', undef, $key) };
	return defined $v ? $v : '';
}

# The pages the server cached still show the tree of before the scan: they are
# wiped as soon as a new scan has finished.
sub _wipeIfNeeded {
	return unless $DBH;
	return unless _metaGet('scanDirty');
	_metaSet('scanDirty', 0);
	eval {
		require Slim::Web::XMLBrowser;
		Slim::Web::XMLBrowser->wipeCaches();
		1;
	} or logWarning("LibraryMapper: the cached pages could not be wiped: $@");
}

# The child process inherits everything the server had open: the connection of
# the web server among them.  It closes every descriptor it does not need (the
# log stays open), so that it cannot disturb the answer of the server.
sub _closeInheritedHandles {
	return unless -d '/proc/self/fd';
	opendir(my $dh, '/proc/self/fd') or return;
	my @fds = grep { /^\d+$/ } readdir($dh);
	closedir($dh);
	for my $fd (@fds) {
		next if $fd <= 2;
		close($fd);
	}
}

# The connection to the database of the server.  A connection cannot be shared
# between two processes, so the child opens its own one.
sub _lmsReadHandle {
	my ($path) = @_;
	if ($path && -f $path) {
		my $dbh = eval {
			DBI->connect("dbi:SQLite:dbname=$path", '', '', {
				AutoCommit => 1, RaiseError => 1, PrintError => 0,
			});
		};
		if ($dbh) {
			eval { $dbh->do('PRAGMA busy_timeout=30000'); };
			return $dbh;
		}
		logWarning("LibraryMapper: the database of the library could not be opened ($path): $@");
	}
	require Slim::Schema;
	return Slim::Schema->storage->dbh;
}

# The child process is waited for, so that it does not stay as a zombie.
sub _reapChild {
	return 0 unless $SCAN_PID;
	require POSIX;
	my $r = waitpid($SCAN_PID, POSIX::WNOHANG());
	$SCAN_PID = 0 if $r == $SCAN_PID || $r == -1;
	return $r;
}

sub _cleanError {
	my ($err) = @_;
	$err = '' unless defined $err;
	$err =~ s/\s+/ /g;
	return substr($err, 0, 300);
}

# Runs the initialization scan: reads Lyrion's own index and fills
# albums_cache + raw genre/artist variant lists. Query-only: no tag or file
# writes. Returns a stats hash for the parameter page.
#
# Everything is read first and written afterwards, in one single transaction:
# the tree of the server is never left half written, and the write costs one
# transaction instead of one per row (that was the reason why the scan took
# hours on a network volume).
sub runInitialization {
	my %opt = @_;
	my $stats = { started => time() };
	unless ($DBH) {
		$stats->{'ok'} = 0;
		$stats->{'error'} = 'database not initialised';
		return $stats;
	}
	my $dbh = $opt{'dbh'} || _probe();

	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_LIBRARY', 5);

	# --- probe joins once, remember which shapes worked (Lyrion 9.x: genre_track) --
	my ($gTab, $gJoinA, $gJoinB);
	for my $c (
		['genre_track',  q{SELECT genre, track FROM genre_track LIMIT 2},  'gt.genre = g.id',  'gt.track = t.id'],
		['genres_track', q{SELECT track_id, genre_id FROM genres_track LIMIT 2}, 'gt.genre_id = g.id', 'gt.track_id = t.id'],
		['track_genres', q{SELECT track_id, genre_id FROM track_genres LIMIT 2}, 'gt.genre_id = g.id', 'gt.track_id = t.id'],
	) {
		my ($label, $probeSql, $joinA, $joinB) = @$c;
		if (_tryQueries($dbh, $probeSql)) {
			($gTab, $gJoinA, $gJoinB) = ($label, $joinA, $joinB);
			last;
		}
	}
	$stats->{'genreJoin'} = $gTab || '';

	my $hasAdded = _tryQueries($dbh,
		q{SELECT id, added_time FROM tracks ORDER BY id DESC LIMIT 2},
		q{SELECT id, timestamp FROM tracks ORDER BY id DESC LIMIT 2});
	$stats->{'addedColumn'} = '';
	if ($hasAdded && ref $hasAdded->[0]) {
		$stats->{'addedColumn'} = exists $hasAdded->[0]{added_time} ? 'added_time' : 'timestamp';
	}

	# The cover art of an album hangs on one of its tracks: the albums table
	# of Lyrion carries the id of that track in its "artwork" column.  The
	# URL /music/<id>/cover only understands a track id (or a cover id), so
	# the album id cannot be used there.
	my $hasArtwork = _tryQueries($dbh, q{SELECT id, artwork FROM albums LIMIT 2});
	$stats->{'artworkColumn'} = '';
	if ($hasArtwork && ref $hasArtwork->[0] && exists $hasArtwork->[0]{'artwork'}) {
		$stats->{'artworkColumn'} = 'artwork';
	}

	# --- genres ------------------------------------------------------------
	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_GENRES', 15);
	my $genres = [];
	if ($gTab) {
		$genres = eval {
			_lmsQuery($dbh, qq{
				SELECT g.name, COUNT(DISTINCT t.album) AS albums
				FROM genres g
				JOIN $gTab gt ON $gJoinA
				JOIN tracks t ON $gJoinB
				GROUP BY g.name ORDER BY albums DESC}, { Slice => {} })
		};
		if (!$genres) { logError("LibraryMapper genres query failed: $@"); $genres = []; }
	}
	else {
		logWarning("LibraryMapper: no genre join table probed - genres skipped");
	}
	# the number of albums of every genre spelling, kept in memory: the rows
	# are written in one go at the end of the scan
	my %genreOcc;
	for my $g (@$genres) {
		my $variant = _fold($g->{name});
		next if $variant eq '';
		$genreOcc{$variant} = $g->{albums} || 0;
	}
	$stats->{'genreVariants'} = scalar keys %genreOcc;

	# --- artists -----------------------------------------------------------
	# Lyrion 9.x: track <-> contributor links live in contributor_track
	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_ARTISTS', 25);
	my $artists = eval {
		_lmsQuery($dbh, qq{
			SELECT c.name, COUNT(DISTINCT t.album) AS albums
			FROM contributors c
			JOIN contributor_track ct ON ct.contributor = c.id
			JOIN tracks t ON t.id = ct.track
			WHERE ct.role IN (1,5,6)
			GROUP BY c.name ORDER BY albums DESC}, { Slice => {} })
	};
	if (!$artists) { logError("LibraryMapper artists query failed: $@"); $artists = []; }
	my $style = $prefs->get('artistNameStyle') || 'firstlast';
	my %artistOcc;
	my %artistCanon;
	for my $a (@$artists) {
		my $variant = _fold($a->{name});
		next if $variant eq '';
		$artistOcc{$variant} = $a->{albums} || 0;
		$artistCanon{$variant} =
			Plugins::LibraryMapper::Mapping::normalizeArtistName($a->{name}, $style);
	}
	$stats->{'artistVariants'} = scalar keys %artistOcc;

	# --- albums cache (artist/genre/year/added/quality) ---------------------
	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_ALBUMS', 35);
	my $addedExpr = $stats->{'addedColumn'} ? "t.$stats->{addedColumn}" : 'NULL';
	my $artworkExpr = $stats->{'artworkColumn'} ? 'MAX(me.artwork)' : 'NULL';
	my $albums = eval {
		_lmsQuery($dbh, qq{
			SELECT me.id, me.title, me.year, c.name AS artist,
			       MAX($addedExpr) AS added,
			       $artworkExpr AS artwork,
			       MAX(t.samplerate) AS sr, MAX(t.lossless) AS lossless, MAX(t.bitrate) AS br
			FROM albums me
			JOIN tracks t ON t.album = me.id
			LEFT JOIN contributors c ON c.id = me.contributor
			GROUP BY me.id, me.title, me.year, artist}, { Slice => {} })
	};
	if (!$albums) { logError("LibraryMapper albums query failed: $@"); $albums = []; }
	$stats->{'albums'} = scalar @$albums;

	my $albumGenre = [];
	if ($gTab) {
		$albumGenre = eval {
			_lmsQuery($dbh, qq{
				SELECT t.album, g.name, COUNT(*) AS c
				FROM tracks t
				JOIN $gTab gt ON $gJoinB
				JOIN genres g ON $gJoinA
				GROUP BY t.album, g.name}, { Slice => {} })
		};
		if (!$albumGenre) { logError("LibraryMapper albumGenre query failed: $@"); $albumGenre = []; }
	}
	my %ag;
	for my $r (@$albumGenre) {
		push @{ $ag{ $r->{album} } ||= [] }, [ $r->{name}, $r->{c} ];
	}

	# --- album artists: one canonical name per album ------------------------
	my $artistRows = _albumArtistRows($dbh);
	my $resolution = Plugins::LibraryMapper::Mapping::resolveAlbumArtists(
		$artistRows, $prefs->get('artistNameStyle') || 'firstlast', trustedNames());
	$stats->{'albumArtistRows'} = scalar @$artistRows;
	$stats->{'albumsResolved'} = scalar keys %$resolution;

	# --- artist variants: raw spelling -> canonical "First Last" ------------
	{
		my %perVariant;
		for my $r (@$artistRows) {
			my $norm = Plugins::LibraryMapper::Mapping::normalizeArtistName(
				$r->{name}, $prefs->get('artistNameStyle') || 'firstlast');
			next unless $norm;
			my $key = _fold($r->{name});
			$perVariant{$key}{canonical} = $norm;
			$perVariant{$key}{albums}{$r->{album}} = 1;
		}
		for my $key (keys %perVariant) {
			$artistOcc{$key} = scalar keys %{ $perVariant{$key}{albums} };
			$artistCanon{$key} = $perVariant{$key}{canonical};
		}
	}
	$stats->{'artistVariants'} = scalar keys %artistOcc;

	# --- contributor cache: artists, composers, conductors -------------------
	# Every contributor of the library with the roles it is credited with.
	# This is what the regex search runs on.
	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_CONTRIBUTORS', 45);
	my %agg;
	{
		my $ct = eval {
			_lmsQuery($dbh, qq{
				SELECT ct.contributor AS cid, c.name AS name, ct.role AS role,
				       COUNT(DISTINCT t.album) AS albums, COUNT(*) AS tracks
				FROM contributor_track ct
				JOIN tracks t ON t.id = ct.track
				JOIN contributors c ON c.id = ct.contributor
				GROUP BY ct.contributor, ct.role}, { Slice => {} })
		};
		if (!$ct) { logError("LibraryMapper contributor_track query failed: $@"); $ct = []; }
		my $ca = eval {
			$dbh->selectall_arrayref(qq{
				SELECT ca.contributor AS cid, c.name AS name, ca.role AS role,
				       COUNT(DISTINCT ca.album) AS albums, 0 AS tracks
				FROM contributor_album ca
				JOIN contributors c ON c.id = ca.contributor
				GROUP BY ca.contributor, ca.role}, { Slice => {} })
		};
		if (!$ca) { logError("LibraryMapper contributor_album query failed: $@"); $ca = []; }

		for my $r (@$ct, @$ca) {
			next unless defined $r->{'cid'} && defined $r->{'name'};
			my $key = $r->{'cid'} . ':' . $r->{'role'};
			my $e = $agg{$key} ||= {
				cid => $r->{'cid'}, name => $r->{'name'},
				role => $r->{'role'}, albums => 0, tracks => 0 };
			$e->{'albums'} += $r->{'albums'} || 0;
			$e->{'tracks'} += $r->{'tracks'} || 0;
		}
		$stats->{'contributors'} = scalar keys %agg;
	}

	# the number of tracks, for the progress bar
	my $trackCount = 0;
	{
		my $c = eval { $dbh->selectrow_array('SELECT COUNT(*) FROM tracks') };
		$trackCount = $c if $c;
	}

	# --- write everything, in one single transaction ------------------------
	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_TREE', 55);
	my $written = eval {
		$DBH->begin_work;

		# the caches are rebuilt from scratch: an album that left the library
		# must not stay in the list
		$DBH->do('DELETE FROM album_artists');
		$DBH->do('DELETE FROM album_artist_map');
		$DBH->do('DELETE FROM album_artist_list');
		$DBH->do('DELETE FROM albums_cache');
		$DBH->do('DELETE FROM tracks_cache');
		$DBH->do('DELETE FROM contributor_cache');

		# the genre spellings: the count is refreshed, the group the user
		# chose for them is kept.  These rows come first: the proposals of
		# the groups are computed from them, and the path of the albums is
		# built from the proposals.
		my $upGenre = _prep('UPDATE genre_variants SET occurrences=? WHERE variant=?');
		my $inGenre = _prep('INSERT INTO genre_variants(variant, occurrences) VALUES (?,?)');
		for my $variant (keys %genreOcc) {
			my $n = $upGenre->execute($genreOcc{$variant}, $variant);
			$inGenre->execute($variant, $genreOcc{$variant})
				if !$n || $n eq '0' || $n eq '0E0';
		}
		$upGenre->finish;
		$inGenre->finish;

		# the artist spellings: the correction of the user is never overwritten
		my $upArtist = _prep(
			'UPDATE artist_variants SET occurrences=?, canonical=CASE WHEN approved<>"" THEN approved ELSE ? END WHERE variant=?');
		my $inArtist = _prep(
			'INSERT INTO artist_variants(variant, canonical, occurrences, approved) VALUES (?,?,?,?)');
		for my $variant (keys %artistOcc) {
			my $canonical = $artistCanon{$variant};
			$canonical = '' unless defined $canonical;
			my $n = $upArtist->execute($artistOcc{$variant}, $canonical, $variant);
			$inArtist->execute($variant, $canonical, $artistOcc{$variant}, '')
				if !$n || $n eq '0' || $n eq '0E0';
		}
		$upArtist->finish;
		$inArtist->finish;

		# the proposals of the groups: the keyword rules of the plugin are
		# applied to the spellings that the user has not decided about yet.
		# The work joins the transaction: it is written with the rest.
		Plugins::LibraryMapper::Mapping::repropose();

		my $insAa = _prep(
			'INSERT OR REPLACE INTO album_artists(album_id, artist_raw, n) VALUES (?,?,?)');
		for my $r (@$artistRows) {
			$insAa->execute($r->{album}, $r->{name}, $r->{n});
		}
		$insAa->finish;

		my $insAlbum = _prep(
			'INSERT OR REPLACE INTO albums_cache(album_id, name, artist_raw, genre_raw, year, added, quality, artwork_track_id, vpath_genre, vpath_artist, vpath_album) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
		my $insMap = _prep(
			'INSERT OR REPLACE INTO album_artist_map(album_id, artist_raw, resolved, confidence, source) VALUES (?,?,?,?,?)');
		my $insList = _prep(
			'INSERT OR REPLACE INTO album_artist_list(album_id, artist, weight) VALUES (?,?,?)');

		for my $a (@$albums) {
			my $g = $ag{ $a->{id} };
			my $genreRaw = $g ? _majority($g) : '';
			my $quality = _quality($a);
			my $res = $resolution->{ $a->{id} };
			my $artist = $res ? $res->{artist} : ($a->{artist} // '');
			my $vPath = _virtualPath($a, $genreRaw, $artist);
			$insAlbum->execute($a->{id}, $a->{title}, ($artist // ''),
				($genreRaw ? $genreRaw->[0] : ''),
				$a->{year} || 0, $a->{added} || 0, $quality, $a->{artwork} || 0,
				$vPath->[0], $vPath->[1], $vPath->[2]);
			if ($res) {
				$insMap->execute($a->{id}, $res->{raw}, $res->{artist}, $res->{confidence}, 'auto');
				# every artist the album belongs to (a collaboration shows up
				# under each of its artists)
				for my $ar (@{ $res->{'artists'} || [] }) {
					$insList->execute($a->{id}, $ar->{name}, $ar->{weight});
				}
			}
			else {
				$insList->execute($a->{id}, ($artist || 'Unknown artist'), 1);
			}
		}
		$insAlbum->finish;
		$insMap->finish;
		$insList->finish;

		# the contributors
		my $insContrib = _prep(
			'INSERT OR REPLACE INTO contributor_cache(contributor_id, name, role, albums, tracks) VALUES (?,?,?,?,?)');
		for my $e (values %agg) {
			$insContrib->execute($e->{'cid'}, $e->{'name'}, $e->{'role'},
				$e->{'albums'}, $e->{'tracks'});
		}
		$insContrib->finish;

		# the tracks, read one by one: a library of hundreds of thousands of
		# tracks must not be loaded in memory at once
		my $insTrack = _prep(
			'INSERT OR REPLACE INTO tracks_cache(track_id, album_id, title, tracknum, disc, quality, url) VALUES (?,?,?,?,?,?,?)');
		my $sth = $dbh->prepare(qq{
			SELECT id, title, CAST(tracknum AS INTEGER) AS tracknum,
			       CAST(disc AS INTEGER) AS disc, album AS album_id,
			       samplerate AS sr, lossless AS lossless, bitrate AS br, url
			FROM tracks});
		$sth->execute;
		my $n = 0;
		while (my $t = $sth->fetchrow_hashref) {
			$insTrack->execute($t->{'id'}, $t->{'album_id'}, $t->{'title'},
				$t->{'tracknum'}, $t->{'disc'}, _quality($t), $t->{'url'});
			$n++;
			if ($n % 5000 == 0) {
				my $pct = $trackCount ? int(55 + 40 * $n / $trackCount) : 95;
				_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_TRACKS', $pct);
			}
		}
		$sth->finish;
		$insTrack->finish;
		$stats->{'tracks'} = $n;

		# the cover art of the albums that have none of their own: the URL
		# /music/<id>/cover needs a track id, an album without an artwork of
		# its own takes the first of its tracks
		$DBH->do(qq{
			UPDATE albums_cache SET artwork_track_id =
				(SELECT MIN(track_id) FROM tracks_cache WHERE album_id = albums_cache.album_id)
			WHERE (artwork_track_id IS NULL OR artwork_track_id = 0)});

		1;
	};

	unless ($written) {
		my $err = _cleanError($@);
		eval { $DBH->rollback; };
		logError("LibraryMapper: the scan could not be written: $err");
		$stats->{'ok'} = 0;
		$stats->{'error'} = $err;
		_metaSet('scanError', $err);
		_progress('error', '', 0);
		return $stats;
	}
	$DBH->commit;

	_metaSet('lastInit', time());
	_metaSet('scanFinished', time());
	# the pages the server cached still show the tree of before the scan
	_metaSet('scanDirty', 1);
	_progress('done', 'PLUGIN_LIBRARYMAPPER_S_PHASE_DONE', 100);
	$stats->{'duration'} = time() - $stats->{'started'};
	$stats->{'ok'} = 1;
	return $stats;
}
sub _albumArtistRows {
	my ($dbh) = @_;
	my @rows;

	my $albumArtists = eval {
		_lmsQuery($dbh, qq{
			SELECT ca.album AS album, c.name AS name, COUNT(*) AS n
			FROM contributor_album ca
			JOIN contributors c ON c.id = ca.contributor
			WHERE ca.role = 5
			GROUP BY ca.album, c.name}, { Slice => {} })
	};
	if ($albumArtists && @$albumArtists) {
		for my $r (@$albumArtists) {
			push @rows, { album => $r->{album}, name => $r->{name}, n => 10 * ($r->{n} || 1) };
		}
	}
	else {
		logWarning("LibraryMapper: no contributor_album rows - falling back to track artists");
	}

	my $trackArtists = eval {
		_lmsQuery($dbh, qq{
			SELECT t.album AS album, c.name AS name, COUNT(*) AS n
			FROM tracks t
			JOIN contributor_track ct ON ct.track = t.id
			JOIN contributors c ON c.id = ct.contributor
			WHERE ct.role IN (1,5)
			GROUP BY t.album, c.name}, { Slice => {} })
	};
	if ($trackArtists && @$trackArtists) {
		for my $r (@$trackArtists) {
			push @rows, { album => $r->{album}, name => $r->{name}, n => ($r->{n} || 1) };
		}
	}
	return \@rows;
}

sub _fold { my $s = shift; return '' unless defined $s; $s =~ s/^\s+|\s+$//g; return lc $s; }

# Upsert one artist spelling.  The "approved" column (a user correction made
# on the parameter page) is never overwritten by a re-run of the scan.
sub _setGenreVariant {
	my ($variant, $occurrences) = @_;
	return 0 unless defined $variant && $variant ne '';
	# the count is refreshed, but the approval of the user is kept
	my $n = $DBH->do('UPDATE genre_variants SET occurrences=? WHERE variant=?',
		undef, $occurrences, $variant);
	return 1 if $n && $n ne '0' && $n ne '0E0';
	$DBH->do('INSERT INTO genre_variants(variant, occurrences) VALUES (?,?)',
		undef, $variant, $occurrences);
	return 1;
}
sub _setArtistVariant {
	my ($variant, $canonical, $occurrences) = @_;
	return 0 unless defined $variant && $variant ne '';
	my $n = $DBH->do('UPDATE artist_variants SET canonical=?, occurrences=? WHERE variant=?',
		undef, $canonical, $occurrences, $variant);
	return 1 if $n && $n ne '0' && $n ne '0E0';
	$DBH->do('INSERT INTO artist_variants(variant, canonical, occurrences, approved) VALUES (?,?,?,?)',
		undef, $variant, $canonical, $occurrences, '');
	return 1;
}
sub _majority {
	my $list = shift;
	my @sorted = sort { $b->[1] <=> $a->[1] } @$list;
	return $sorted[0];
}
sub _quality {
	my $a = shift;
	return 'lossy'  if defined $a->{'lossless'} && !$a->{'lossless'};
	return 'hires'  if $a->{'sr'} && $a->{'sr'} > 48400;
	return 'cd'     if $a->{'sr'} && $a->{'sr'} > 40000;
	return 'unknown';
}
sub _virtualPath {
	my ($a, $genreRaw, $artistRaw) = @_;
	my $group   = Plugins::LibraryMapper::Mapping::mappedGroup($genreRaw ? $genreRaw->[0] : '') // 'Unsorted';
	my $artist  = $artistRaw || 'Unknown artist';
	my $year    = $a->{'year'} || '????';
	return [ $group, $artist, "$year - $a->{'title'}" ];
}

# ------------------------------------------------------------------ queries

sub status {
	my ($out) = @_;
	return { error => 'database not initialised', albums => 0 } unless $DBH;
	_wipeIfNeeded();
	my ($lastInit) = $DBH->selectrow_array("SELECT value FROM meta WHERE key='lastInit'");
	$out = {
		dbPath    => dbPath(),
		lastInit  => $lastInit || 0,
		lastInitText => $lastInit ? scalar(localtime($lastInit)) : '',
		albums    => $DBH->selectrow_array('SELECT COUNT(*) FROM albums_cache'),
		genreVariants => $DBH->selectrow_array('SELECT COUNT(*) FROM genre_variants'),
		groups    => $DBH->selectrow_array('SELECT COUNT(*) FROM genre_groups'),
		mapped    => $DBH->selectrow_array('SELECT COUNT(*) FROM genre_variants WHERE approved<>""'),
		artistVariants => $DBH->selectrow_array('SELECT COUNT(*) FROM artist_variants'),
		artistMapped  => $DBH->selectrow_array('SELECT COUNT(*) FROM artist_variants WHERE approved<>""'),
		albumsResolved => $DBH->selectrow_array('SELECT COUNT(*) FROM album_artist_map'),
		artistLinks    => $DBH->selectrow_array('SELECT COUNT(*) FROM album_artist_list'),
		collaborations => $DBH->selectrow_array(
			'SELECT COUNT(*) FROM (SELECT album_id FROM album_artist_list GROUP BY album_id HAVING COUNT(*) > 1)'),
		trusted    => $DBH->selectrow_array('SELECT COUNT(*) FROM trusted_artists'),
		contributors => $DBH->selectrow_array('SELECT COUNT(DISTINCT name) FROM contributor_cache'),
	};
	# the state of the background scan
	my $scan = scanStatus();
	$out->{'scanState'}    = $scan->{'state'};
	$out->{'scanStep'}     = $scan->{'step'};
	$out->{'scanProgress'} = $scan->{'progress'};
	$out->{'scanError'}    = $scan->{'error'};
	$out->{'scanStarted'}  = $scan->{'started'};
	$out->{'scanFinished'} = $scan->{'finished'};
	return $out;
}

sub getGenreGroups {
	return [] unless $DBH;
	return $DBH->selectall_arrayref('SELECT id, name, sort_order, is_default FROM genre_groups ORDER BY sort_order, name', { Slice => {} });
}

sub topVariants {
	my $n = shift || 25;
	return [] unless $DBH;
	return $DBH->selectall_arrayref('SELECT variant, occurrences, proposed_group, approved FROM genre_variants ORDER BY occurrences DESC LIMIT ?', { Slice => {} }, $n );
}

sub topArtistVariants {
	my $n = shift || 25;
	return [] unless $DBH;
	return $DBH->selectall_arrayref(
		'SELECT variant, CASE WHEN approved<>"" THEN approved ELSE canonical END AS canonical,
		        occurrences, approved
		 FROM artist_variants ORDER BY occurrences DESC LIMIT ?',
		{ Slice => {} }, $n );
}

# Albums that are credited to more than one artist (a collaboration) or that
# carry several spellings of the same artist: the report of albums that could
# show up twice in the tree.
sub ambiguousAlbums {
	my $n = shift || 25;
	return [] unless $DBH;
	return $DBH->selectall_arrayref(qq{
		SELECT m.album_id, a.name AS album, m.resolved, m.confidence,
		       (SELECT COUNT(*) FROM album_artist_list l WHERE l.album_id = m.album_id) AS artists,
		       (SELECT COUNT(*) FROM album_artists aa WHERE aa.album_id = m.album_id) AS spellings,
		       (SELECT GROUP_CONCAT(l2.artist) FROM album_artist_list l2 WHERE l2.album_id = m.album_id) AS artist_list
		FROM album_artist_map m
		JOIN albums_cache a ON a.album_id = m.album_id
		WHERE artists > 1 OR spellings > 1
		ORDER BY artists DESC, spellings DESC, m.album_id LIMIT ?}, { Slice => {} }, $n );
}

# Approve (or clear) the canonical name of one artist spelling.  The row is
# created when it does not exist yet: a composer or a conductor may have no
# spelling row at all.
sub setArtistCanonical {
	my ($variant, $canonical) = @_;
	return 0 unless $DBH;
	return 0 unless defined $variant && $variant ne '';
	# the name comes from the page: it is turned into UTF-8 bytes, because
	# that is what the database speaks
	$variant = _bytes($variant);
	$canonical = '' unless defined $canonical;
	$canonical = _bytes($canonical);
	my $n = $DBH->do('UPDATE artist_variants SET approved=? WHERE variant=?',
		undef, $canonical, $variant);
	return 1 if $n && $n ne '0' && $n ne '0E0';
	$DBH->do('INSERT INTO artist_variants(variant, canonical, occurrences, approved) VALUES (?,?,?,?)',
		undef, $variant, '', 0, $canonical);
	return 1;
}

# ------------------------------------------------------- trusted artists
#
# A trusted name is an artist that is always ONE artist: the credit is never
# split and the albums credited to it are filed under it alone.  The user
# uploads the list of those names on the parameter page.

# The trusted names, with the number of albums currently filed under them.
sub trustedArtists {
	return [] unless $DBH;
	return $DBH->selectall_arrayref(qq{
		SELECT t.name AS name, t.added_at AS added_at,
		       (SELECT COUNT(*) FROM album_artist_list l WHERE l.artist = t.name) AS albums
		FROM trusted_artists t ORDER BY t.name}, { Slice => {} });
}

# The trusted names only (used by the artist resolution).
sub trustedNames {
	return [] unless $DBH;
	my $rows = $DBH->selectcol_arrayref('SELECT name FROM trusted_artists ORDER BY name');
	return $rows || [];
}

# Add names to the trusted list.  With $replace the whole list is replaced.
sub addTrustedArtists {
	my ($names, $replace) = @_;
	return 0 unless $DBH;
	my @clean;
	my %seen;
	for my $n (@{ $names || [] }) {
		next unless defined $n;
		$n = _bytes($n);
		$n =~ s/^\s+|\s+$//g;
		next unless $n ne '';
		next if $seen{lc $n}++;
		push @clean, $n;
	}
	return 0 unless @clean;
	$DBH->do('DELETE FROM trusted_artists') if $replace;
	my $ins = $DBH->prepare('INSERT OR REPLACE INTO trusted_artists(name, added_at) VALUES (?,?)');
	$DBH->begin_work;
	for my $n (@clean) { $ins->execute($n, time()); }
	$DBH->commit;
	$ins->finish;
	return scalar @clean;
}

# Remove one name from the trusted list.
sub removeTrustedArtist {
	my ($name) = @_;
	return 0 unless $DBH;
	return 0 unless defined $name && $name ne '';
	$DBH->do('DELETE FROM trusted_artists WHERE name=?', undef, _bytes($name));
	return 1;
}

# Re-resolve the album artists from the cached raw credits.  No Lyrion access
# is needed, so this runs in a second: it is used after the trusted list or
# the artist corrections changed.  Returns the number of albums resolved.
sub reresolveArtists {
	return 0 unless $DBH;
	my $rows = $DBH->selectall_arrayref(
		'SELECT album_id AS album, artist_raw AS name, n FROM album_artists', { Slice => {} });
	return 0 unless $rows && @$rows;

	my $style = $prefs->get('artistNameStyle') || 'firstlast';
	my $res = Plugins::LibraryMapper::Mapping::resolveAlbumArtists(
		$rows, $style, trustedNames());

	$DBH->begin_work;
	$DBH->do('DELETE FROM album_artist_list');
	my $upArt = $DBH->prepare('UPDATE album_artist_map SET resolved=?, confidence=? WHERE album_id=?');
	my $upAlb = $DBH->prepare('UPDATE albums_cache SET artist_raw=?, vpath_artist=? WHERE album_id=?');
	for my $a (@$rows) {
		my $r = $res->{ $a->{'album'} };
		next unless $r;
		for my $ar (@{ $r->{'artists'} || [] }) {
			$DBH->do('INSERT OR REPLACE INTO album_artist_list(album_id, artist, weight) VALUES (?,?,?)',
				undef, $a->{'album'}, $ar->{'name'}, $ar->{'weight'});
		}
		$upArt->execute($r->{'artist'}, $r->{'confidence'}, $a->{'album'});
		$upAlb->execute($r->{'artist'}, $r->{'artist'}, $a->{'album'});
	}
	$upArt->finish;
	$upAlb->finish;
	# albums without any artist credit keep their "Unknown artist" entry
	$DBH->do(qq{
		INSERT OR IGNORE INTO album_artist_list(album_id, artist, weight)
		SELECT a.album_id, 'Unknown artist', 1
		FROM albums_cache a
		WHERE NOT EXISTS (SELECT 1 FROM album_artist_list l WHERE l.album_id = a.album_id)});
	$DBH->commit;
	return scalar keys %$res;
}

# Re-resolve the genre group of every album from the mapping that is in the
# database now.  The raw genre of the album is cached, so no Lyrion access is
# needed: the tree can be rebuilt in a second, without a new scan.
# Returns the number of albums that were re-resolved.
sub reresolveGenres {
	return 0 unless $DBH;
	my $rows = $DBH->selectall_arrayref(
		'SELECT album_id, genre_raw, name, year FROM albums_cache', { Slice => {} });
	return 0 unless $rows && @$rows;

	# one query per genre, not per album
	my %group;
	my $changed = 0;
	$DBH->begin_work;
	my $up = $DBH->prepare(
		'UPDATE albums_cache SET vpath_genre=?, vpath_album=? WHERE album_id=?');
	for my $r (@$rows) {
		my $raw = $r->{'genre_raw'};
		$raw = '' unless defined $raw;
		if (!exists $group{$raw}) {
			$group{$raw} = Plugins::LibraryMapper::Mapping::mappedGroup($raw) || 'Unsorted';
		}
		my $year  = $r->{'year'} || '????';
		my $album = "$year - " . ($r->{'name'} // '');
		$up->execute($group{$raw}, $album, $r->{'album_id'});
		$changed++;
	}
	$up->finish;
	$DBH->commit;
	return $changed;
}

# Apply the mapping that is in the database now to the tree and let the server
# forget the pages it cached: the new mapping is visible at once, the server
# does not have to be restarted.
sub refreshTree {
	return 0 unless $DBH;
	my $n = reresolveGenres();
	reresolveArtists();

	# the classic web pages are cached by the server: they would still show
	# the tree of before the mapping
	eval {
		require Slim::Web::XMLBrowser;
		Slim::Web::XMLBrowser->wipeCaches() if Slim::Web::XMLBrowser->can('wipeCaches');
		1;
	} or do { logWarning("LibraryMapper: the web page cache could not be wiped: $@"); };

	return $n;
}

# ------------------------------------------------------------------ search
#
# A regex search over the contributors of the library (artists, composers,
# conductors).  The result is an ordered and numbered list: the number is the
# reference the user can use to apply a mapping to that row later on.

my %ROLE_TOKEN = (
	1 => 'PLUGIN_LIBRARYMAPPER_ROLE_ARTIST',
	2 => 'PLUGIN_LIBRARYMAPPER_ROLE_COMPOSER',
	3 => 'PLUGIN_LIBRARYMAPPER_ROLE_CONDUCTOR',
	4 => 'PLUGIN_LIBRARYMAPPER_ROLE_BAND',
	5 => 'PLUGIN_LIBRARYMAPPER_ROLE_ALBUMARTIST',
	6 => 'PLUGIN_LIBRARYMAPPER_ROLE_TRACKARTIST',
);

# the string token of a role number ('' for an unknown role)
sub roleToken { my $r = shift || 0; return $ROLE_TOKEN{ 0 + $r } || ''; }

# The names of the roles the search can filter on.
sub searchRoles {
	return [
		{ value => 'all', token => 'PLUGIN_LIBRARYMAPPER_S_ALLROLES' },
		{ value => 1, token => $ROLE_TOKEN{1} },
		{ value => 2, token => $ROLE_TOKEN{2} },
		{ value => 3, token => $ROLE_TOKEN{3} },
		{ value => 4, token => $ROLE_TOKEN{4} },
		{ value => 5, token => $ROLE_TOKEN{5} },
		{ value => 6, token => $ROLE_TOKEN{6} },
	];
}

# Search the contributors.
#   $pattern : a Perl regular expression
#   $roles   : 'all' or a role number (1 artist, 2 composer, 3 conductor ...)
#   $opts    : { caseSensitive => 0|1 }
# Returns { rows => [ { nr, name, role, roleTokens, albums, tracks, mapping } ],
#           count, pattern, error }
sub queryContributors {
	my ($pattern, $roles, $opts) = @_;
	$opts ||= {};
	return { error => 'database not initialised', rows => [], count => 0 } unless $DBH;

	$pattern = '' unless defined $pattern;
	# the names of the database are UTF-8 bytes: the pattern is turned into
	# bytes as well, so that both speak the same language
	$pattern = _bytes($pattern);
	$pattern =~ s/^\s+|\s+$//g;
	return { error => 'no pattern', rows => [], count => 0 } if $pattern eq '';

	# the pattern is a regular expression; the match ignores the case unless
	# the page asks for a case sensitive search
	my $re = $opts->{'caseSensitive'}
		? eval { qr/$pattern/ }
		: eval { qr/$pattern/i };
	if (!$re) {
		logError("LibraryMapper search: invalid regular expression '$pattern'");
		return { error => 'invalid regular expression', rows => [], count => 0, pattern => $pattern };
	}

	# the role filter
	my %want;
	if (defined $roles && $roles ne '' && lc $roles ne 'all' && $roles ne '0') {
		for my $r ($roles =~ /(\d+)/g) { $want{0 + $r} = 1; }
	}

	my $rows = $DBH->selectall_arrayref(
		'SELECT name, role, albums, tracks FROM contributor_cache', { Slice => {} }) || [];

	my %byName;
	for my $r (@$rows) {
		next unless defined $r->{'name'} && $r->{'name'} ne '';
		next if %want && !$want{ $r->{'role'} };
		next unless $r->{'name'} =~ $re;
		my $e = $byName{ $r->{'name'} };
		if (!$e) {
			$e = $byName{ $r->{'name'} } = {
				name => $r->{'name'}, role => $r->{'role'},
				albums => 0, tracks => 0, roles => {} };
		}
		$e->{'albums'} += $r->{'albums'} || 0;
		$e->{'tracks'} += $r->{'tracks'} || 0;
		$e->{'roles'}{ $r->{'role'} } = 1;
		$e->{'role'} = $r->{'role'} if $r->{'role'} < $e->{'role'};
	}

	# alphabetical order: a person under its last name, a group under the
	# name it carries; then numbered: the number is the reference
	_sortkey();
	my @out = sort {
		my $ka = Plugins::LibraryMapper::SortKey::artistSortKey($a->{'name'});
		my $kb = Plugins::LibraryMapper::SortKey::artistSortKey($b->{'name'});
		$ka cmp $kb || lc($a->{'name'}) cmp lc($b->{'name'});
	} values %byName;

	my $style = $prefs->get('artistNameStyle') || 'firstlast';
	my $nr = 0;
	_mapping();
	for my $e (@out) {
		$e->{'nr'} = ++$nr;
		# the key the name is filed under: it shows the user where the
		# artist will end up in the alphabetical order
		$e->{'sortKey'} = Plugins::LibraryMapper::SortKey::artistSortKey($e->{'name'});
		$e->{'roleTokens'} = [ map { roleToken($_) } sort { $a <=> $b } keys %{ $e->{'roles'} } ];
		$e->{'mapping'} = Plugins::LibraryMapper::Mapping::roleCanonical(
			$e->{'name'}, $e->{'role'}, $style);
	}

	# keep the result: the numbers are the references of the mapping
	$DBH->begin_work;
	$DBH->do('DELETE FROM query_results');
	my $ins = $DBH->prepare(
		'INSERT OR REPLACE INTO query_results(nr, name, role, roles, albums, tracks) VALUES (?,?,?,?,?,?)');
	for my $e (@out) {
		$ins->execute($e->{'nr'}, $e->{'name'}, $e->{'role'},
			join(',', @{ $e->{'roleTokens'} }), $e->{'albums'}, $e->{'tracks'});
	}
	$ins->finish;
	$DBH->commit;

	return { rows => \@out, count => scalar @out, pattern => $pattern };
}

# The result of the last search, with the current mapping of every row.
sub lastQueryResults {
	return [] unless $DBH;
	my $rows = $DBH->selectall_arrayref(
		'SELECT nr, name, role, roles, albums, tracks FROM query_results ORDER BY nr',
		{ Slice => {} }) || [];
	my $style = $prefs->get('artistNameStyle') || 'firstlast';
	_mapping();
	for my $r (@$rows) {
		my @roles = grep { $_ =~ /^\d+$/ } split /,/, ($r->{'roles'} // '');
		$r->{'roleTokens'} = @roles ? [ map { 0 + $_ } @roles ] : [ $r->{'role'} ];
		$r->{'mapping'} = Plugins::LibraryMapper::Mapping::roleCanonical(
			$r->{'name'}, $r->{'role'}, $style);
	}
	return $rows;
}

# The name of a search result, by its reference number.
sub queryResultName {
	my ($nr) = @_;
	return '' unless $DBH;
	return '' unless defined $nr && $nr =~ /^\d+$/;
	my ($name) = $DBH->selectrow_array('SELECT name FROM query_results WHERE nr=?', undef, $nr);
	return $name || '';
}

# Apply a mapping to one search result.  $ref is the reference number of the
# row (or the name itself).  An empty canonical name clears the mapping.
sub setContributorMapping {
	my ($ref, $canonical, $role) = @_;
	return 0 unless $DBH;
	return 0 unless defined $ref && $ref ne '';

	my ($name, $useRole);
	if ($ref =~ /^\d+$/ && $ref > 0) {
		my $row = $DBH->selectrow_hashref(
			'SELECT name, role FROM query_results WHERE nr=?', undef, $ref);
		return 0 unless $row;
		$name = $row->{'name'};
		$useRole = $row->{'role'};
	}
	else {
		$name = $ref;
		$useRole = ($role && $role =~ /^\d+$/) ? 0 + $role : 1;
	}
	$useRole = 1 unless $useRole;
	$canonical = '' unless defined $canonical;
	# the name comes from the page: it is turned into UTF-8 bytes, because
	# that is what the database speaks
	$canonical = _bytes($canonical);
	$canonical =~ s/^\s+|\s+$//g;

	# the mapping cell accepts the number of another row as a reference:
	# "12" means "the name of row 12"
	if ($canonical =~ /^\d+$/ && $canonical > 0 && !($ref =~ /^\d+$/ && $ref == $canonical)) {
		my ($other) = $DBH->selectrow_array(
			'SELECT name FROM query_results WHERE nr=?', undef, $canonical);
		$canonical = $other if defined $other && $other ne '';
	}

	if ($canonical eq '') {
		$DBH->do('DELETE FROM contributor_mappings WHERE role=? AND variant=?',
			undef, $useRole, _fold($name));
	}
	else {
		$DBH->do('INSERT OR REPLACE INTO contributor_mappings(role, variant, canonical, updated_at) VALUES (?,?,?,?)',
			undef, $useRole, _fold($name), $canonical, time());
	}
	# an artist mapping is also the artist spelling correction: the tree
	# shows the corrected name
	if ($useRole == 1) {
		setArtistCanonical(_fold($name), $canonical);
		# a corrected artist changes the tree: re-resolve from the cached credits
		refreshTree();
	}
	return 1;
}

# The number of items a level of the tree shows.
#
# The value comes from the page of the plugin or from the tree: it is a
# number ("100") or the word "unlimited".  When it is missing, the preference
# of the plugin decides.
sub _limitOf {
	my ($value) = @_;
	my $pref = $prefs->get('listLimit') || 100;
	return $pref unless defined $value && $value ne '';
	return UNLIMITED if $value eq 'unlimited' || $value eq 'all' || $value eq '0';
	return $value if $value =~ /^\d+$/ && $value > 0;
	return $pref;
}

# virtual browse: categories query only.
# Returns { type, rows, title } where:
#   level  -> list of { key, n }          (genres, or artists within a genre)
#   albums -> list of album rows          (within a genre + artist)
#   tracks -> list of tracks (disc/tracknum order) of ONE album
sub browse {
	my %args = @_;
	return { type => 'level', rows => [], title => '' } unless $DBH;
	_wipeIfNeeded();
	my $limit = _limitOf($args{'list'});
	my $order = $args{'order'} || 'alpha';
	my $groupOrder = $args{'groupOrder'} || 'alpha';
	my $filterSql = ' WHERE 1=1';
	my @filterP;
	if (my $t = $args{'time'}) {
		if ($t ne 'all') { $filterSql .= ' AND a.added >= ?'; push @filterP, _timeStart($t); }
	}
	if (my $q = $args{'quality'}) {
		if ($q ne 'all') { $filterSql .= ' AND a.quality = ?'; push @filterP, $q; }
	}

	# The artist filter is a regular expression: it selects the artists of
	# the current genre group.
	my $pattern = $args{'filter'};
	$pattern = '' unless defined $pattern;
	# the pattern is matched against the names of the database, which are
	# UTF-8 bytes: it is turned into bytes as well
	$pattern = _bytes($pattern);
	$pattern =~ s/^\s+|\s+$//g;
	my $filterRe;
	my $filterError = 0;
	if ($pattern ne '') {
		$filterRe = eval { qr/$pattern/i };
		if (!$filterRe) {
			logError("LibraryMapper browse: invalid artist filter '$pattern'");
			$filterRe = undef;
			$filterError = 1;
		}
	}

	# The drill-down path is "genre|artist|album_id":
	#   1 element  - the genre groups
	#   2 elements - the artists of one genre group
	#   3 elements - the albums of one artist within one genre group
	# and the album id identifies the tracks.
	#
	# The path arrives as characters (the server decodes the parameters of the
	# request): it is turned back into UTF-8 bytes, so that it can be
	# compared with the names of the database.
	if (my $p = _bytes($args{'parent'})) {
		my @path = split /\|/, $p;
		if (@path >= 3) {
			# drill into an album: tracks in disc / track-number order.
			# The tracks of one album are never cut short: the "items shown"
			# preference applies to the levels of the tree, not to the
			# content of an album.
			my $rows = $DBH->selectall_arrayref(qq{
				SELECT title, tracknum, disc, quality, track_id, url FROM tracks_cache
				WHERE album_id = ?
				ORDER BY COALESCE(disc,1), COALESCE(tracknum,9999), title
				LIMIT 10000}, { Slice => {} }, $path[2]);
			return { type => 'tracks', rows => $rows, title => $path[1], parent => $p,
			         filter => $pattern, filterError => $filterError };
		}
		elsif (@path == 2) {
			# albums of one artist within one genre group
			my $ordering = _albumOrdering($order);
			my $rows = $DBH->selectall_arrayref(qq{
				SELECT a.vpath_genre AS vpath_genre, l.artist AS vpath_artist,
				       a.vpath_album AS vpath_album, a.name AS name, a.year AS year,
				       a.album_id AS album_id, a.quality AS quality,
				       a.artwork_track_id AS artwork_track_id
				FROM albums_cache a
				JOIN album_artist_list l ON l.album_id = a.album_id
				$filterSql
				AND a.vpath_genre = ? AND l.artist = ?
				ORDER BY $ordering LIMIT ?}, { Slice => {} }, @filterP, $path[0], $path[1], $limit);
			return { type => 'albums', rows => $rows, title => $path[1], parent => $p,
			         filter => $pattern, filterError => $filterError };
		}
		elsif ($path[0]) {
			# artists within one genre group
			my $rows = $DBH->selectall_arrayref(qq{
				SELECT l.artist AS key, COUNT(DISTINCT a.album_id) AS n,
				       MAX(a.added) AS lastadded
				FROM album_artist_list l
				JOIN albums_cache a ON a.album_id = l.album_id
				$filterSql
				AND a.vpath_genre = ?
				GROUP BY l.artist
				HAVING COUNT(DISTINCT a.album_id) > 0},
				{ Slice => {} }, @filterP, $path[0]);
			# the order of the artists follows the order of the albums: the
			# alphabetical one, or the date of the last album of the artist
			# when the user asked for the most recent first
			$rows = _sortArtists($rows, $order);
			# the regex filter narrows the list down
			$rows = [ grep { $_->{'key'} =~ $filterRe } @$rows ] if $filterRe;
			$rows = [ @{$rows}[ 0 .. $limit - 1 ] ] if @$rows > $limit;
			return { type => 'level', rows => $rows, title => $path[0], parent => $p,
			         level => 'artists',
			         filter => $pattern, filterError => $filterError };
		}
	}

	# top: genre groups
	#
	# A group that holds no album is not shown: the tree only offers what can
	# really be opened.  The group of the albums that carry no genre at all
	# is not a genre either: it is hidden unless the user asks for it on the
	# parameter page.
	my $noGenreSql = '';
	my @noGenreP;
	unless ($prefs->get('showUnclassified')) {
		$noGenreSql = ' AND LOWER(a.vpath_genre) NOT IN ('
			. join(',', ('?') x scalar(@NO_GENRE)) . ')';
		@noGenreP = @NO_GENRE;
	}
	my $groupOrdering = _groupOrdering($groupOrder);
	my $rows = $DBH->selectall_arrayref(qq{
		SELECT a.vpath_genre AS key, COUNT(DISTINCT a.album_id) AS n
		FROM albums_cache a$filterSql$noGenreSql
		GROUP BY a.vpath_genre
		HAVING COUNT(DISTINCT a.album_id) > 0
		ORDER BY $groupOrdering LIMIT ?},
		{ Slice => {} }, @filterP, @noGenreP, $limit);
	# the group of the albums that carry no genre is marked: it is shown
	# under a name that says it
	for my $r (@$rows) {
		$r->{'unclassified'} = 1 if _isNoGenre($r->{'key'});
	}
	return { type => 'level', rows => $rows, title => '', filter => $pattern,
	         level => 'genres',
	         filterError => $filterError };
}

# Does this name mean "no genre at all"?
sub _isNoGenre {
	my $name = shift;
	return 0 unless defined $name;
	$name = lc $name;
	$name =~ s/^\s+|\s+$//g;
	for my $n (@NO_GENRE) {
		return 1 if $name eq $n;
	}
	return 0;
}

# The order of the albums of one artist.
sub _albumOrdering {
	my $order = shift || 'alpha';
	return 'a.year DESC, a.name ASC'  if $order eq 'newer';
	return 'a.year ASC, a.name ASC'   if $order eq 'older';
	return 'a.added DESC, a.name ASC'  if $order eq 'added';
	return 'a.name ASC';
}

# The order of the genre groups.
sub _groupOrdering {
	my $order = shift || 'alpha';
	return 'COUNT(DISTINCT a.album_id) DESC, a.vpath_genre ASC' if $order eq 'count';
	return 'COUNT(DISTINCT a.album_id) ASC, a.vpath_genre ASC'  if $order eq 'countasc';
	return 'a.vpath_genre ASC';
}

# The order of the artists.
#
# The alphabetical order is the usual one: a person is filed under its last
# name, a group under the name it carries ("Claude Nougaro" -> N,
# "Metallica" -> M).
#
# When the user asked for the most recent first ("newer" or "added"), the
# artists are ordered by the date their last album was added to the library:
# the artist who is working right now comes first.
sub _sortArtists {
	my ($rows, $order) = @_;
	if ($order && ($order eq 'newer' || $order eq 'added')) {
		my @recent = sort {
			($b->{'lastadded'} || 0) <=> ($a->{'lastadded'} || 0)
				|| lc($a->{'key'}) cmp lc($b->{'key'})
		} @$rows;
		return \@recent;
	}
	_sortkey();
	my @out = sort {
		my $ka = Plugins::LibraryMapper::SortKey::artistSortKey($a->{'key'});
		my $kb = Plugins::LibraryMapper::SortKey::artistSortKey($b->{'key'});
		$ka cmp $kb || lc($a->{'key'}) cmp lc($b->{'key'});
	} @$rows;
	return \@out;
}

sub _timeStart {
	my $what = shift;
	my $now = time();
	return $now - 86_400        if $what eq 'day';
	return $now - 7 * 86_400    if $what eq 'week';
	return $now - 30 * 86_400   if $what eq 'month';
	return $now - 365 * 86_400  if $what eq 'year';
	return 0;
}

1;
