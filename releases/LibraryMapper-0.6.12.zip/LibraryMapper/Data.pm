package Plugins::LibraryMapper::Data;

use strict;

use File::Basename qw(dirname);
use File::Spec;

use DBI;

use Slim::Utils::Log qw(logger logError logWarning);
use Slim::Utils::Prefs;
use Slim::Utils::OSDetect;

my $log = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

my $DBH;   # dedicated plugin database handle
my $SCAN_PID = 0;   # the process number of the scan that is running

# The names the tags use when an album carries no genre at all.  They are
# not genres: the group they make is hidden by default.

# The number of items a level shows when the user asks for "unlimited": the
# library holds far less than that, so every item of the level is shown.
use constant UNLIMITED => 1000000;

my @NO_GENRE = (
	'pas de genre', 'sans genre', 'no genre', 'none', 'unknown',
	'unknown genre', 'genre inconnu', 'inconnu', 'ohne genre',
	'nicht klassifiziert', 'sin genero', 'sem genero', 'geen genre',
);

# The mapping module needs the data module, so it cannot be loaded at the
# top here: it is loaded on demand instead.
sub _mapping { require Plugins::LibraryMapper::Mapping; return 1; }

# The sort order of the artists has no Lyrion dependency either.
sub _sortkey { require Plugins::LibraryMapper::SortKey; return 1; }

# Shared accessors used by Mapping.pm
sub dbh { return $DBH; }

# --------------------------------------------------------------- the encoding
#
# The whole plugin speaks UTF-8 bytes, exactly like Lyrion itself: the names
# of the artists, of the albums and of the genres are read from the index of
# the server as UTF-8 bytes and they are stored in the database of the plugin
# as those same bytes.
#
# This is not a choice of taste: the SQLite driver of the server writes a
# text that carries the UTF-8 flag as Latin-1 bytes ("é" would be written
# e9 instead of c3 a9), so a character string must never reach the database.
#
# The characters appear at two places only, and both of them are handled
# here:
#
#   - the links of the pages: the server escapes them with
#     uri_escape_utf8, which escapes a byte string twice ("Jules Billé"
#     would become "Jules%20Bill%C3%83%C2%A9") and a character string
#     once.  The template therefore decodes the name before it escapes
#     it: [% name | utf8on | uri %].
#   - the answers in JSON: JSON::XS writes a byte string as Latin-1, so
#     the text is decoded before it is encoded.
sub _bytes {
	my $s = shift;
	return $s unless defined $s;
	utf8::encode($s) if utf8::is_utf8($s);
	return $s;
}

sub _chars {
	my $s = shift;
	return $s unless defined $s;
	utf8::decode($s) unless utf8::is_utf8($s);
	return $s;
}

# A query on the index of Lyrion.  The text of the library comes back as
# UTF-8 bytes, which is what the plugin works with.
sub _lmsQuery {
	my ($dbh, $sql, $attr, @bind) = @_;
	my $rows = eval { $dbh->selectall_arrayref($sql, $attr, @bind) };
	return [] unless $rows;
	return $rows;
}

# The text of a whole structure, decoded: JSON::XS writes a byte string as
# Latin-1, which would show "Jules BillÃ©" in the browser.
sub _jsonChars {
	my ($data) = @_;
	if (ref $data eq 'HASH') {
		$data->{$_} = _jsonChars($data->{$_}) for keys %$data;
	}
	elsif (ref $data eq 'ARRAY') {
		$data->[$_] = _jsonChars($data->[$_]) for 0 .. $#$data;
	}
	elsif (!ref $data && defined $data) {
		return _chars($data);
	}
	return $data;
}

sub to_json {
	my ($data) = @_;
	if (!ref $data) {
		# diagnose instead of dying: log the caller and answer with a JSON error
		require Carp;
		logError("LibraryMapper to_json: non-ref argument '" . ($data // 'undef') . "'\n" . Carp::longmess());
		return '{"error": "librarymapper: to_json received non-ref argument (see server log)"}';
	}
	require JSON::XS;
	my $json = JSON::XS::encode_json(_jsonChars($data));
	# The answer of the server is often put into another answer (the JSON of
	# the skins, the answers of the command line).  JSON::XS writes a byte
	# string as Latin-1, so a byte string that is put into another answer is
	# written twice ("Jules Billé" becomes "Jules BillÃ©").  The answer is
	# therefore returned as characters: the one that writes it (the server,
	# the browser) turns them into UTF-8 bytes exactly once.
	utf8::decode($json);
	return $json;
}
sub from_json {
	my ($text) = @_;
	require JSON::XS;
	# JSON::XS wants octets: a text that carries the UTF-8 flag (the text of
	# a form field, for instance) is turned into its UTF-8 bytes first.
	utf8::encode($text) if utf8::is_utf8($text);
	return JSON::XS::decode_json($text);
}

# ---------------------------------------------------------------- persist dir

sub dbPath {
	my $dir = _persistDir();
	return File::Spec->catfile($dir, 'librarymapper.db');
}

# The plugin keeps its own files in a directory of the preferences folder of
# the server: that folder survives a restart of the server and is not wiped
# with the cache.
#
# (An earlier version asked the operating system for the preferences folder
# with OSDetect->dir('prefs'), which does not exist: the answer was empty and
# the fallback was /tmp, so the database was lost at every reboot.)
sub _persistDir {
	my $base = '';

	for my $dir (eval { Slim::Utils::OSDetect::dirsFor('prefs') } || ()) {
		next unless $dir && -d $dir;
		$base = $dir;
		last;
	}

	# the preferences folder of the server, when it is not the default one
	if (!$base && $::prefsdir && -d $::prefsdir) {
		$base = $::prefsdir;
	}

	# last resort: the folder the server was started from
	if (!$base && $main::Bin && -d File::Spec->catdir($main::Bin, 'prefs')) {
		$base = File::Spec->catdir($main::Bin, 'prefs');
	}

	$base = File::Spec->catdir($base, 'LibraryMapper');
	mkdir $base unless -d $base;
	$prefs->set('dataDir', $base);
	return $base;
}

# ----------------------------------------------------------------- schema

my $SCHEMA = <<'SQL';
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS genre_groups (
	id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE,
	sort_order INTEGER DEFAULT 0, is_default INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS genre_variants (
	variant TEXT PRIMARY KEY,            -- folded display form
	occurrences INTEGER NOT NULL DEFAULT 0,   -- albums referencing it
	proposed_group TEXT, approved TEXT DEFAULT '', approved_by TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS genre_proposals (
	variant TEXT NOT NULL, part TEXT NOT NULL, pos INTEGER NOT NULL,
	group_name TEXT, PRIMARY KEY (variant, pos));
CREATE TABLE IF NOT EXISTS artist_variants (
	variant TEXT PRIMARY KEY, canonical TEXT,
	occurrences INTEGER NOT NULL DEFAULT 0, approved TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS album_artists (
	album_id INTEGER NOT NULL,
	artist_raw TEXT NOT NULL,
	n INTEGER NOT NULL DEFAULT 1,
	PRIMARY KEY (album_id, artist_raw));
CREATE INDEX IF NOT EXISTS idx_aa_album ON album_artists(album_id);
CREATE TABLE IF NOT EXISTS album_artist_map (
	album_id INTEGER PRIMARY KEY,
	artist_raw TEXT,
	resolved TEXT,
	confidence REAL,
	source TEXT);
CREATE TABLE IF NOT EXISTS album_artist_list (
	album_id INTEGER NOT NULL,
	artist TEXT NOT NULL,          -- canonical artist name
	weight INTEGER NOT NULL DEFAULT 1,
	PRIMARY KEY (album_id, artist));
CREATE INDEX IF NOT EXISTS idx_aal_artist ON album_artist_list(artist);
CREATE TABLE IF NOT EXISTS trusted_artists (
	name TEXT PRIMARY KEY,         -- as typed by the user
	added_at INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS contributor_cache (
	contributor_id INTEGER NOT NULL,
	name TEXT NOT NULL,
	role INTEGER NOT NULL,         -- 1 artist, 2 composer, 3 conductor,
	albums INTEGER NOT NULL DEFAULT 0,   -- 4 band, 5 album artist, 6 track artist
	tracks INTEGER NOT NULL DEFAULT 0,
	PRIMARY KEY (contributor_id, role));
CREATE INDEX IF NOT EXISTS idx_cc_name ON contributor_cache(name);
CREATE INDEX IF NOT EXISTS idx_cc_role ON contributor_cache(role);
CREATE TABLE IF NOT EXISTS contributor_mappings (
	role INTEGER NOT NULL,        -- 1 artist, 2 composer, 3 conductor ...
	variant TEXT NOT NULL,         -- the name as written in the tags
	canonical TEXT NOT NULL,       -- the name the user wants to see
	updated_at INTEGER NOT NULL DEFAULT 0,
	PRIMARY KEY (role, variant));
CREATE TABLE IF NOT EXISTS query_results (
	nr INTEGER PRIMARY KEY,       -- the number to use as a reference
	name TEXT NOT NULL,
	role INTEGER NOT NULL DEFAULT 0,
	roles TEXT DEFAULT '',        -- every role of that name, comma separated
	albums INTEGER NOT NULL DEFAULT 0,
	tracks INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS albums_cache (
	album_id INTEGER PRIMARY KEY,
	name TEXT NOT NULL, artist_raw TEXT, genre_raw TEXT,
	year INTEGER, added INTEGER,       -- epoch seconds, from Lyrion index
	quality TEXT,                      -- hires | cd | lossy | dsd | unknown
	duration INTEGER DEFAULT 0,        -- seconds; the longest of the encodings
	artwork_track_id INTEGER,          -- the track that carries the cover art
	vpath_genre TEXT, vpath_artist TEXT, vpath_album TEXT);
CREATE INDEX IF NOT EXISTS idx_ac_group ON albums_cache(vpath_genre);
CREATE INDEX IF NOT EXISTS idx_ac_artist ON albums_cache(vpath_artist);
CREATE INDEX IF NOT EXISTS idx_ac_added ON albums_cache(added);
CREATE TABLE IF NOT EXISTS tracks_cache (
	track_id INTEGER PRIMARY KEY,
	album_id INTEGER NOT NULL,
	title TEXT, tracknum INTEGER, disc INTEGER, quality TEXT, url TEXT);
CREATE INDEX IF NOT EXISTS idx_tc_album ON tracks_cache(album_id);
SQL

# the statements of the schema, one by one, and the table each one creates
my @STATEMENTS = split /;\n/, $SCHEMA;

my %TABLE_DDL;
for my $stmt (@STATEMENTS) {
	$TABLE_DDL{$1} = $stmt if $stmt =~ /CREATE TABLE IF NOT EXISTS\s+(\w+)/i;
}

sub init {
	my $path = dbPath();
	mkdir dirname($path) unless -d dirname($path);
	$DBH = _connectDb($path) or do {
		logError("LibraryMapper: cannot open dedicated db $path: $DBI::errstr");
		return;
	};
	for my $ddl (@STATEMENTS) {
		$DBH->do($ddl) or logError("LibraryMapper DDL failed: " . $DBI::errstr);
	}
	_migrate();
	# a rebuilt table took its indexes with it: they are created again here
	for my $ddl (@STATEMENTS) {
		$DBH->do($ddl) or logError("LibraryMapper DDL failed: " . $DBI::errstr);
	}
	# the icons the user uploaded on the parameter page are picked up again
	# (they are in the same folder as the database)
	eval { refreshIcons(); 1 } or logError("LibraryMapper: icon scan failed: $@");
	$log->info("LibraryMapper dedicated database: $path");
}

# The connection to the database of the plugin.  The scan runs in another
# process and opens its own connection, so this is used by both.
#
# The pragmas are the ones that make the difference on a network volume: the
# write ahead log keeps the readers out of the way of the writer, and the
# "normal" synchronisation does not write the whole journal to the disk at
# every transaction (that was the reason why the scan took hours).
sub _connectDb {
	my ($path) = @_;
	my $dbh = DBI->connect("dbi:SQLite:dbname=$path", '', '', {
		AutoCommit => 1,
		sqlite_use_immediate_transaction => 1,
		PrintError => 0,
	}) or return undef;
	$dbh->do("PRAGMA journal_mode=WAL");
	eval { $dbh->do("PRAGMA synchronous=NORMAL"); };
	eval { $dbh->do("PRAGMA busy_timeout=20000"); };
	eval { $dbh->do("PRAGMA cache_size=-16000"); };
	return $dbh;
}

# A statement that is checked: a statement that could not be prepared is an
# error that is reported, not a crash of the scan.
sub _prep {
	my ($sql) = @_;
	my $sth = $DBH->prepare($sql);
	unless ($sth) {
		my $err = $DBI::errstr || 'unknown error';
		logError("LibraryMapper: the statement could not be prepared: $err");
		die "the statement could not be prepared: $err\n";
	}
	return $sth;
}

# The schema grew over the versions: a table that was created with fewer
# columns is rebuilt instead of being left as it is.  Every table of the
# schema is checked, not only the one that changed last time.
sub _migrate {
	for my $table (sort keys %TABLE_DDL) {
		my $cols = eval {
			$DBH->selectall_arrayref("PRAGMA table_info($table)", { Slice => {} });
		};
		next unless $cols && @$cols;

		my %have = map { $_->{'name'} => 1 } @$cols;
		my $want = _expectedColumns($TABLE_DDL{$table});
		my @missing = grep { !$have{$_} } @$want;
		next unless @missing;

		$log->info("LibraryMapper: the table $table is rebuilt (missing: @missing)");
		$DBH->do("DROP TABLE $table");
		$DBH->do($TABLE_DDL{$table});
	}
}

# the columns of a CREATE TABLE statement
sub _expectedColumns {
	my ($ddl) = @_;
	my @cols;
	my ($body) = $ddl =~ /\((.*)\)/s;
	return \@cols unless $body;
	for my $line (split /\n/, $body) {
		$line =~ s/^\s+//;
		next unless length $line;
		next if $line =~ /^(?:PRIMARY|UNIQUE|FOREIGN|CHECK|CONSTRAINT)\b/i;
		my ($c) = $line =~ /^(\w+)/;
		push @cols, $c if $c;
	}
	return \@cols;
}

# ------------------------------------------------------------ initialization

# Schema-sensitive probes: Lyrion internal table/column names vary between
# versions; we probe once and remember what worked in meta.
sub _probe {
	require Slim::Schema;
	my $dbh = Slim::Schema->storage->dbh;
	return $dbh;
}

sub _tryQueries {
	my ($dbh, @candidates) = @_;
	for my $sql (@candidates) {
		# no bind parameters are passed: the trailing 3 used here previously
		# made every probe fail with 'called with 1 bind variables'
		my $rows = eval { $dbh->selectall_arrayref($sql, { Slice => {} }) };
		return $rows if $rows;
	}
	return undef;
}

# ------------------------------------------------------------ the background scan
#
# The scan reads the index of the server and fills the caches of the plugin.
# It never writes a file of the library: it only reads the index.
#
# The scan runs in the background (in a child process of the server), so that
# the music server keeps answering while it works.  The page that started it
# shows its progress: the state of the scan is written in the meta table and
# read back by the page.

# Start the scan in the background.  The function answers at once: the scan
# works on its own and writes its progress in the database.
sub startScan {
	my (%opt) = @_;

	_reapChild();

	if (_scanRunning()) {
		# a scan is already working: the library changed again, the running
		# scan does a second round when it is done
		_metaSet('scanPending', 1);
		return 0;
	}

	# The path of the database of the server.  The child process opens its own
	# connection to it: a database connection cannot be shared between two
	# processes.
	my $lmsPath = eval {
		require Slim::Schema;
		Slim::Schema->storage->dbh->{'Database'};
	};

	_metaSet('scanPending', 0);
	_metaSet('scanError', '');
	_metaSet('scanStarted', time());
	_metaSet('scanFinished', '');
	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_START', 1);

	my $pid = fork();
	if (!defined $pid) {
		logError("LibraryMapper: the scan could not be started in the background");
		_progress('error', '', 0);
		return 0;
	}

	if ($pid == 0) {
		# --- the child process ---------------------------------------------
		$0 = 'librarymapper scan';
		_closeInheritedHandles();
		my $ok = eval {
			$DBH = _connectDb(dbPath())
				or die "the database of the plugin could not be opened\n";
			my $dbh = _lmsReadHandle($lmsPath);
			# a change that arrives while the scan runs is picked up by a
			# second round
			for (my $round = 1; $round <= 5; $round++) {
				my $stats = runInitialization(dbh => $dbh);
				die(($stats->{'error'} || 'unknown error') . "\n") unless $stats->{'ok'};
				last unless _metaGet('scanPending');
				_metaSet('scanPending', 0);
			}
			1;
		};
		unless ($ok) {
			logError("LibraryMapper: the background scan failed: $@");
			$DBH = _connectDb(dbPath()) if !$DBH;
			_metaSet('scanError', _cleanError($@));
			_progress('error', '', 0);
		}
		require POSIX;
		POSIX::_exit(0);
	}

	$SCAN_PID = $pid;
	_metaSet('scanPid', $pid);
	return 1;
}

# The library changed: a file was added or removed.  The tree is brought up to
# date in the background; the mapping of the user is not touched.
sub libraryChanged {
	return 0 unless $DBH;
	# there is nothing to update as long as the library was never scanned
	return 0 unless _metaGet('lastInit');
	if (_scanRunning()) {
		_metaSet('scanPending', 1);
		return 0;
	}
	return startScan();
}

# Is a scan running?  A scan whose process is gone (the server was stopped in
# the middle of it) is not running any more.
sub _scanRunning {
	my $state = _metaGet('scanState');
	return 0 unless $state eq 'running';
	my $pid = _metaGet('scanPid');
	if ($pid && $pid =~ /^\d+$/ && $pid > 1) {
		return 1 if kill(0, $pid);
		logWarning("LibraryMapper: the scan process $pid is gone");
		_metaSet('scanState', 'error');
		_metaSet('scanError', 'the scan process stopped');
		return 0;
	}
	return 1;
}

# The state of the scan, for the progress bar of the parameter page.
sub scanStatus {
	return { state => 'none', step => '', progress => 0 } unless $DBH;
	_reapChild();
	return {
		state    => (_metaGet('scanState') || 'none'),
		step     => _metaGet('scanStep'),
		progress => (_metaGet('scanProgress') || 0),
		started  => (_metaGet('scanStarted') || 0),
		finished => (_metaGet('scanFinished') || 0),
		error    => _metaGet('scanError'),
		pending  => (_metaGet('scanPending') || 0),
	};
}

# The progress of the scan, written in the database: the page reads it and
# shows the bar.  The step is the token of a string of the plugin.
sub _progress {
	my ($state, $step, $percent) = @_;
	_metaSet('scanState', $state);
	_metaSet('scanStep', $step) if defined $step;
	_metaSet('scanProgress', $percent) if defined $percent;
}

sub _metaSet {
	my ($key, $value) = @_;
	return unless $DBH;
	$value = '' unless defined $value;
	eval {
		$DBH->do('INSERT OR REPLACE INTO meta(key, value) VALUES (?,?)', undef, $key, $value);
		1;
	} or do { logWarning("LibraryMapper: the state '$key' could not be written: $@"); };
}

sub _metaGet {
	my ($key) = @_;
	return '' unless $DBH;
	my ($v) = eval { $DBH->selectrow_array('SELECT value FROM meta WHERE key=?', undef, $key) };
	return defined $v ? $v : '';
}

# The pages the server cached still show the tree of before the scan: they are
# wiped as soon as a new scan has finished.
sub _wipeIfNeeded {
	return unless $DBH;
	return unless _metaGet('scanDirty');
	_metaSet('scanDirty', 0);
	eval {
		require Slim::Web::XMLBrowser;
		Slim::Web::XMLBrowser->wipeCaches();
		1;
	} or logWarning("LibraryMapper: the cached pages could not be wiped: $@");
}

# The child process inherits everything the server had open: the connection of
# the web server among them.  It closes every descriptor it does not need (the
# log stays open), so that it cannot disturb the answer of the server.
sub _closeInheritedHandles {
	return unless -d '/proc/self/fd';
	opendir(my $dh, '/proc/self/fd') or return;
	my @fds = grep { /^\d+$/ } readdir($dh);
	closedir($dh);
	for my $fd (@fds) {
		next if $fd <= 2;
		close($fd);
	}
}

# The connection to the database of the server.  A connection cannot be shared
# between two processes, so the child opens its own one.
sub _lmsReadHandle {
	my ($path) = @_;
	if ($path && -f $path) {
		my $dbh = eval {
			DBI->connect("dbi:SQLite:dbname=$path", '', '', {
				AutoCommit => 1, RaiseError => 1, PrintError => 0,
			});
		};
		if ($dbh) {
			eval { $dbh->do('PRAGMA busy_timeout=30000'); };
			return $dbh;
		}
		logWarning("LibraryMapper: the database of the library could not be opened ($path): $@");
	}
	require Slim::Schema;
	return Slim::Schema->storage->dbh;
}

# The child process is waited for, so that it does not stay as a zombie.
sub _reapChild {
	return 0 unless $SCAN_PID;
	require POSIX;
	my $r = waitpid($SCAN_PID, POSIX::WNOHANG());
	$SCAN_PID = 0 if $r == $SCAN_PID || $r == -1;
	return $r;
}

sub _cleanError {
	my ($err) = @_;
	$err = '' unless defined $err;
	$err =~ s/\s+/ /g;
	return substr($err, 0, 300);
}

# Runs the initialization scan: reads Lyrion's own index and fills
# albums_cache + raw genre/artist variant lists. Query-only: no tag or file
# writes. Returns a stats hash for the parameter page.
#
# Everything is read first and written afterwards, in one single transaction:
# the tree of the server is never left half written, and the write costs one
# transaction instead of one per row (that was the reason why the scan took
# hours on a network volume).
sub runInitialization {
	my %opt = @_;
	my $stats = { started => time() };
	unless ($DBH) {
		$stats->{'ok'} = 0;
		$stats->{'error'} = 'database not initialised';
		return $stats;
	}
	my $dbh = $opt{'dbh'} || _probe();

	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_LIBRARY', 5);

	# --- probe joins once, remember which shapes worked (Lyrion 9.x: genre_track) --
	my ($gTab, $gJoinA, $gJoinB);
	for my $c (
		['genre_track',  q{SELECT genre, track FROM genre_track LIMIT 2},  'gt.genre = g.id',  'gt.track = t.id'],
		['genres_track', q{SELECT track_id, genre_id FROM genres_track LIMIT 2}, 'gt.genre_id = g.id', 'gt.track_id = t.id'],
		['track_genres', q{SELECT track_id, genre_id FROM track_genres LIMIT 2}, 'gt.genre_id = g.id', 'gt.track_id = t.id'],
	) {
		my ($label, $probeSql, $joinA, $joinB) = @$c;
		if (_tryQueries($dbh, $probeSql)) {
			($gTab, $gJoinA, $gJoinB) = ($label, $joinA, $joinB);
			last;
		}
	}
	$stats->{'genreJoin'} = $gTab || '';

	my $hasAdded = _tryQueries($dbh,
		q{SELECT id, added_time FROM tracks ORDER BY id DESC LIMIT 2},
		q{SELECT id, timestamp FROM tracks ORDER BY id DESC LIMIT 2});
	$stats->{'addedColumn'} = '';
	if ($hasAdded && ref $hasAdded->[0]) {
		$stats->{'addedColumn'} = exists $hasAdded->[0]{added_time} ? 'added_time' : 'timestamp';
	}

	# The cover art of an album hangs on one of its tracks: the albums table
	# of Lyrion carries the id of that track in its "artwork" column.  The
	# URL /music/<id>/cover only understands a track id (or a cover id), so
	# the album id cannot be used there.
	my $hasArtwork = _tryQueries($dbh, q{SELECT id, artwork FROM albums LIMIT 2});
	$stats->{'artworkColumn'} = '';
	if ($hasArtwork && ref $hasArtwork->[0] && exists $hasArtwork->[0]{'artwork'}) {
		$stats->{'artworkColumn'} = 'artwork';
	}

	# The size of a sample: the server calls it "samplesize".  It is the
	# first witness that a track is a one bit file (DSD).  The column is
	# probed, because the name varies between the versions of the server.
	my $hasSamplesize = _tryQueries($dbh,
		q{SELECT id, samplesize FROM tracks ORDER BY id DESC LIMIT 2});
	$stats->{'sampleSizeColumn'} = '';
	if ($hasSamplesize && ref $hasSamplesize->[0]
		&& exists $hasSamplesize->[0]{'samplesize'}) {
		$stats->{'sampleSizeColumn'} = 'samplesize';
	}

	# The duration of a track in seconds: the column carries the names of
	# the versions of the server ("audio_seconds" of Lyrion 9, "seconds"
	# before it).  It gives the total duration of an album.
	# Lyrion 9.1.2 calls the column "secs" (the schema of the server carries
	# it beside the bitrate and the samplerate); "audio_seconds" and
	# "seconds" are guesses of other versions, probed before and after.
	my $hasSeconds = _tryQueries($dbh,
		q{SELECT id, secs FROM tracks ORDER BY id DESC LIMIT 2},
		q{SELECT id, audio_seconds FROM tracks ORDER BY id DESC LIMIT 2},
		q{SELECT id, seconds FROM tracks ORDER BY id DESC LIMIT 2});
	$stats->{'secondsColumn'} = '';
	if ($hasSeconds && ref $hasSeconds->[0]) {
		if (exists $hasSeconds->[0]{'secs'}) {
			$stats->{'secondsColumn'} = 'secs';
		}
		elsif (exists $hasSeconds->[0]{'audio_seconds'}) {
			$stats->{'secondsColumn'} = 'audio_seconds';
		}
		elsif (exists $hasSeconds->[0]{'seconds'}) {
			$stats->{'secondsColumn'} = 'seconds';
		}
	}

	# --- genres ------------------------------------------------------------
	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_GENRES', 15);
	my $genres = [];
	if ($gTab) {
		$genres = eval {
			_lmsQuery($dbh, qq{
				SELECT g.name, COUNT(DISTINCT t.album) AS albums
				FROM genres g
				JOIN $gTab gt ON $gJoinA
				JOIN tracks t ON $gJoinB
				GROUP BY g.name ORDER BY albums DESC}, { Slice => {} })
		};
		if (!$genres) { logError("LibraryMapper genres query failed: $@"); $genres = []; }
	}
	else {
		logWarning("LibraryMapper: no genre join table probed - genres skipped");
	}
	# the number of albums of every genre spelling, kept in memory: the rows
	# are written in one go at the end of the scan
	my %genreOcc;
	for my $g (@$genres) {
		my $variant = _fold($g->{name});
		next if $variant eq '';
		$genreOcc{$variant} = $g->{albums} || 0;
	}
	$stats->{'genreVariants'} = scalar keys %genreOcc;

	# --- artists -----------------------------------------------------------
	# Lyrion 9.x: track <-> contributor links live in contributor_track
	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_ARTISTS', 25);
	my $artists = eval {
		_lmsQuery($dbh, qq{
			SELECT c.name, COUNT(DISTINCT t.album) AS albums
			FROM contributors c
			JOIN contributor_track ct ON ct.contributor = c.id
			JOIN tracks t ON t.id = ct.track
			WHERE ct.role IN (1,5,6)
			GROUP BY c.name ORDER BY albums DESC}, { Slice => {} })
	};
	if (!$artists) { logError("LibraryMapper artists query failed: $@"); $artists = []; }
	my $style = $prefs->get('artistNameStyle') || 'firstlast';
	my %artistOcc;
	my %artistCanon;
	for my $a (@$artists) {
		my $variant = _fold($a->{name});
		next if $variant eq '';
		$artistOcc{$variant} = $a->{albums} || 0;
		$artistCanon{$variant} =
			Plugins::LibraryMapper::Mapping::normalizeArtistName($a->{name}, $style);
	}
	$stats->{'artistVariants'} = scalar keys %artistOcc;

	# --- albums cache (artist/genre/year/added/quality) ---------------------
	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_ALBUMS', 35);
	my $addedExpr = $stats->{'addedColumn'} ? "t.$stats->{addedColumn}" : 'NULL';
	my $artworkExpr = $stats->{'artworkColumn'} ? 'MAX(me.artwork)' : 'NULL';
	# The one bit files (DSD): two witnesses tell that a track is one of
	# them: the size of a sample (one bit) and the name of the file.
	my $dsdCond = '(';
	$dsdCond .= "t.$stats->{'sampleSizeColumn'} = 1" if $stats->{'sampleSizeColumn'};
	$dsdCond .= ' OR ' if $stats->{'sampleSizeColumn'};
	$dsdCond .= "LOWER(t.url) LIKE '%.dsf' OR LOWER(t.url) LIKE '%.dff')";
	# The duration of a track: the seconds come in three buckets, the three
	# classes of the encodings — the one bit files, the lossless ones and the
	# others.  A folder that carries the same album in two encodings (the
	# mp3 copies of the flac files) holds every track twice: the duration of
	# the album is the longest of the buckets, not their sum.
	my $secExpr = $stats->{'secondsColumn'}
		? "COALESCE(t.$stats->{'secondsColumn'}, 0)" : '0';
	my $albums = eval {
		_lmsQuery($dbh, qq{
			SELECT me.id, me.title, me.year, c.name AS artist,
			       MAX($addedExpr) AS added,
			       $artworkExpr AS artwork,
			       COUNT(t.id) AS tcnt,
			       SUM(CASE WHEN $dsdCond THEN 1 ELSE 0 END) AS dsd_n,
			       MAX(CASE WHEN $dsdCond THEN 0 ELSE t.samplerate END) AS sr,
			       MAX(CASE WHEN $dsdCond THEN 0 ELSE t.lossless END) AS lossless,
			       MAX(CASE WHEN $dsdCond THEN 0 ELSE t.bitrate END) AS br,
			       SUM(CASE WHEN $dsdCond THEN $secExpr ELSE 0 END) AS d_dsd,
			       SUM(CASE WHEN NOT($dsdCond) AND t.lossless IS 1              THEN $secExpr ELSE 0 END) AS d_ll,
			       SUM(CASE WHEN NOT($dsdCond) AND t.lossless IS NOT 1          THEN $secExpr ELSE 0 END) AS d_y
			FROM albums me
			JOIN tracks t ON t.album = me.id
			LEFT JOIN contributors c ON c.id = me.contributor
			GROUP BY me.id, me.title, me.year, artist}, { Slice => {} })
	};
	if (!$albums) { logError("LibraryMapper albums query failed: $@"); $albums = []; }
	$stats->{'albums'} = scalar @$albums;

	my $albumGenre = [];
	if ($gTab) {
		$albumGenre = eval {
			_lmsQuery($dbh, qq{
				SELECT t.album, g.name, COUNT(*) AS c
				FROM tracks t
				JOIN $gTab gt ON $gJoinB
				JOIN genres g ON $gJoinA
				GROUP BY t.album, g.name}, { Slice => {} })
		};
		if (!$albumGenre) { logError("LibraryMapper albumGenre query failed: $@"); $albumGenre = []; }
	}
	my %ag;
	for my $r (@$albumGenre) {
		push @{ $ag{ $r->{album} } ||= [] }, [ $r->{name}, $r->{c} ];
	}

	# --- album artists: one canonical name per album ------------------------
	my $artistRows = _albumArtistRows($dbh);
	my $resolution = Plugins::LibraryMapper::Mapping::resolveAlbumArtists(
		$artistRows, $prefs->get('artistNameStyle') || 'firstlast', trustedNames());
	$stats->{'albumArtistRows'} = scalar @$artistRows;
	$stats->{'albumsResolved'} = scalar keys %$resolution;

	# --- artist variants: raw spelling -> canonical "First Last" ------------
	{
		my %perVariant;
		for my $r (@$artistRows) {
			my $norm = Plugins::LibraryMapper::Mapping::normalizeArtistName(
				$r->{name}, $prefs->get('artistNameStyle') || 'firstlast');
			next unless $norm;
			my $key = _fold($r->{name});
			$perVariant{$key}{canonical} = $norm;
			$perVariant{$key}{albums}{$r->{album}} = 1;
		}
		for my $key (keys %perVariant) {
			$artistOcc{$key} = scalar keys %{ $perVariant{$key}{albums} };
			$artistCanon{$key} = $perVariant{$key}{canonical};
		}
	}
	$stats->{'artistVariants'} = scalar keys %artistOcc;

	# --- contributor cache: artists, composers, conductors -------------------
	# Every contributor of the library with the roles it is credited with.
	# This is what the regex search runs on.
	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_CONTRIBUTORS', 45);
	my %agg;
	{
		my $ct = eval {
			_lmsQuery($dbh, qq{
				SELECT ct.contributor AS cid, c.name AS name, ct.role AS role,
				       COUNT(DISTINCT t.album) AS albums, COUNT(*) AS tracks
				FROM contributor_track ct
				JOIN tracks t ON t.id = ct.track
				JOIN contributors c ON c.id = ct.contributor
				GROUP BY ct.contributor, ct.role}, { Slice => {} })
		};
		if (!$ct) { logError("LibraryMapper contributor_track query failed: $@"); $ct = []; }
		my $ca = eval {
			$dbh->selectall_arrayref(qq{
				SELECT ca.contributor AS cid, c.name AS name, ca.role AS role,
				       COUNT(DISTINCT ca.album) AS albums, 0 AS tracks
				FROM contributor_album ca
				JOIN contributors c ON c.id = ca.contributor
				GROUP BY ca.contributor, ca.role}, { Slice => {} })
		};
		if (!$ca) { logError("LibraryMapper contributor_album query failed: $@"); $ca = []; }

		for my $r (@$ct, @$ca) {
			next unless defined $r->{'cid'} && defined $r->{'name'};
			my $key = $r->{'cid'} . ':' . $r->{'role'};
			my $e = $agg{$key} ||= {
				cid => $r->{'cid'}, name => $r->{'name'},
				role => $r->{'role'}, albums => 0, tracks => 0 };
			$e->{'albums'} += $r->{'albums'} || 0;
			$e->{'tracks'} += $r->{'tracks'} || 0;
		}
		$stats->{'contributors'} = scalar keys %agg;
	}

	# the number of tracks, for the progress bar
	my $trackCount = 0;
	{
		my $c = eval { $dbh->selectrow_array('SELECT COUNT(*) FROM tracks') };
		$trackCount = $c if $c;
	}

	# --- write everything, in one single transaction ------------------------
	_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_TREE', 55);
	my $written = eval {
		$DBH->begin_work;

		# the caches are rebuilt from scratch: an album that left the library
		# must not stay in the list
		$DBH->do('DELETE FROM album_artists');
		$DBH->do('DELETE FROM album_artist_map');
		$DBH->do('DELETE FROM album_artist_list');
		$DBH->do('DELETE FROM albums_cache');
		$DBH->do('DELETE FROM tracks_cache');
		$DBH->do('DELETE FROM contributor_cache');

		# the genre spellings: the count is refreshed, the group the user
		# chose for them is kept.  These rows come first: the proposals of
		# the groups are computed from them, and the path of the albums is
		# built from the proposals.
		my $upGenre = _prep('UPDATE genre_variants SET occurrences=? WHERE variant=?');
		my $inGenre = _prep('INSERT INTO genre_variants(variant, occurrences) VALUES (?,?)');
		for my $variant (keys %genreOcc) {
			my $n = $upGenre->execute($genreOcc{$variant}, $variant);
			$inGenre->execute($variant, $genreOcc{$variant})
				if !$n || $n eq '0' || $n eq '0E0';
		}
		$upGenre->finish;
		$inGenre->finish;

		# the artist spellings: the correction of the user is never overwritten
		my $upArtist = _prep(
			'UPDATE artist_variants SET occurrences=?, canonical=CASE WHEN approved<>"" THEN approved ELSE ? END WHERE variant=?');
		my $inArtist = _prep(
			'INSERT INTO artist_variants(variant, canonical, occurrences, approved) VALUES (?,?,?,?)');
		for my $variant (keys %artistOcc) {
			my $canonical = $artistCanon{$variant};
			$canonical = '' unless defined $canonical;
			my $n = $upArtist->execute($artistOcc{$variant}, $canonical, $variant);
			$inArtist->execute($variant, $canonical, $artistOcc{$variant}, '')
				if !$n || $n eq '0' || $n eq '0E0';
		}
		$upArtist->finish;
		$inArtist->finish;

		# the proposals of the groups: the keyword rules of the plugin are
		# applied to the spellings that the user has not decided about yet.
		# The work joins the transaction: it is written with the rest.
		Plugins::LibraryMapper::Mapping::repropose();

		my $insAa = _prep(
			'INSERT OR REPLACE INTO album_artists(album_id, artist_raw, n) VALUES (?,?,?)');
		for my $r (@$artistRows) {
			$insAa->execute($r->{album}, $r->{name}, $r->{n});
		}
		$insAa->finish;

		my $insAlbum = _prep(
			'INSERT OR REPLACE INTO albums_cache(album_id, name, artist_raw, genre_raw, year, added, quality, duration, artwork_track_id, vpath_genre, vpath_artist, vpath_album) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
		my $insMap = _prep(
			'INSERT OR REPLACE INTO album_artist_map(album_id, artist_raw, resolved, confidence, source) VALUES (?,?,?,?,?)');
		my $insList = _prep(
			'INSERT OR REPLACE INTO album_artist_list(album_id, artist, weight) VALUES (?,?,?)');

		for my $a (@$albums) {
			my $g = $ag{ $a->{id} };
			my $genreRaw = $g ? _majority($g) : '';
			my $quality = _quality($a);
			my $res = $resolution->{ $a->{id} };
			my $artist = $res ? $res->{artist} : ($a->{artist} // '');
			my $vPath = _virtualPath($a, $genreRaw, $artist);
			# the duration of the album: the longest of the three buckets of
			# the encodings (the one bit, the lossless, the others)
			my $duration = $a->{d_dsd} || 0;
			$duration = $a->{d_ll} if ($a->{d_ll} || 0) > $duration;
			$duration = $a->{d_y}  if ($a->{d_y}  || 0) > $duration;
			$insAlbum->execute($a->{id}, $a->{title}, ($artist // ''),
				($genreRaw ? $genreRaw->[0] : ''),
				$a->{year} || 0, $a->{added} || 0, $quality, int($duration),
				$a->{artwork} || 0,
				$vPath->[0], $vPath->[1], $vPath->[2]);
			if ($res) {
				$insMap->execute($a->{id}, $res->{raw}, $res->{artist}, $res->{confidence}, 'auto');
				# every artist the album belongs to (a collaboration shows up
				# under each of its artists)
				for my $ar (@{ $res->{'artists'} || [] }) {
					$insList->execute($a->{id}, $ar->{name}, $ar->{weight});
				}
			}
			else {
				$insList->execute($a->{id}, ($artist || 'Unknown artist'), 1);
			}
		}
		$insAlbum->finish;
		$insMap->finish;
		$insList->finish;

		# the contributors
		my $insContrib = _prep(
			'INSERT OR REPLACE INTO contributor_cache(contributor_id, name, role, albums, tracks) VALUES (?,?,?,?,?)');
		for my $e (values %agg) {
			$insContrib->execute($e->{'cid'}, $e->{'name'}, $e->{'role'},
				$e->{'albums'}, $e->{'tracks'});
		}
		$insContrib->finish;

		# the tracks, read one by one: a library of hundreds of thousands of
		# tracks must not be loaded in memory at once
		my $insTrack = _prep(
			'INSERT OR REPLACE INTO tracks_cache(track_id, album_id, title, tracknum, disc, quality, url) VALUES (?,?,?,?,?,?,?)');
		# the size of a sample: the column is probed, its name varies
		my $ssExpr = $stats->{'sampleSizeColumn'}
			? "t.$stats->{'sampleSizeColumn'} AS ss" : 'NULL AS ss';
		my $sth = $dbh->prepare(qq{
			SELECT t.id, t.title, CAST(t.tracknum AS INTEGER) AS tracknum,
			       CAST(t.disc AS INTEGER) AS disc, t.album AS album_id,
			       t.samplerate AS sr, t.lossless AS lossless, t.bitrate AS br,
			       $ssExpr, t.url
			FROM tracks t});
		$sth->execute;
		my $n = 0;
		while (my $t = $sth->fetchrow_hashref) {
			$insTrack->execute($t->{'id'}, $t->{'album_id'}, $t->{'title'},
				$t->{'tracknum'}, $t->{'disc'}, _quality($t), $t->{'url'});
			$n++;
			if ($n % 5000 == 0) {
				my $pct = $trackCount ? int(55 + 40 * $n / $trackCount) : 95;
				_progress('running', 'PLUGIN_LIBRARYMAPPER_S_PHASE_TRACKS', $pct);
			}
		}
		$sth->finish;
		$insTrack->finish;
		$stats->{'tracks'} = $n;

		# the cover art of the albums that have none of their own: the URL
		# /music/<id>/cover needs a track id, an album without an artwork of
		# its own takes the first of its tracks
		$DBH->do(qq{
			UPDATE albums_cache SET artwork_track_id =
				(SELECT MIN(track_id) FROM tracks_cache WHERE album_id = albums_cache.album_id)
			WHERE (artwork_track_id IS NULL OR artwork_track_id = 0)});

		1;
	};

	unless ($written) {
		my $err = _cleanError($@);
		eval { $DBH->rollback; };
		logError("LibraryMapper: the scan could not be written: $err");
		$stats->{'ok'} = 0;
		$stats->{'error'} = $err;
		_metaSet('scanError', $err);
		_progress('error', '', 0);
		return $stats;
	}
	$DBH->commit;

	_metaSet('lastInit', time());
	_metaSet('scanFinished', time());
	# the pages the server cached still show the tree of before the scan
	_metaSet('scanDirty', 1);
	_progress('done', 'PLUGIN_LIBRARYMAPPER_S_PHASE_DONE', 100);
	$stats->{'duration'} = time() - $stats->{'started'};
	$stats->{'ok'} = 1;
	return $stats;
}
sub _albumArtistRows {
	my ($dbh) = @_;
	my @rows;

	my $albumArtists = eval {
		_lmsQuery($dbh, qq{
			SELECT ca.album AS album, c.name AS name, COUNT(*) AS n
			FROM contributor_album ca
			JOIN contributors c ON c.id = ca.contributor
			WHERE ca.role = 5
			GROUP BY ca.album, c.name}, { Slice => {} })
	};
	if ($albumArtists && @$albumArtists) {
		for my $r (@$albumArtists) {
			push @rows, { album => $r->{album}, name => $r->{name}, n => 10 * ($r->{n} || 1) };
		}
	}
	else {
		logWarning("LibraryMapper: no contributor_album rows - falling back to track artists");
	}

	my $trackArtists = eval {
		_lmsQuery($dbh, qq{
			SELECT t.album AS album, c.name AS name, COUNT(*) AS n
			FROM tracks t
			JOIN contributor_track ct ON ct.track = t.id
			JOIN contributors c ON c.id = ct.contributor
			WHERE ct.role IN (1,5)
			GROUP BY t.album, c.name}, { Slice => {} })
	};
	if ($trackArtists && @$trackArtists) {
		for my $r (@$trackArtists) {
			push @rows, { album => $r->{album}, name => $r->{name}, n => ($r->{n} || 1) };
		}
	}
	return \@rows;
}

sub _fold { my $s = shift; return '' unless defined $s; $s =~ s/^\s+|\s+$//g; return lc $s; }

# Upsert one artist spelling.  The "approved" column (a user correction made
# on the parameter page) is never overwritten by a re-run of the scan.
sub _setGenreVariant {
	my ($variant, $occurrences) = @_;
	return 0 unless defined $variant && $variant ne '';
	# the count is refreshed, but the approval of the user is kept
	my $n = $DBH->do('UPDATE genre_variants SET occurrences=? WHERE variant=?',
		undef, $occurrences, $variant);
	return 1 if $n && $n ne '0' && $n ne '0E0';
	$DBH->do('INSERT INTO genre_variants(variant, occurrences) VALUES (?,?)',
		undef, $variant, $occurrences);
	return 1;
}
sub _setArtistVariant {
	my ($variant, $canonical, $occurrences) = @_;
	return 0 unless defined $variant && $variant ne '';
	my $n = $DBH->do('UPDATE artist_variants SET canonical=?, occurrences=? WHERE variant=?',
		undef, $canonical, $occurrences, $variant);
	return 1 if $n && $n ne '0' && $n ne '0E0';
	$DBH->do('INSERT INTO artist_variants(variant, canonical, occurrences, approved) VALUES (?,?,?,?)',
		undef, $variant, $canonical, $occurrences, '');
	return 1;
}
sub _majority {
	my $list = shift;
	my @sorted = sort { $b->[1] <=> $a->[1] } @$list;
	return $sorted[0];
}
sub _quality {
	my $a = shift;
	# The one bit files come first: the server may report them as "not
	# lossless", and their samplerate (2.8 MHz for a DSD64) would put them
	# in the hi-res class, which they do not belong to.
	return 'dsd'    if _isDsd($a);
	return 'lossy'  if defined $a->{'lossless'} && !$a->{'lossless'};
	return 'hires'  if $a->{'sr'} && $a->{'sr'} > 48400;
	return 'cd'     if $a->{'sr'} && $a->{'sr'} > 40000;
	return 'unknown';
}

# The total duration of an album, ready to show: h:mm:ss, and only mm:ss
# under one hour.  An empty text when the album carries no duration at all
# (the caches of the scan of before).
sub _durationText {
	my ($sec) = @_;
	$sec = int($sec || 0);
	return '' unless $sec > 0;
	my $h = int($sec / 3600);
	my $m = int(($sec % 3600) / 60);
	my $s = $sec % 60;
	return sprintf('%d:%02d:%02d', $h, $m, $s) if $h;
	return sprintf('%d:%02d', $m, $s);
}

# The columns of an album row, shared by the three queries of the album
# levels (the walk of one artist, "All albums", the draw of "Random"):
# one list, so that a column added once is there for the three of them.
my $ALBUM_COLS
	= 'a.vpath_genre AS vpath_genre, l.artist AS vpath_artist,'
	. ' a.vpath_album AS vpath_album, a.name AS name, a.year AS year,'
	. ' a.album_id AS album_id, a.quality AS quality, a.duration AS duration,'
	. ' a.artwork_track_id AS artwork_track_id';

# The dressing of the rows of an album level, before the rows go back to
# the tree: the path stays under the group of the walk (the pseudo groups
# included, when the query did not carry it itself) and the duration is
# ready to show ("1:04:12").
sub _dressAlbums {
	my ($rows, $genre) = @_;
	for my $r (@$rows) {
		$r->{'vpath_genre'}  = $genre if defined $genre;
		$r->{'durationText'} = _durationText($r->{'duration'});
	}
	return $rows;
}

# The one bit files (DSD): the server reads one bit per sample and a
# samplerate of 2.8 MHz (DSD64) or more out of them.  They are their own
# quality: they are not a "hi-res" of 96 kHz but a different technology.
#
# Two witnesses tell that a track is a one bit file: the size of a sample
# (one bit) and the name of the file (.dsf and .dff).  An album is one bit
# when all of its tracks are.
sub _isDsd {
	my ($a) = @_;
	# an album: the number of its one bit tracks and the number of its
	# tracks (the aggregates of the scan are computed without the one bit
	# tracks, so that a mixed album keeps the class of its other tracks)
	if (defined $a->{'tcnt'}) {
		return 0 unless $a->{'tcnt'} && ($a->{'dsd_n'} || 0) == $a->{'tcnt'};
		return 1;
	}
	# a track
	return 1 if defined $a->{'ss'} && $a->{'ss'} == 1;
	my $url = $a->{'url'} || '';
	return 1 if $url =~ /\.(dsf|dff)\z/i;
	return 0;
}
sub _virtualPath {
	my ($a, $genreRaw, $artistRaw) = @_;
	my $group   = Plugins::LibraryMapper::Mapping::mappedGroup($genreRaw ? $genreRaw->[0] : '') // 'Unsorted';
	my $artist  = $artistRaw || 'Unknown artist';
	my $year    = $a->{'year'} || '????';
	return [ $group, $artist, "$year - $a->{'title'}" ];
}

# ------------------------------------------------------------------ queries

sub status {
	my ($out) = @_;
	return { error => 'database not initialised', albums => 0 } unless $DBH;
	_wipeIfNeeded();
	my ($lastInit) = $DBH->selectrow_array("SELECT value FROM meta WHERE key='lastInit'");
	$out = {
		dbPath    => dbPath(),
		lastInit  => $lastInit || 0,
		lastInitText => $lastInit ? scalar(localtime($lastInit)) : '',
		albums    => $DBH->selectrow_array('SELECT COUNT(*) FROM albums_cache'),
		genreVariants => $DBH->selectrow_array('SELECT COUNT(*) FROM genre_variants'),
		groups    => $DBH->selectrow_array('SELECT COUNT(*) FROM genre_groups'),
		mapped    => $DBH->selectrow_array('SELECT COUNT(*) FROM genre_variants WHERE approved<>""'),
		artistVariants => $DBH->selectrow_array('SELECT COUNT(*) FROM artist_variants'),
		artistMapped  => $DBH->selectrow_array('SELECT COUNT(*) FROM artist_variants WHERE approved<>""'),
		albumsResolved => $DBH->selectrow_array('SELECT COUNT(*) FROM album_artist_map'),
		artistLinks    => $DBH->selectrow_array('SELECT COUNT(*) FROM album_artist_list'),
		collaborations => $DBH->selectrow_array(
			'SELECT COUNT(*) FROM (SELECT album_id FROM album_artist_list GROUP BY album_id HAVING COUNT(*) > 1)'),
		trusted    => $DBH->selectrow_array('SELECT COUNT(*) FROM trusted_artists'),
		contributors => $DBH->selectrow_array('SELECT COUNT(DISTINCT name) FROM contributor_cache'),
	};
	# the state of the background scan
	my $scan = scanStatus();
	$out->{'scanState'}    = $scan->{'state'};
	$out->{'scanStep'}     = $scan->{'step'};
	$out->{'scanProgress'} = $scan->{'progress'};
	$out->{'scanError'}    = $scan->{'error'};
	$out->{'scanStarted'}  = $scan->{'started'};
	$out->{'scanFinished'} = $scan->{'finished'};
	return $out;
}

sub getGenreGroups {
	return [] unless $DBH;
	return $DBH->selectall_arrayref('SELECT id, name, sort_order, is_default FROM genre_groups ORDER BY sort_order, name', { Slice => {} });
}

sub topVariants {
	my $n = shift || 25;
	return [] unless $DBH;
	return $DBH->selectall_arrayref('SELECT variant, occurrences, proposed_group, approved FROM genre_variants ORDER BY occurrences DESC LIMIT ?', { Slice => {} }, $n );
}

sub topArtistVariants {
	my $n = shift || 25;
	return [] unless $DBH;
	return $DBH->selectall_arrayref(
		'SELECT variant, CASE WHEN approved<>"" THEN approved ELSE canonical END AS canonical,
		        occurrences, approved
		 FROM artist_variants ORDER BY occurrences DESC LIMIT ?',
		{ Slice => {} }, $n );
}

# Albums that are credited to more than one artist (a collaboration) or that
# carry several spellings of the same artist: the report of albums that could
# show up twice in the tree.
sub ambiguousAlbums {
	my $n = shift || 25;
	return [] unless $DBH;
	return $DBH->selectall_arrayref(qq{
		SELECT m.album_id, a.name AS album, m.resolved, m.confidence,
		       (SELECT COUNT(*) FROM album_artist_list l WHERE l.album_id = m.album_id) AS artists,
		       (SELECT COUNT(*) FROM album_artists aa WHERE aa.album_id = m.album_id) AS spellings,
		       (SELECT GROUP_CONCAT(l2.artist) FROM album_artist_list l2 WHERE l2.album_id = m.album_id) AS artist_list
		FROM album_artist_map m
		JOIN albums_cache a ON a.album_id = m.album_id
		WHERE artists > 1 OR spellings > 1
		ORDER BY artists DESC, spellings DESC, m.album_id LIMIT ?}, { Slice => {} }, $n );
}

# Approve (or clear) the canonical name of one artist spelling.  The row is
# created when it does not exist yet: a composer or a conductor may have no
# spelling row at all.
sub setArtistCanonical {
	my ($variant, $canonical) = @_;
	return 0 unless $DBH;
	return 0 unless defined $variant && $variant ne '';
	# the name comes from the page: it is turned into UTF-8 bytes, because
	# that is what the database speaks
	$variant = _bytes($variant);
	$canonical = '' unless defined $canonical;
	$canonical = _bytes($canonical);
	my $n = $DBH->do('UPDATE artist_variants SET approved=? WHERE variant=?',
		undef, $canonical, $variant);
	return 1 if $n && $n ne '0' && $n ne '0E0';
	$DBH->do('INSERT INTO artist_variants(variant, canonical, occurrences, approved) VALUES (?,?,?,?)',
		undef, $variant, '', 0, $canonical);
	return 1;
}

# ------------------------------------------------------- trusted artists
#
# A trusted name is an artist that is always ONE artist: the credit is never
# split and the albums credited to it are filed under it alone.  The user
# uploads the list of those names on the parameter page.

# The trusted names, with the number of albums currently filed under them.
sub trustedArtists {
	return [] unless $DBH;
	return $DBH->selectall_arrayref(qq{
		SELECT t.name AS name, t.added_at AS added_at,
		       (SELECT COUNT(*) FROM album_artist_list l WHERE l.artist = t.name) AS albums
		FROM trusted_artists t ORDER BY t.name}, { Slice => {} });
}

# The trusted names only (used by the artist resolution).
sub trustedNames {
	return [] unless $DBH;
	my $rows = $DBH->selectcol_arrayref('SELECT name FROM trusted_artists ORDER BY name');
	return $rows || [];
}

# Add names to the trusted list.  With $replace the whole list is replaced.
sub addTrustedArtists {
	my ($names, $replace) = @_;
	return 0 unless $DBH;
	my @clean;
	my %seen;
	for my $n (@{ $names || [] }) {
		next unless defined $n;
		$n = _bytes($n);
		$n =~ s/^\s+|\s+$//g;
		next unless $n ne '';
		next if $seen{lc $n}++;
		push @clean, $n;
	}
	return 0 unless @clean;
	$DBH->do('DELETE FROM trusted_artists') if $replace;
	my $ins = $DBH->prepare('INSERT OR REPLACE INTO trusted_artists(name, added_at) VALUES (?,?)');
	$DBH->begin_work;
	for my $n (@clean) { $ins->execute($n, time()); }
	$DBH->commit;
	$ins->finish;
	return scalar @clean;
}

# Remove one name from the trusted list.
sub removeTrustedArtist {
	my ($name) = @_;
	return 0 unless $DBH;
	return 0 unless defined $name && $name ne '';
	$DBH->do('DELETE FROM trusted_artists WHERE name=?', undef, _bytes($name));
	return 1;
}

# Re-resolve the album artists from the cached raw credits.  No Lyrion access
# is needed, so this runs in a second: it is used after the trusted list or
# the artist corrections changed.  Returns the number of albums resolved.
sub reresolveArtists {
	return 0 unless $DBH;
	my $rows = $DBH->selectall_arrayref(
		'SELECT album_id AS album, artist_raw AS name, n FROM album_artists', { Slice => {} });
	return 0 unless $rows && @$rows;

	my $style = $prefs->get('artistNameStyle') || 'firstlast';
	my $res = Plugins::LibraryMapper::Mapping::resolveAlbumArtists(
		$rows, $style, trustedNames());

	$DBH->begin_work;
	$DBH->do('DELETE FROM album_artist_list');
	my $upArt = $DBH->prepare('UPDATE album_artist_map SET resolved=?, confidence=? WHERE album_id=?');
	my $upAlb = $DBH->prepare('UPDATE albums_cache SET artist_raw=?, vpath_artist=? WHERE album_id=?');
	for my $a (@$rows) {
		my $r = $res->{ $a->{'album'} };
		next unless $r;
		for my $ar (@{ $r->{'artists'} || [] }) {
			$DBH->do('INSERT OR REPLACE INTO album_artist_list(album_id, artist, weight) VALUES (?,?,?)',
				undef, $a->{'album'}, $ar->{'name'}, $ar->{'weight'});
		}
		$upArt->execute($r->{'artist'}, $r->{'confidence'}, $a->{'album'});
		$upAlb->execute($r->{'artist'}, $r->{'artist'}, $a->{'album'});
	}
	$upArt->finish;
	$upAlb->finish;
	# albums without any artist credit keep their "Unknown artist" entry
	$DBH->do(qq{
		INSERT OR IGNORE INTO album_artist_list(album_id, artist, weight)
		SELECT a.album_id, 'Unknown artist', 1
		FROM albums_cache a
		WHERE NOT EXISTS (SELECT 1 FROM album_artist_list l WHERE l.album_id = a.album_id)});
	$DBH->commit;
	return scalar keys %$res;
}

# Re-resolve the genre group of every album from the mapping that is in the
# database now.  The raw genre of the album is cached, so no Lyrion access is
# needed: the tree can be rebuilt in a second, without a new scan.
# Returns the number of albums that were re-resolved.
sub reresolveGenres {
	return 0 unless $DBH;
	my $rows = $DBH->selectall_arrayref(
		'SELECT album_id, genre_raw, name, year FROM albums_cache', { Slice => {} });
	return 0 unless $rows && @$rows;

	# one query per genre, not per album
	my %group;
	my $changed = 0;
	$DBH->begin_work;
	my $up = $DBH->prepare(
		'UPDATE albums_cache SET vpath_genre=?, vpath_album=? WHERE album_id=?');
	for my $r (@$rows) {
		my $raw = $r->{'genre_raw'};
		$raw = '' unless defined $raw;
		if (!exists $group{$raw}) {
			$group{$raw} = Plugins::LibraryMapper::Mapping::mappedGroup($raw) || 'Unsorted';
		}
		my $year  = $r->{'year'} || '????';
		my $album = "$year - " . ($r->{'name'} // '');
		$up->execute($group{$raw}, $album, $r->{'album_id'});
		$changed++;
	}
	$up->finish;
	$DBH->commit;
	return $changed;
}

# Apply the mapping that is in the database now to the tree and let the server
# forget the pages it cached: the new mapping is visible at once, the server
# does not have to be restarted.
sub refreshTree {
	return 0 unless $DBH;
	my $n = reresolveGenres();
	reresolveArtists();

	# the classic web pages are cached by the server: they would still show
	# the tree of before the mapping
	eval {
		require Slim::Web::XMLBrowser;
		Slim::Web::XMLBrowser->wipeCaches() if Slim::Web::XMLBrowser->can('wipeCaches');
		1;
	} or do { logWarning("LibraryMapper: the web page cache could not be wiped: $@"); };

	return $n;
}

# ------------------------------------------------------------------ search
#
# A regex search over the contributors of the library (artists, composers,
# conductors).  The result is an ordered and numbered list: the number is the
# reference the user can use to apply a mapping to that row later on.

my %ROLE_TOKEN = (
	1 => 'PLUGIN_LIBRARYMAPPER_ROLE_ARTIST',
	2 => 'PLUGIN_LIBRARYMAPPER_ROLE_COMPOSER',
	3 => 'PLUGIN_LIBRARYMAPPER_ROLE_CONDUCTOR',
	4 => 'PLUGIN_LIBRARYMAPPER_ROLE_BAND',
	5 => 'PLUGIN_LIBRARYMAPPER_ROLE_ALBUMARTIST',
	6 => 'PLUGIN_LIBRARYMAPPER_ROLE_TRACKARTIST',
);

# the string token of a role number ('' for an unknown role)
sub roleToken { my $r = shift || 0; return $ROLE_TOKEN{ 0 + $r } || ''; }

# The names of the roles the search can filter on.
sub searchRoles {
	return [
		{ value => 'all', token => 'PLUGIN_LIBRARYMAPPER_S_ALLROLES' },
		{ value => 1, token => $ROLE_TOKEN{1} },
		{ value => 2, token => $ROLE_TOKEN{2} },
		{ value => 3, token => $ROLE_TOKEN{3} },
		{ value => 4, token => $ROLE_TOKEN{4} },
		{ value => 5, token => $ROLE_TOKEN{5} },
		{ value => 6, token => $ROLE_TOKEN{6} },
	];
}

# Search the contributors.
#   $pattern : a Perl regular expression
#   $roles   : 'all' or a role number (1 artist, 2 composer, 3 conductor ...)
#   $opts    : { caseSensitive => 0|1, searchKey => 'name'|'sortkey' }
#              searchKey names the column of the match: the name as written,
#              or its sort key (last name first, both in lower case).
# Returns { rows => [ { nr, name, role, roleTokens, albums, tracks, mapping } ],
#           count, pattern, key, error }
sub queryContributors {
	my ($pattern, $roles, $opts) = @_;
	$opts ||= {};
	return { error => 'database not initialised', rows => [], count => 0 } unless $DBH;

	$pattern = '' unless defined $pattern;
	# the names of the database are UTF-8 bytes: the pattern is turned into
	# bytes as well, so that both speak the same language
	$pattern = _bytes($pattern);
	$pattern =~ s/^\s+|\s+$//g;
	return { error => 'no pattern', rows => [], count => 0 } if $pattern eq '';

	# the pattern is a regular expression; the match ignores the case unless
	# the page asks for a case sensitive search
	my $re = $opts->{'caseSensitive'}
		? eval { qr/$pattern/ }
		: eval { qr/$pattern/i };
	if (!$re) {
		logError("LibraryMapper search: invalid regular expression '$pattern'");
		return { error => 'invalid regular expression', rows => [], count => 0, pattern => $pattern };
	}

	# where the pattern has to match: the name as written, or the sort key
	# ("davis, miles" style) the artist is filed under
	my $onKey = (defined $opts->{'searchKey'} && lc $opts->{'searchKey'} eq 'sortkey') ? 1 : 0;

	# the role filter
	my %want;
	if (defined $roles && $roles ne '' && lc $roles ne 'all' && $roles ne '0') {
		for my $r ($roles =~ /(\d+)/g) { $want{0 + $r} = 1; }
	}

	my $rows = $DBH->selectall_arrayref(
		'SELECT name, role, albums, tracks FROM contributor_cache', { Slice => {} }) || [];

	# the sort keys of the names: computed once per spelling and shared
	# between the roles of the same spelling
	_sortkey();
	my %sortKeyOf;
	if ($onKey) {
		for my $r (@$rows) {
			next unless defined $r->{'name'} && $r->{'name'} ne '';
			next if exists $sortKeyOf{ $r->{'name'} };
			$sortKeyOf{ $r->{'name'} } =
				Plugins::LibraryMapper::SortKey::artistSortKey($r->{'name'});
		}
	}

	my %byName;
	for my $r (@$rows) {
		next unless defined $r->{'name'} && $r->{'name'} ne '';
		next if %want && !$want{ $r->{'role'} };
		if ($onKey) {
			my $key = $sortKeyOf{ $r->{'name'} };
			next unless defined $key && $key ne '' && $key =~ $re;
		}
		else {
			next unless $r->{'name'} =~ $re;
		}
		my $e = $byName{ $r->{'name'} };
		if (!$e) {
			$e = $byName{ $r->{'name'} } = {
				name => $r->{'name'}, role => $r->{'role'},
				albums => 0, tracks => 0, roles => {} };
		}
		$e->{'albums'} += $r->{'albums'} || 0;
		$e->{'tracks'} += $r->{'tracks'} || 0;
		$e->{'roles'}{ $r->{'role'} } = 1;
		$e->{'role'} = $r->{'role'} if $r->{'role'} < $e->{'role'};
	}

	# alphabetical order: a person under its last name, a group under the
	# name it carries; then numbered: the number is the reference
	my @out = sort {
		my $ka = Plugins::LibraryMapper::SortKey::artistSortKey($a->{'name'});
		my $kb = Plugins::LibraryMapper::SortKey::artistSortKey($b->{'name'});
		$ka cmp $kb || lc($a->{'name'}) cmp lc($b->{'name'});
	} values %byName;

	my $style = $prefs->get('artistNameStyle') || 'firstlast';
	my $nr = 0;
	_mapping();
	for my $e (@out) {
		$e->{'nr'} = ++$nr;
		# the key the name is filed under: it shows the user where the
		# artist will end up in the alphabetical order
		$e->{'sortKey'} = Plugins::LibraryMapper::SortKey::artistSortKey($e->{'name'});
		$e->{'roleTokens'} = [ map { roleToken($_) } sort { $a <=> $b } keys %{ $e->{'roles'} } ];
		$e->{'mapping'} = Plugins::LibraryMapper::Mapping::roleCanonical(
			$e->{'name'}, $e->{'role'}, $style);
	}

	# keep the result: the numbers are the references of the mapping
	$DBH->begin_work;
	$DBH->do('DELETE FROM query_results');
	my $ins = $DBH->prepare(
		'INSERT OR REPLACE INTO query_results(nr, name, role, roles, albums, tracks) VALUES (?,?,?,?,?,?)');
	for my $e (@out) {
		$ins->execute($e->{'nr'}, $e->{'name'}, $e->{'role'},
			join(',', @{ $e->{'roleTokens'} }), $e->{'albums'}, $e->{'tracks'});
	}
	$ins->finish;
	$DBH->commit;

	return {
		rows    => \@out,
		count   => scalar @out,
		pattern => $pattern,
		key     => ($onKey ? 'sortkey' : 'name'),
	};
}

# The result of the last search, with the current mapping of every row.
sub lastQueryResults {
	return [] unless $DBH;
	my $rows = $DBH->selectall_arrayref(
		'SELECT nr, name, role, roles, albums, tracks FROM query_results ORDER BY nr',
		{ Slice => {} }) || [];
	my $style = $prefs->get('artistNameStyle') || 'firstlast';
	_mapping();
	_sortkey();
	for my $r (@$rows) {
		my @roles = grep { $_ =~ /^\d+$/ } split /,/, ($r->{'roles'} // '');
		$r->{'roleTokens'} = @roles ? [ map { 0 + $_ } @roles ] : [ $r->{'role'} ];
		$r->{'mapping'} = Plugins::LibraryMapper::Mapping::roleCanonical(
			$r->{'name'}, $r->{'role'}, $style);
		# the key the name is filed under (the column can show where the
		# artist ends up in the alphabetical order)
		$r->{'sortKey'} = Plugins::LibraryMapper::SortKey::artistSortKey($r->{'name'});
	}
	return $rows;
}

# The name of a search result, by its reference number.
sub queryResultName {
	my ($nr) = @_;
	return '' unless $DBH;
	return '' unless defined $nr && $nr =~ /^\d+$/;
	my ($name) = $DBH->selectrow_array('SELECT name FROM query_results WHERE nr=?', undef, $nr);
	return $name || '';
}

# Apply a mapping to one search result.  $ref is the reference number of the
# row (or the name itself).  An empty canonical name clears the mapping.
sub setContributorMapping {
	my ($ref, $canonical, $role) = @_;
	return 0 unless $DBH;
	return 0 unless defined $ref && $ref ne '';

	my ($name, $useRole);
	if ($ref =~ /^\d+$/ && $ref > 0) {
		my $row = $DBH->selectrow_hashref(
			'SELECT name, role FROM query_results WHERE nr=?', undef, $ref);
		return 0 unless $row;
		$name = $row->{'name'};
		$useRole = $row->{'role'};
	}
	else {
		$name = $ref;
		$useRole = ($role && $role =~ /^\d+$/) ? 0 + $role : 1;
	}
	$useRole = 1 unless $useRole;
	$canonical = '' unless defined $canonical;
	# the name comes from the page: it is turned into UTF-8 bytes, because
	# that is what the database speaks
	$canonical = _bytes($canonical);
	$canonical =~ s/^\s+|\s+$//g;

	# the mapping cell accepts the number of another row as a reference:
	# "12" means "the name of row 12"
	if ($canonical =~ /^\d+$/ && $canonical > 0 && !($ref =~ /^\d+$/ && $ref == $canonical)) {
		my ($other) = $DBH->selectrow_array(
			'SELECT name FROM query_results WHERE nr=?', undef, $canonical);
		$canonical = $other if defined $other && $other ne '';
	}

	if ($canonical eq '') {
		$DBH->do('DELETE FROM contributor_mappings WHERE role=? AND variant=?',
			undef, $useRole, _fold($name));
	}
	else {
		$DBH->do('INSERT OR REPLACE INTO contributor_mappings(role, variant, canonical, updated_at) VALUES (?,?,?,?)',
			undef, $useRole, _fold($name), $canonical, time());
	}
	# an artist mapping is also the artist spelling correction: the tree
	# shows the corrected name
	if ($useRole == 1) {
		setArtistCanonical(_fold($name), $canonical);
		# a corrected artist changes the tree: re-resolve from the cached credits
		refreshTree();
	}
	return 1;
}

# The number of items a level of the tree shows.
#
# The value comes from the page of the plugin or from the tree: it is a
# number ("100"), the word "unlimited" or the word "default".  The last one
# means that the preference of the plugin decides, exactly like a missing
# value does.
sub _limitOf {
	my ($value) = @_;
	# the preference holds a choice, not a number: "unlimited" (the user can
	# choose it on the page) is a word, and SQLite binds such a word as LIMIT
	# 0 — every level of the walk would come back empty.  The preference is
	# normalised first, the choice is checked the same way.
	my $pref = $prefs->get('listLimit') || '';
	if ($pref eq 'unlimited' || $pref eq 'all' || $pref eq '0') { $pref = UNLIMITED }
	elsif ($pref !~ /^\d+$/ || $pref <= 0) { $pref = 100 }
	return $pref unless defined $value && $value ne '';
	return UNLIMITED if $value eq 'unlimited' || $value eq 'all' || $value eq '0';
	return $value if $value =~ /^\d+$/ && $value > 0;
	return $pref;
}

# ------------------------------------------------------------------ genre icons
# One small icon per genre group, shown in the tree (Simplified View) and on
# the page (genre level).  The icons are instrument drawings of the icons8
# "Windows 8" set, recoloured into one muted colour each (t\make_genre_icons.ps1).
#
# The *key* of an icon is the name of the group with everything but letters
# and digits taken away ("Soul/R&B" -> "soulrb"), so that a spelling variant
# of a group name finds the same icon.  The aliases map the customary group
# names onto the icons that are shipped; anything unknown shows the neutral
# treble clef ("default").
my %GENRE_FILES = (
	classical  => 1,
	jazz       => 1,
	rock       => 1,
	pop        => 1,
	blues      => 1,
	hiphop     => 1,
	electronic => 1,
	folk       => 1,
	soul       => 1,
	soundtrack => 1,
);

my %GENRE_ALIAS = (
	prog        => 'rock',
	metal       => 'rock',
	punk        => 'rock',
	indie       => 'rock',
	alternative => 'rock',
	grunge      => 'rock',
	hardrock    => 'rock',
	rap         => 'hiphop',
	trap        => 'hiphop',
	grime       => 'hiphop',
	techno      => 'electronic',
	house       => 'electronic',
	trance      => 'electronic',
	edm         => 'electronic',
	electro     => 'electronic',
	ambient     => 'electronic',
	synthwave   => 'electronic',
	dnb         => 'electronic',
	world       => 'folk',
	celtic      => 'folk',
	trad        => 'folk',
	ethnic      => 'folk',
	soulrb      => 'soul',
	rnb         => 'soul',
	funk        => 'soul',
	gospel      => 'soul',
	motown      => 'soul',
	chanson     => 'pop',
	disco       => 'pop',
	variety     => 'pop',
	ost         => 'soundtrack',
	score       => 'soundtrack',
);

# The file of the icon of a genre group, without the extension: the base
# name of one of the shipped PNGs of html/images/genre/, or "default".
sub genreIconFile {
	my ($key) = @_;
	return 'default' unless defined $key && $key ne '';
	# the pseudo groups ("All artists", "All albums", "Random") are no
	# genres: they carry the double quaver, not the neutral drawing of the
	# others
	return 'notes' if $key eq '*' || $key eq '%%' || $key eq '@@';
	return _iconKey($key) if $GENRE_FILES{_iconKey($key)};
	return 'default';
}

# The key of the icon of a genre group: the name of the group with everything
# but letters and digits taken away, then through the aliases.  The same key
# answers for the shipped icons and for the icons the user uploaded.
sub _iconKey {
	my ($key) = @_;
	return '' unless defined $key;
	my $k = lc $key;
	$k =~ s/[^a-z0-9]//g;
	return $GENRE_ALIAS{$k} // $k;
}

# ---------------------------------------------------------------- icon pack
#
# The user uploads the icons of the genre groups on the parameter page as a
# zip archive: one file per group, named after the group
# (<genre>.png, <genre>.gif or <genre>.ico — "Classical.png", "Jazz.gif"...).
# The archive is unpacked into <persist dir>/icons, a folder that survives a
# restart the way the database does.  An uploaded icon replaces the shipped
# drawing of the same group; every group without an uploaded icon keeps the
# shipped drawing (or the neutral treble clef).

# The folder of the uploaded icons.
sub iconDir {
	# the tests hand the folder over with LM_ICON_DIR: the plugin runs without
	# a server there
	return $ENV{'LM_ICON_DIR'} if $ENV{'LM_ICON_DIR'};
	my $dir = File::Spec->catdir(_persistDir(), 'icons');
	mkdir $dir unless -d $dir;
	return $dir;
}

my %CUSTOM_ICONS;   # normalized key -> file name (with its extension)

# Walk the folder of the uploaded icons: one entry per icon file.  The name
# of the file goes through the same key as the group itself ("Classical.png"
# and "Classical Music.png" answer for the group "Classical").  The group of
# the albums without a genre is named "Unclassified"; "Default" is accepted
# in its place, but "Unclassified" wins when both are there.
sub refreshIcons {
	%CUSTOM_ICONS = ();
	my $dir = iconDir();
	return unless -d $dir;

	opendir(my $dh, $dir) or return;
	for my $name (sort readdir($dh)) {
		next unless $name =~ /\A([A-Za-z0-9][A-Za-z0-9_.\- ]*?)\.(png|gif|ico|jpg|jpeg)\z/i;
		my $k = _iconKey($1);
		if ($k eq 'default') { $k = 'unclassified' }
		# "Default.png" does not push "Unclassified.png" out of its slot
		next if $k eq 'unclassified' && $CUSTOM_ICONS{$k} && $1 !~ /^unclassified/i;
		$CUSTOM_ICONS{$k} = $name;
	}
	closedir($dh);
	return 1;
}

# The file name of an uploaded icon of a genre group, with its extension, or
# undef when the group has none (the shipped drawing is used then).  The key
# "" (the group of the albums without a genre) answers for the file that is
# named "Unclassified" or "Default".
sub customIconFile {
	my ($key) = @_;
	my $k = (!defined $key || $key eq '') ? 'unclassified' : _iconKey($key);
	return $CUSTOM_ICONS{$k};
}

# The list of the uploaded icons, for the parameter page.
sub listCustomIcons {
	return [ map { { key => $_, file => $CUSTOM_ICONS{$_} } } sort keys %CUSTOM_ICONS ];
}

# Drop every uploaded icon: the shipped drawings are used again.
sub clearIcons {
	my $dir = iconDir();
	return unless -d $dir;
	opendir(my $dh, $dir) or return;
	my @files = grep { /\.(png|gif|ico|jpg|jpeg)\z/i } readdir($dh);
	closedir($dh);
	for my $f (@files) {
		unlink File::Spec->catfile($dir, $f);
	}
	%CUSTOM_ICONS = ();
	return 1;
}

# The pattern of an allowed icon name: the folders the member may sit in
# (plain single names, without dots) and the file itself:
# <genre>.png / .gif / .ico / .jpg / .jpeg.  Anything else in the archive is
# ignored — and no name can walk out of the icon folder ("../evil.png" has a
# "." in its folder part and is refused).
my $ICON_NAME_RE = qr/\A(?:[A-Za-z0-9\- ]+[\/\\])*([A-Za-z0-9][A-Za-z0-9\- ]*?)\.(png|gif|ico|jpg|jpeg)\z/i;

# Unpack an uploaded icon pack and return (added, error).  The archive is
# read with IO::Uncompress::Unzip (a module of the perl core: no dependency
# of the server on it).
sub extractIconPack {
	my ($bytes) = @_;
	return (0, 'empty') unless defined $bytes && length $bytes;
	return (0, 'toolarge') unless length $bytes <= 16 * 1024 * 1024;

	my $dir = iconDir();
	mkdir $dir unless -d $dir;

	require IO::Uncompress::Unzip;
	my $uz = eval {
		IO::Uncompress::Unzip->new(\$bytes, Transparent => 0)
	} or return (0, 'notazip');

	my $added = 0;
	for (my $status = 1; $status > 0 && $added < 64; $status = $uz->nextStream()) {
		# the header of the member holds its name (IO::Uncompress API)
		my $name = eval { $uz->getHeaderInfo()->{'Name'} } || '';
		next unless $name =~ $ICON_NAME_RE;
		my $good = $1 . '.' . $2;

		# the read of this module appends into the buffer and it empties it
		# at the end of the member: the content is accumulated in one string
		# of its own
		my $data = '';
		while ((my $rc = $uz->read(my $chunk)) > 0) {
			$data .= $chunk;
			last if length $data > 2 * 1024 * 1024;   # never read a huge member in
		}
		next unless length $data && length $data <= 2 * 1024 * 1024;

		eval {
			open(my $fh, '>', File::Spec->catfile($dir, $good)) or die $!;
			binmode $fh;
			print $fh $data;
			close $fh;
			1;
		} or next;
		$added++;
	}

	refreshIcons()
		or logError('LibraryMapper: cannot read the icon folder ' . iconDir());
	$log->info("LibraryMapper: icon pack unpacked, $added icon(s)");
	return ($added, undef);
}

# One icon uploaded on its own (not in an archive): it is stored under its
# name and it replaces the drawing of that group.  Returns 1 or 0.
sub storeIcon {
	my ($name, $bytes) = @_;
	return 0 unless defined $name && defined $bytes && length $bytes;
	return 0 unless $name =~ $ICON_NAME_RE;
	my $good = $1 . '.' . $2;
	return 0 unless length $bytes <= 2 * 1024 * 1024;

	my $dir = iconDir();
	mkdir $dir unless -d $dir;
	eval {
		open(my $fh, '>', File::Spec->catfile($dir, $good)) or die $!;
		binmode $fh;
		print $fh $bytes;
		close $fh;
		1;
	} or return 0;
	refreshIcons();
	return 1;
}

# The bytes of the icon of a genre group: the uploaded icon when the user has
# given the group one, the shipped drawing otherwise, and an empty picture
# (a transparent dot, so that the layout of the pages holds) when nothing is
# there at all.  Returns { data => ..., type => "image/..." }.
my %ICON_TYPES = (
	png  => 'image/png',
	gif  => 'image/gif',
	ico  => 'image/x-icon',
	jpg  => 'image/jpeg',
	jpeg => 'image/jpeg',
);

my $BLANK_GIF = 'GIF89a' . pack('vvv', 1, 1, 0x80)
	. "\x00\x00\x00\xff\xff\xff"
	. "\x21\xf9\x04\x01\x00\x00\x00\x00"
	. "\x2c\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02\x44\x01\x00\x3b";

sub iconBytes {
	my ($raw) = @_;
	$raw = '' unless defined $raw;
	my $dir = iconDir();
	my $file = customIconFile($raw);

	if ($file) {
		my $path = File::Spec->catfile($dir, $file);
		my $data = _slurpFile($path);
		if (defined $data) {
			(my $ext = lc $file) =~ s/.*\.//;
			return { data => $data, type => $ICON_TYPES{$ext} || 'image/png' };
		}
		logError("LibraryMapper: the icon file cannot be read: $path");
	}

	# the shipped drawing of the group (or the treble clef "default"): it
	# lives in the HTML folder of the plugin, beside the modules
	my $base = genreIconFile($raw);
	my $path = File::Spec->catfile(dirname(__FILE__), 'HTML', 'EN', 'plugins',
		'LibraryMapper', 'html', 'images', 'genre', "$base.png");
	my $data = _slurpFile($path);
	return { data => $data, type => 'image/png' } if defined $data;

	return { data => $BLANK_GIF, type => 'image/gif' };
}

# the bytes of a small file (undef when it is not there)
sub _slurpFile {
	my ($path) = @_;
	return undef unless defined $path && -f $path;
	open(my $fh, '<', $path) or return undef;
	binmode $fh;
	local $/;
	my $data = <$fh>;
	close $fh;
	return defined $data ? $data : '';
}

# virtual browse: categories query only.
# Returns { type, rows, title } where:
#   level  -> list of { key, n }          (genres, or artists within a genre)
#   albums -> list of album rows          (within a genre + artist)
#   tracks -> list of tracks (disc/tracknum order) of ONE album
sub browse {
	my %args = @_;
	return { type => 'level', rows => [], title => '' } unless $DBH;
	_wipeIfNeeded();
	my $limit = _limitOf($args{'list'});
	my $order = $args{'order'} || 'alpha';
	my $groupOrder = $args{'groupOrder'} || 'alpha';
	my $filterSql = ' WHERE 1=1';
	my @filterP;
	if (my $t = $args{'time'}) {
		if ($t ne 'all') { $filterSql .= ' AND a.added >= ?'; push @filterP, _timeStart($t); }
	}
	if (my $q = $args{'quality'}) {
		if ($q ne 'all') { $filterSql .= ' AND a.quality = ?'; push @filterP, $q; }
	}

	# The filter expression: a small language of conditions beside the
	# regular expression of the artists (the terms are read at the level,
	# where the tags of that level are known).
	my $expr = exists $args{'expr'} ? $args{'expr'} : '';
	$expr = '' unless defined $expr;
	$expr = _bytes($expr);
	$expr =~ s/^\s+|\s+$//g;
	my $exprError = '';

	# The translit of the artist filter: the letters of the pattern match
	# their accent-carrying variants ("e" matches "é" as well).  The pattern
	# and the names are compared on their accent-free forms.
	my $filterFold = $args{'filterTranslit'} ? 1 : 0;

	# The artist filter is a regular expression: it selects the artists of
	# the current genre group.
	my $pattern = $args{'filter'};
	$pattern = '' unless defined $pattern;
	# the pattern is matched against the names of the database, which are
	# UTF-8 bytes: it is turned into bytes as well
	$pattern = _bytes($pattern);
	$pattern =~ s/^\s+|\s+$//g;
	my $filterRe;
	my $filterError = 0;
	if ($pattern ne '') {
		if ($filterFold) {
			# the pattern matches the accent-free form of the names
			my $folded = _foldName($pattern);
			$filterRe = eval { qr/$folded/i };
		}
		else {
			$filterRe = eval { qr/$pattern/i };
		}
		if (!$filterRe) {
			logError("LibraryMapper browse: invalid artist filter '$pattern'");
			$filterRe = undef;
			$filterError = 1;
		}
	}

	# The drill-down path is "genre|artist|album_id":
	#   1 element  - the genre groups
	#   2 elements - the artists of one genre group
	#   3 elements - the albums of one artist within one genre group
	# and the album id identifies the tracks.
	#
	# The path arrives as characters (the server decodes the parameters of the
	# request): it is turned back into UTF-8 bytes, so that it can be
	# compared with the names of the database.
	if (my $p = _bytes($args{'parent'})) {
		my @path = split /\|/, $p;
		if (@path >= 3) {
			# drill into an album: tracks in disc / track-number order.
			# The tracks of one album are never cut short: the "items shown"
			# preference applies to the levels of the tree, not to the
			# content of an album.
			my $rows = $DBH->selectall_arrayref(qq{
				SELECT title, tracknum, disc, quality, track_id, url FROM tracks_cache
				WHERE album_id = ?
				ORDER BY COALESCE(disc,1), COALESCE(tracknum,9999), title
				LIMIT 10000}, { Slice => {} }, $path[2]);
			# the name of the album: the last step of the path is the id of
			# the album, the breadcrumb of the page shows its name
			my $an = eval { scalar $DBH->selectrow_array(
				'SELECT name FROM albums_cache WHERE album_id = ?', undef, $path[2]) } || '';
			return { type => 'tracks', rows => $rows, title => $an, parent => $p,
			         filter => $pattern, filterError => $filterError,
			         filterTranslit => $filterFold,
			         expr => $expr, exprError => $exprError };
		}
		elsif (@path == 2) {
			# albums of one artist within one genre group — or of one artist
			# of the whole library, when the walk went through the pseudo
			# group "All artists" (the key "*" carries no genre at all)
			my $star  = $path[0] eq '*';
			my $genreCond  = $star ? '' : ' AND a.vpath_genre = ?';
			my $artistCond = ' AND l.artist = ?';
			# the terms of the expression, on the tags of the albums
			my $X = eval { _exprParse('albums', $expr) }
				|| { where => [], whereP => [], order => [], err => '' };
			$exprError = $X->{'err'};
			my $exprSql = join '', map { " AND $_" } @{ $X->{'where'} };
			# the sort of the expression is the order of the albums when
			# the user asked for one
			my $ordering = @{ $X->{'order'} }
				? join(', ', @{ $X->{'order'} }) . ', a.name ASC'
				: _albumOrdering($order);
			my $rows = _dressAlbums(
				$DBH->selectall_arrayref(qq{
					SELECT $ALBUM_COLS
					FROM albums_cache a
					JOIN album_artist_list l ON l.album_id = a.album_id
					$filterSql$genreCond$artistCond$exprSql
					ORDER BY $ordering LIMIT ?}, { Slice => {} },
						@filterP, ($star ? () : $path[0]), $path[1],
						@{ $X->{'whereP'} }, $limit),
				($star ? '*' : undef));
			return { type => 'albums', rows => $rows, title => $path[1], parent => $p,
			         filter => $pattern, filterError => $filterError,
			         filterTranslit => $filterFold,
			         expr => $expr, exprError => $exprError };
		}
		elsif ($path[0]) {
			# artists within one genre group — or every artist of the
			# library when the walk went through the pseudo group
			# "All artists" (path[0] is "*", which is no genre at all)
			my $star = $path[0] eq '*';

			# The pseudo entry "Random" (key "@@"): a level of a few albums
			# drawn at random among the albums that match the selections and
			# the expression, whatever the artist, one single row per album.
			# The count of the draw is the choice of the 🎲 link.  The draw
			# is its own order: the sort of the expression has no place
			# here (it would pick the same albums every time).
			if ($path[0] eq '@@') {
				my $XR = eval { _exprParse('albums', $expr) }
					|| { where => [], whereP => [], order => [], err => '' };
				$exprError = $XR->{'err'};
				my $rSql = join '', map { " AND $_" } @{ $XR->{'where'} };
				my $rows = _dressAlbums(
					$DBH->selectall_arrayref(qq{
						SELECT $ALBUM_COLS
						FROM albums_cache a
						JOIN (SELECT album_id, artist FROM album_artist_list
						      GROUP BY album_id) l ON l.album_id = a.album_id
						$filterSql$rSql
						ORDER BY RANDOM() LIMIT ?}, { Slice => {} },
							@filterP, @{ $XR->{'whereP'} }, _randomCountOf(\%args)),
					'@@');
				return { type => 'albums', rows => $rows, title => '@@', parent => $p,
				         filter => $pattern, filterError => $filterError,
				         filterTranslit => $filterFold,
				         expr => $expr, exprError => $exprError };
			}

			# The pseudo entry "All albums" (key "%%"): it is a shortcut,
			# not a genre.  Its level is the list of every album that
			# matches the selections, whatever the artist — one single row
			# per album (an album filed under several artists is listed
			# once, unlike the walks, which list it under every artist).
			# The albums keep the pseudo group in their path, so the
			# drill-down walks on there (the id of the album is enough for
			# the level of the tracks).
			if ($path[0] eq '%%') {
				my $XA = eval { _exprParse('albums', $expr) }
					|| { where => [], whereP => [], order => [], err => '' };
				$exprError = $XA->{'err'};
				my $eSql = join '', map { " AND $_" } @{ $XA->{'where'} };
				# the sort of the expression is the order of the albums when
				# the user asked for one
				my $ordering = @{ $XA->{'order'} }
					? join(', ', @{ $XA->{'order'} }) . ', a.name ASC'
					: _albumOrdering($order);
				my $rows = _dressAlbums(
					$DBH->selectall_arrayref(qq{
						SELECT $ALBUM_COLS
						FROM albums_cache a
						JOIN (SELECT album_id, artist FROM album_artist_list
						      GROUP BY album_id) l ON l.album_id = a.album_id
						$filterSql$eSql
						ORDER BY $ordering LIMIT ?}, { Slice => {} },
							@filterP, @{ $XA->{'whereP'} }, $limit),
					'%%');
				return { type => 'albums', rows => $rows, title => '%%', parent => $p,
					filter => $pattern, filterError => $filterError,
					filterTranslit => $filterFold,
					expr => $expr, exprError => $exprError };
			}

			my $genreCond = $star ? '' : ' AND a.vpath_genre = ?';
			# the terms of the expression: the plain conditions go into
			# WHERE, the ones on the aggregates (number of albums, total
			# duration) into HAVING
			my $X = eval { _exprParse('artists', $expr) }
				|| { where => [], whereP => [], having => [], havingP => [], order => [], err => '' };
			$exprError = $X->{'err'};
			my $exprSql = join '', map { " AND $_" } @{ $X->{'where'} };
			my $exprHaving = join '', map { " AND $_" } @{ $X->{'having'} };
			# the sort of the expression is an order of the SQL (the sort
			# key of the artists applies only when the user asked for none)
			my $orderSql = @{ $X->{'order'} }
				? ' ORDER BY ' . join(', ', @{ $X->{'order'} }) . ', l.artist ASC' : '';
			# the regular expression narrows the list down in perl: no
			# LIMIT in the SQL when it is there, the cut happens after
			my $limitSql = ($orderSql && !$filterRe) ? ' LIMIT ?' : '';
			my $rows = $DBH->selectall_arrayref(qq{
				SELECT l.artist AS key, COUNT(DISTINCT a.album_id) AS n,
				       MAX(a.added) AS lastadded, SUM(a.duration) AS dur,
				       MAX(a.year) AS lastyear
				FROM album_artist_list l
				JOIN albums_cache a ON a.album_id = l.album_id
				$filterSql$genreCond$exprSql
				GROUP BY l.artist
				HAVING COUNT(DISTINCT a.album_id) > 0$exprHaving$orderSql$limitSql},
				{ Slice => {} }, @filterP, ($star ? () : $path[0]),
				@{ $X->{'whereP'} }, @{ $X->{'havingP'} }, ($limitSql ? $limit : ()));
			# the order of the artists follows the order of the albums: the
			# alphabetical one, or the date of the last album of the artist
			# when the user asked for the most recent first (the sort of the
			# expression, when there is one, was applied by the SQL)
			$rows = _sortArtists($rows, $order) unless $orderSql;
			# the regex filter narrows the list down.  With the translit
			# turned on, the pattern is compared with the computed sort key
			# of the name (the name is transliterated there and filed under
			# its last name: "Чайковский" is filed as "chaikovskii"), and
			# with the accent-free form of the name as well, so that a
			# search on the name as written keeps finding it.
			if ($filterRe) {
				if ($filterFold) {
					_sortkey();
					$rows = [ grep {
						my $key = eval {
							Plugins::LibraryMapper::SortKey::artistSortKey($_->{'key'})
						} || '';
						_foldName($_->{'key'}) =~ $filterRe || $key =~ $filterRe;
					} @$rows ];
				}
				else {
					$rows = [ grep { $_->{'key'} =~ $filterRe } @$rows ];
				}
			}
			$rows = [ @{$rows}[ 0 .. $limit - 1 ] ] if @$rows > $limit;
			return { type => 'level', rows => $rows, title => $path[0], parent => $p,
			         level => 'artists',
			         filter => $pattern, filterError => $filterError,
			         filterTranslit => $filterFold,
			         expr => $expr, exprError => $exprError };
		}
	}

	# top: genre groups
	#
	# A group that holds no album is not shown: the tree only offers what can
	# really be opened.  The group of the albums that carry no genre at all
	# is not a genre either: it is hidden unless the user asks for it on the
	# parameter page.
	my $noGenreSql = '';
	my @noGenreP;
	unless ($prefs->get('showUnclassified')) {
		$noGenreSql = ' AND LOWER(a.vpath_genre) NOT IN ('
			. join(',', ('?') x scalar(@NO_GENRE)) . ')';
		@noGenreP = @NO_GENRE;
	}
	my $groupOrdering = _groupOrdering($groupOrder);
	# the terms of the expression, on the tags the level of the groups has
	# (no artist is joined here)
	my $GX = eval { _exprParse('groups', $expr) } || { where => [], whereP => [], order => [], err => '' };
	$exprError = $GX->{'err'};
	my $gExprSql = join '', map { " AND $_" } @{ $GX->{'where'} };
	my $rows = $DBH->selectall_arrayref(qq{
		SELECT a.vpath_genre AS key, COUNT(DISTINCT a.album_id) AS n
		FROM albums_cache a$filterSql$gExprSql$noGenreSql
		GROUP BY a.vpath_genre
		HAVING COUNT(DISTINCT a.album_id) > 0
		ORDER BY $groupOrdering LIMIT ?},
		{ Slice => {} }, @filterP, @{ $GX->{'whereP'} }, @noGenreP, $limit);
	# the group of the albums that carry no genre is marked: it is shown
	# under a name that says it
	for my $r (@$rows) {
		$r->{'unclassified'} = 1 if _isNoGenre($r->{'key'});
	}
	# The pseudo group "All artists" (key "*"): it is not a genre at all, it
	# opens the list of every artist of the library, whatever group the
	# albums of that artist belong to.  It is always the first entry of the
	# level, and it is not cut short by the limit of the groups: it is the
	# entry point of the whole library.
	my $total = eval {
		scalar $DBH->selectrow_array(
			"SELECT COUNT(DISTINCT a.album_id) FROM albums_cache a$filterSql$gExprSql",
			undef, @filterP, @{ $GX->{'whereP'} })
	} || 0;
	# The pseudo entries on top of the list: "All artists" (the artists of
	# the whole library, whatever the group) and "All albums" (the
	# every-album level: every album that matches the selections, whatever
	# the artist, one row per album).  Like "*", the pseudo entry "%%" is
	# never cut short by the limit of the groups.
	unshift @$rows, { key => '@@', n => _randomCountOf(\%args), random => 1 } if $total;
	unshift @$rows, { key => '%%', n => $total, allalbums => 1 } if $total;
	unshift @$rows, { key => '*', n => $total, all => 1 }        if $total;
	return { type => 'level', rows => $rows, title => '', filter => $pattern,
	         level => 'genres', filterTranslit => $filterFold,
	         expr => $expr, exprError => $exprError };
}

# The count of the albums of the draw of the "Random" level: the choice of
# the 🎲 link (the page remembers it), the preference of the parameter page
# otherwise, 10 when neither is readable.
sub _randomCountOf {
	my $args = shift;
	my $rc = $args->{'randomCount'} // '';
	if ($rc =~ /^\d+$/ && $rc >= 1 && $rc <= 100) { return 0 + $rc; }
	$rc = $prefs->get('random_default') || '';
	return 0 + $rc if $rc =~ /^\d+$/ && $rc >= 1 && $rc <= 100;
	return 10;
}

# ------------------------------------------------------------ filter expression
#
# A small language of conditions beside the artist filter.  The terms, all
# of which must hold, are separated with whitespaces; a quote protects the
# spaces of a value:
#
#   year:1970..1995      a range of values ("-" works as well: 1980-1995)
#   year:70..95          two digits work too (70..95 is 1970..1995)
#   year>1990            the comparisons  =  !=  >  >=  <  <=
#   genre:(Jazz,Pop)     a list of values — equal to any of them
#   title~love           the value is contained in the text of the title
#   duration:45:00..1:30:00   the durations of the albums
#   added:2023..2024     the date an album was added to the library
#                        ("2023" means the first of January 2023: to keep
#                        the whole year write  added:2023..2023-12-31)
#   sort:duration-,title the order of the results ("-" = descending)
#
# Every term becomes a fragment of SQL with its values carried in
# placeholders: the expression never touches the database as text.
#
# The columns of every level: "albums" (the level of the albums of one
# artist, where the artists are joined), "groups" (the level of the genre
# groups, where no artist is joined) and "artists" (the level of the
# artists, where the aggregates live in HAVING).  The tag carries the kind
# of the value: "n" (a number), "s" (a duration in seconds), "d" (a date:
# the time a name like 2023-06 stands for) or "t" (a text).

my %EXPR_COLS = (
	albums => {
		# the kinds: n = a plain number, y = a year (the two-digit form
		# expands: 59 = 1959), s = a duration (h:mm, "1:00:00" or seconds),
		# d = a date (the epoch), t = a text
		year     => [ 'a.year',              'y' ],
		duration => [ 'a.duration',          's' ],
		title    => [ 'LOWER(a.name)',       't' ],
		artist   => [ 'LOWER(l.artist)',     't' ],
		genre    => [ 'LOWER(a.vpath_genre)','t' ],
		quality  => [ 'LOWER(a.quality)',    't' ],
		added    => [ 'a.added',             'd' ],
		album_id => [ 'a.album_id',          'n' ],
	},
	groups => {
		year     => [ 'a.year',              'y' ],
		duration => [ 'a.duration',          's' ],
		title    => [ 'LOWER(a.name)',       't' ],
		genre    => [ 'LOWER(a.vpath_genre)','t' ],
		quality  => [ 'LOWER(a.quality)',    't' ],
		added    => [ 'a.added',             'd' ],
		album_id => [ 'a.album_id',          'n' ],
	},
	artists => {
		artist   => [ 'LOWER(l.artist)',                      't' ],
		count    => [ 'COUNT(DISTINCT a.album_id)',           'n', 1 ],
		duration => [ 'COALESCE(SUM(a.duration), 0)',         's', 1 ],
		year     => [ 'MAX(a.year)',                          'y', 1 ],
		added    => [ 'MAX(a.added)',                         'd', 1 ],
	},
);

# The sort tags of the expression: the columns the results are ordered by.
# The "-" after a tag of the expression asks for the descending order.
my %EXPR_SORT = (
	albums => {
		year     => 'a.year',
		duration => 'a.duration',
		title    => 'a.name',
		artist   => 'l.artist',
		added    => 'a.added',
		genre    => 'a.vpath_genre',
	},
	artists => {
		artist   => 'l.artist',
		count    => 'COUNT(DISTINCT a.album_id)',
		duration => 'COALESCE(SUM(a.duration), 0)',
		year     => 'MAX(a.year)',
	},
);

# Parse one expression.  Returns a hash with the fragments of SQL:
#   where  : the plain conditions (placed in WHERE)
#   whereP : their placeholders, bound in the same order
#   having : the conditions on the aggregates of the level of the artists
#   havingP: their placeholders
#   order  : the columns of the sort term, with their ASC / DESC
#   err    : the first term the language does not understand ('' when all
#            terms are read)
sub _exprParse {
	my ($level, $expr) = @_;
	my %out = ( where => [], whereP => [], having => [], havingP => [],
	            order => [], err => '' );
	return \%out unless defined $expr;
	$expr =~ s/^\s+|\s+$//g;
	return \%out if $expr eq '';
	my $cols = $EXPR_COLS{$level} || $EXPR_COLS{'albums'};
	my $sorts = $EXPR_SORT{$level} || {};

	for my $term (_exprTerms($expr)) {
		# the sort term: the list of the tags, "-" = descending
		if ($term =~ /^sort:(.*)$/s) {
			my @spec = split /,/, $1;
			for my $t (@spec) {
				my $desc = ($t =~ s/-$//) ? ' DESC' : ' ASC';
				my $col = $sorts->{ lc $t };
				unless ($col) { $out{'err'} = $term unless $out{'err'}; last; }
				push @{ $out{'order'} }, $col . $desc;
			}
			next;
		}
		# the other terms: the tag, the operator and the value.  The two
		# forms of the value are accepted: "duration>45:00" (tag operator
		# value) and "duration:>45:00" (the colon of the tag keeps its
		# place, the comparison follows it).
		elsif ($term =~ /^([A-Za-z_]{2,})(>=|<=|!=|~=|=|>|<|~|:)(.*)$/s
			&& $cols->{ lc $1 }) {
			my ($name, $op, $val) = (lc $1, $2, $3);
			if ($op eq ':' && $val =~ /^(>=|<=|!=|~=|=|>|<|~)/
			                 && defined $cols->{$name}) {
				# the operator is written after the colon of the tag;
				# nothing to read otherwise (a range, a list, a value)
				my $op2 = $1;
				$op = $op2;
				$val = substr($val, length $op2);
			}
			_exprTerm($cols->{$name}[0], $cols->{$name}[1],
				$op, $val, $term, \%out, $cols->{$name}[2]);
		}
		# a term the language does not understand is reported, not thrown
		else {
			$out{'err'} = $term unless $out{'err'};
		}
	}
	return \%out;
}

# One condition term: builds its fragment of SQL (or records the error).
# The value is one of three shapes: a list, a range or a single value.
# One value in the SQL of a condition.  The values of the numeric tags
# (year, duration, count, date) are validated numbers: they are written in
# the SQL directly.  A written number takes its own type for SQLite, while
# a placeholder is bound as a TEXT value — and an INTEGER (the result of an
# aggregate in the HAVING, and the numeric column of the albums) would never
# reach a text value ("count >= 2" would be false for every artist).
sub _exprNumLit {
	my ($v) = @_;
	return $v if defined $v && $v =~ /^-?\d+(?:\.\d+)?$/;
	return undef;   # no number: left to the caller (a text, or not understood)
}

sub _exprTerm {
	my ($col, $kind, $op, $val, $term, $out, $agg) = @_;
	# a column of an aggregate (the COUNT, the SUM, the MAX of the level of
	# the artists) cannot live in a WHERE: its condition goes to the HAVING
	my $where = $agg ? $out->{'having'} : $out->{'where'};
	my $whereP = $agg ? $out->{'havingP'} : $out->{'whereP'};
	my $err = sub { $out->{'err'} = $term unless $out->{'err'}; };

	# one plain comparison: the comparison "col op <value>"; a number takes
	# its own type in the SQL, a text keeps the placeholder
	my $one = sub {
		my ($opword, $v) = @_;
		if (my $num = _exprNumLit($v)) {
			push @$where, "$col $opword $num";
		}
		else {
			push @$where, "$col $opword ?";
			push @$whereP, $v;
		}
	};
	# one comparison "<col> BETWEEN <v1> AND <v2>", the same way
	my $between = sub {
		my ($a, $b) = @_;
		my ($na, $nb) = (_exprNumLit($a), _exprNumLit($b));
		if (defined $na && defined $nb) {
			push @$where, "$col >= $na AND $col <= $nb";
		}
		else {
			push @$where, "$col >= ? AND $col <= ?";
			push @$whereP, $a, $b;
		}
	};

	# a list:  tag:(v 1,v2,v3)
	if ($val =~ /^\((.*)\)$/s) {
		unless ($op eq ':' || $op eq '=') { $err->(); return; }
		my @vals = split /(?<!\\),/, $1;
		@vals = map { my $v = $_; $v =~ s/^"|"$//g; trim($v); } @vals;
		unless (@vals) { $err->(); return; }
		my @vs = map { _exprVal($kind, $_) } @vals;
		# every value a readable one: numbers written in, texts bound
		if (grep { !defined } @vs) { $err->(); return; }
		my @lits = map { _exprNumLit($_) } @vs;
		if (grep { !defined } @lits) {
			# at least one text: every value keeps its placeholder
			push @$where, "$col IN (" . join(',', ('?') x @vs) . ')';
			push @$whereP, @vs;
		}
		else {
			push @$where, "$col IN (" . join(',', @lits) . ')';
		}
		return;
	}
	# a range:  tag:V1..V2   or  tag:V1-V2  (numbers, durations; a range of
	# dates must be written with the two dots, else "2023-06" would read
	# as an end of range)
	if ($op eq ':') {
		my ($a, $b);
		if ($kind ne 't' && $val =~ /^(.+?)\.\.(.+)$/) {
			($a, $b) = ($1, $2);
		}
		elsif ($kind eq 's' && $val =~ /^([\d:.]+)-([\d:.]+)$/) {
			($a, $b) = ($1, $2);
		}
		elsif ($kind eq 'n' && $val =~ /^([\d.]+)-([\d.]+)$/) {
			($a, $b) = ($1, $2);
		}
		elsif ($kind eq 'y' && $val =~ /^([\d.]+)-([\d.]+)$/) {
			($a, $b) = ($1, $2);
		}
		if (defined $a) {
			my ($av, $bv) = (_exprVal($kind, $a), _exprVal($kind, $b));
			if (defined $av && defined $bv) {
				$between->($av, $bv);
				return;
			}
			# the shape of a range but no readable values: an error
			$err->();
			return;
		}
		# not a range after all: read as a single value ("2023-06-15")
	}
	# one value
	if ($op eq ':' || $op eq '=') {
		$one->('=', _exprVal($kind, $val));
	}
	elsif ($op eq '!=') {
		$one->('!=', _exprVal($kind, $val));
	}
	elsif ($op eq '>' || $op eq '>=' || $op eq '<' || $op eq '<=') {
		$one->($op, _exprVal($kind, $val));
	}
	elsif ($op eq '~' || $op eq '~=') {
		push @$where, "$col LIKE ?";
		push @$whereP, '%' . lc($val) . '%';
	}
	else {
		$err->();
	}
}

# trim a value of the expression
sub trim {
	my $s = shift || '';
	$s =~ s/^\s+|\s+$//g;
	return $s;
}

# One value of the expression, turned into the value the placeholder binds.
sub _exprVal {
	my ($kind, $val) = @_;
	return undef unless defined $val;
	# a quoted value keeps its spaces inside, the quotes themselves go
	$val =~ s/^"//; $val =~ s/"$//;
	$val =~ s/^\s+|\s+$//g;
	return _exprSeconds($val) if $kind eq 's';
	return _exprTime($val)    if $kind eq 'd';
	return lc $val            if $kind eq 't';
	if ($kind eq 'y') {
		# the two-digit form of a year: 59 = 1959, 12 = 2012; the values of
		# "2020..25" (a range of years in the two-digit form) come here too
		return $val >= 70 ? $val + 1900 : $val + 2000 if $val =~ /^\d{1,2}$/;
		return $val + 0 if $val =~ /^\d+$/;
		return undef;   # not a year: the term is not understood
	}
	if ($kind eq 'n') {
		return $val + 0 if $val =~ /^\d+(?:\.\d+)?$/;
		return undef;   # not a number: the term is not understood
	}
	return lc $val;
}

# The seconds of a duration: "3600" (plain seconds), "45:00"
# (minutes:seconds — the form the albums of the library are shown in) and
# "1:02:00" (hours:minutes:seconds).
sub _exprSeconds {
	my $v = shift || '';
	if ($v =~ /^(\d+):(\d{1,2}):(\d{1,2})$/) {
		return $1 * 3600 + $2 * 60 + $3;
	}
	if ($v =~ /^(\d+):(\d{1,2})$/) {
		return $1 * 60 + $2;
	}
	return $v + 0 if $v =~ /^\d+$/;
	return undef;   # not a duration: the term is not understood
}

# The time a date of the expression stands for: "2023", "2023-06" and
# "2023-06-15".  The noon of the day, so that the shifts of the time never
# pull the limit over to the day before or after.
sub _exprTime {
	my $v = shift || '';
	if ($v =~ /^(\d{4})(?:-(\d{1,2})(?:-(\d{1,2}))?)?$/) {
		my ($y, $m, $d) = ($1, $2 || 1, $3 || 1);
		my $t = eval { require Time::Local; Time::Local::timelocal(0, 0, 12, $d, $m - 1, $y - 1900) };
		return defined $t ? $t : $v;
	}
	return $v + 0 if $v =~ /^\d+$/;
	return $v;
}

# The terms of an expression: the whitespaces end a term, a quote protects
# the spaces of a value, "tag:(...)" is read whole.  The reader is a small
# loop, no regex gymnastics: the expressions come from the users.
sub _exprTerms {
	my $expr = shift;
	my @terms;
	my $i = 0;
	my $len = length $expr;
	while ($i < $len) {
		$i++ while $i < $len && substr($expr, $i, 1) =~ /\s/;
		last if $i >= $len;
		my $term = '';
		my $quote = 0;
		my $open = 0;     # the brackets opened and not closed yet
		while ($i < $len) {
			my $c = substr($expr, $i, 1);
			if ($c eq '"') { $quote = !$quote; $term .= '"'; $i++; next; }
			last if !$quote && $open == 0 && $c =~ /\s/;
			if ($c eq '(' && !$quote) { $open++; }
			elsif ($c eq ')' && !$quote && $open > 0) { $open--; }
			$term .= $c;
			$i++;
		}
		push @terms, $term if $term ne '';
	}
	return @terms;
}

# Does this name mean "no genre at all"?
sub _isNoGenre {
	my $name = shift;
	return 0 unless defined $name;
	$name = lc $name;
	$name =~ s/^\s+|\s+$//g;
	for my $n (@NO_GENRE) {
		return 1 if $name eq $n;
	}
	return 0;
}

# The order of the albums of one artist.
sub _albumOrdering {
	my $order = shift || 'alpha';
	return 'a.year DESC, a.name ASC'  if $order eq 'newer';
	return 'a.year ASC, a.name ASC'   if $order eq 'older';
	return 'a.added DESC, a.name ASC'  if $order eq 'added';
	return 'COALESCE(a.duration, 0) DESC, a.name ASC' if $order eq 'longest';
	return 'COALESCE(a.duration, 0) ASC, a.name ASC'  if $order eq 'shortest';
	# the number of albums is a notion of the higher level (the artists):
	# here it has no meaning, the albums stay alphabetical
	return 'a.name ASC';
}

# The order of the genre groups.
sub _groupOrdering {
	my $order = shift || 'alpha';
	return 'COUNT(DISTINCT a.album_id) DESC, a.vpath_genre ASC' if $order eq 'count';
	return 'COUNT(DISTINCT a.album_id) ASC, a.vpath_genre ASC'  if $order eq 'countasc';
	return 'a.vpath_genre ASC';
}

# The order of the artists.
#
# The alphabetical order is the usual one: a person is filed under its last
# name, a group under the name it carries ("Claude Nougaro" -> N,
# "Metallica" -> M).
#
# The other orders are the ones of the albums: the date of the last album
# added to the library ("newer" and "added" most recent first, "older"
# least recent first), the number of albums ("count" most albums first,
# "countasc" fewest first) and the total duration of the music of the
# artist ("longest" the most music first, "shortest" the least first).
# Whatever the order, a tie is settled alphabetically.
sub _sortArtists {
	my ($rows, $order) = @_;
	if ($order && ($order eq 'newer' || $order eq 'added')) {
		my @recent = sort {
			($b->{'lastadded'} || 0) <=> ($a->{'lastadded'} || 0)
				|| lc($a->{'key'}) cmp lc($b->{'key'})
		} @$rows;
		return \@recent;
	}
	if ($order && $order eq 'older') {
		my @oldest = sort {
			($a->{'lastadded'} || 0) <=> ($b->{'lastadded'} || 0)
				|| lc($a->{'key'}) cmp lc($b->{'key'})
		} @$rows;
		return \@oldest;
	}
	if ($order && ($order eq 'count' || $order eq 'countasc')) {
		my $asc = $order eq 'countasc' ? 1 : 0;
		my @bycount = sort {
			($asc ? $a->{'n'} <=> $b->{'n'} : $b->{'n'} <=> $a->{'n'})
				|| lc($a->{'key'}) cmp lc($b->{'key'})
		} @$rows;
		return \@bycount;
	}
	if ($order && ($order eq 'longest' || $order eq 'shortest')) {
		my $asc = $order eq 'shortest' ? 1 : 0;
		my @bydur = sort {
			($asc ? ($a->{'dur'} || 0) <=> ($b->{'dur'} || 0)
			      : ($b->{'dur'} || 0) <=> ($a->{'dur'} || 0))
				|| lc($a->{'key'}) cmp lc($b->{'key'})
		} @$rows;
		return \@bydur;
	}
	_sortkey();
	my @out = sort {
		my $ka = Plugins::LibraryMapper::SortKey::artistSortKey($a->{'key'});
		my $kb = Plugins::LibraryMapper::SortKey::artistSortKey($b->{'key'});
		$ka cmp $kb || lc($a->{'key'}) cmp lc($b->{'key'});
	} @$rows;
	return \@out;
}

sub _timeStart {
	my $what = shift;
	my $now = time();
	return $now - 86_400        if $what eq 'day';
	return $now - 7 * 86_400    if $what eq 'week';
	return $now - 30 * 86_400   if $what eq 'month';
	return $now - 365 * 86_400  if $what eq 'year';
	return 0;
}

# ----------------------------------------------------------- random albums

# The ids of some random albums of the library, honoring the filters (the
# date of the last additions, the class of quality) and the expression of
# the filter: used by the button of the page and by the CLI command
# (librarymapper randomadd).
sub randomAlbumIds {
	my %args = @_;
	return [] unless $DBH;
	_wipeIfNeeded();
	my $n = $args{'n'} || 10;
	$n = 100 if $n > 100;
	my $sql = ' WHERE 1=1';
	my @p;
	if (my $t = $args{'time'}) {
		if ($t ne 'all') { $sql .= ' AND a.added >= ?'; push @p, _timeStart($t); }
	}
	if (my $q = $args{'quality'}) {
		if ($q ne 'all') { $sql .= ' AND a.quality = ?'; push @p, $q; }
	}
	my $X = eval { _exprParse('albums', $args{'expr'} || '') }
		|| { where => [], whereP => [] };
	$sql .= join '', map { " AND $_" } @{ $X->{'where'} };
	push @p, @{ $X->{'whereP'} };
	my $rows = $DBH->selectall_arrayref(
		"SELECT a.album_id FROM albums_cache a$sql ORDER BY RANDOM() LIMIT ?",
		{ Slice => {} }, @p, $n);
	return [ map { $_->{'album_id'} } @$rows ];
}

# ------------------------------------------------------------- accent-free

# The accent-free form of a name: the combining marks are dropped, so that
# "é" and "e" are the same letter.  The names arrive as UTF-8 bytes (the
# language of the database) and leave as bytes again: everything is
# compared byte to byte, like everywhere else in the plugin.
sub _foldName {
	my $s = shift;
	return '' unless defined $s;
	utf8::decode($s) unless utf8::is_utf8($s);
	if (eval { require Unicode::Normalize; 1 }) {
		eval {
			$s = Unicode::Normalize::NFD($s);
			$s =~ s/\p{M}//g;
			$s = Unicode::Normalize::NFC($s);
			utf8::encode($s) if utf8::is_utf8($s);
			1;
		} or do {
			utf8::encode($s) if utf8::is_utf8($s);
			return $s;
		};
	}
	else {
		# no Normalize module: the accents stay, the translit is then
		# a plain search
		utf8::encode($s) if utf8::is_utf8($s);
	}
	return $s;
}

1;
