package Plugins::LibraryMapper::Browse;

use strict;

use MIME::Base64 ();

use Slim::Utils::Log qw(logger logError);
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(clientString string);

use Plugins::LibraryMapper::Data;

my $log   = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

use constant MODE => 'librarymapper';

# The virtual browse tree is exposed as a native LMS browse mode so that it
# shows up in "My Music" of every skin (Material Skin included) and can be
# walked with the standard LMS drill-down machinery.
#
# The drill-down path ("Genre|Artist|Year - Album") is carried in the
# "lm_path" parameter.  It is transported base64url encoded so that album
# titles containing spaces, commas, ampersands or colons survive every
# transport (CLI parameter lists, web query strings, JSON): a plain "|" in a
# request parameter would be read by Lyrion as a search tag.

sub feed {
	my ($client, $callback, $args, $pt) = @_;

	my $path = _path($args, $pt);

	# The order, the filters and the order of the groups travel with the
	# request: the node of "My Music" that the user picked carries them and
	# every item repeats them, so that the drill-down keeps them.
	my $order      = _param($args, 'lm_order')        || _param($args, 'order')
	                || $prefs->get('order_default')   || 'alpha';
	my $groupOrder = _param($args, 'lm_group_order') || $prefs->get('group_order')
	                || 'alpha';
	my $time       = _param($args, 'lm_time')        || $prefs->get('time_default')
	                || 'all';
	my $quality    = _param($args, 'lm_quality')     || $prefs->get('quality_default')
	                || 'all';

	# The number of items of a level: the choice of the user travels with the
	# request, so that it holds for the whole drill-down.  It is carried as a
	# *choice* ("default" included), never as the resolved number: when the
	# user has chosen nothing, the preference of the plugin decides, and that
	# must stay so down the tree.  The query itself resolves the choice (see
	# Data::_limitOf, which falls back to the preference for "default").
	my $limit = _limitMode(_param($args, 'lm_limit'));

	# The expression of the walk travels like the other choices.  It is free
	# text (spaces, commas, colons), which would break the "tag:value" list
	# of a CLI parameter: the tree carries it URL-encoded and the request
	# decodes it.  With no choice of its own, the preference of the
	# parameter page holds.
	my $expr = _param($args, 'lm_expr');
	if ($expr ne '') {
		$expr = _urldec($expr);
	}
	else {
		$expr = $prefs->get('expr_default') || '';
	}

	# The transliteration of the name filter travels as a plain flag; it is
	# pinned on every item, an explicit "off" must survive the drill-down
	# just like an "on".
	my $ft = _param($args, 'lm_ft');
	$ft = ($ft ne '' ? $ft : ($prefs->get('translit_default') ? 1 : 0));
	$ft = $ft ? 1 : 0;

	# The count of the albums of the draw (the "Random" level): a choice of
	# the page like the others (registered when the page of the step opens),
	# the preference of the parameter page otherwise.
	my $rnd = _randomMode(_param($args, 'lm_rnd'));

	# The choices travel no more: every level reads the preferences at its
	# request (the fallbacks above) — a pick applies to the whole tree, the
	# level the user came from included.  The parameters lm_order, lm_time,
	# ... stay honoured for the callers that send them (the CLI, the tests),
	# but the tree itself pins nothing.

	my $view = Plugins::LibraryMapper::Data::browse(
		parent     => $path,
		time       => $time,
		quality    => $quality,
		order      => $order,
		groupOrder => $groupOrder,
		list       => $limit,
		filter     => _param($args, 'filter'),
		expr       => $expr,
		filterTranslit => $ft,
		randomCount    => $rnd,
	);

	my $type = $view->{'type'} || 'level';
	my @items;

	# The walk rows come first (the header line stands at the end, see
	# below): the level the user lands on starts right at the top of the
	# list.
	if ($type eq 'level') {
		for my $row (@{ $view->{'rows'} }) {
			my $next = $path ? $path . '|' . $row->{'key'} : $row->{'key'};
			# the pseudo entries of the shortcuts are no genres at all: they
			# are shown under a name that says it.  "All artists" (key "*")
			# stands on top and lists every artist of the library; the
			# "%%" row lists every album matching the selections, whatever
			# the artist — the library-wide shortcut at the top of the tree
			# ("All albums"), the aggregate of the genre walked into
			# elsewhere ("Selected albums", see _levelLabel); "Random"
			# (key "@@") is the draw of a few albums, the count beside its
			# name.  The group of the albums that carry no genre is not a
			# genre either: it is shown under a name that says it too.
			my $label = _levelLabel($client, $row, $path);
			# the number of albums is shown beside the name: at the level of
			# the genre groups (every group, every pseudo group), and beside
			# the "%%" row of a walk ("Selected albums") — its count is the one of
			# the albums of the group under the selections (the draw already
			# carries its own count in its name)
			$label .= ' (' . $row->{'n'} . ')'
				if $row->{'n'} && !$row->{'random'} && (!$path || $row->{'allalbums'});
			# the first level is the level of the genre groups: every group
			# carries its icon (t\make_genre_icons.ps1)
			my $icon = $path ? undef : _genreIcon($row->{'unclassified'} ? '' : $row->{'key'});
			push @items, _levelItem($next, $label, $icon);
		}
	}
	elsif ($type eq 'albums') {
		for my $row (@{ $view->{'rows'} }) {
			# the path carries the album id: an album that belongs to several
			# artists is filed under each of them
			my $next = join('|', $row->{'vpath_genre'}, $row->{'vpath_artist'}, $row->{'album_id'});
			my $label = ($row->{'year'} ? $row->{'year'} . ' - ' : '') . _chars($row->{'name'});
			# the total duration of the album (the longest of the buckets of
			# the encodings), when the scan found one.  The middle dot is
			# written as the code point U+00B7 and not as a literal of the
			# file: the source is no UTF-8 text for perl, a literal of two
			# bytes would be read as the characters "Â·" when the label
			# (characters) meets it (bytes) — the trap of the double
			# encoding, seen on the pilot.
			$label .= '  ' . "\x{B7}" . '  ' . $row->{'durationText'} if $row->{'durationText'};
			push @items, _albumItem($next, $label, $row);
		}
	}
	elsif ($type eq 'tracks') {
		for my $row (@{ $view->{'rows'} }) {
			push @items, _trackItem($row);
		}
	}

	# The header comes last, as it did before the choices experiment: the
	# level the user lands on comes first, so the tree of the app opens on
	# its content at once — a header on top would make the app open on the
	# lone line of the selections.  The line shows the selections in use
	# (read out of the preferences at each request) and opens the page of
	# the plugin, where they can be changed.
	push @items, _headerItem($client, $path);

	# The "items" action walks one level down.  The path of the level is
	# carried by the "lm_path" parameter, which every item sets itself.  The
	# choices travel no more: a level carries the path only, the choices are
	# read from the preferences at every request (see above).
	my %actions = (
		commonVariables => [ 'lm_path' => 'id' ],
		items => {
			command     => [ 'browselibrary', 'items' ],
			fixedParams => { mode => MODE },
		},
	);

	$callback->({ items => \@items, actions => \%actions, sorted => 1 }, undef);
}

# The line of the selections, the last row of every level: the value of each
# choice, joined by a middle dot, as they stand in the preferences — and it
# opens the page of the plugin (filters + help), where they can be changed.
#
# The page and the tree share one source of truth: the preferences.  The URL
# carries no choice and no rnd — the page falls back to the preferences
# itself, so an old, remembered URL cannot re-register stale values over the
# picks of the tree (the page of the older releases wrote every choice it was
# handed into the preferences, so an old URL undid the picks of the tree).
# The level the user came from travels as "parent", so the page opens back on
# the step of that level (its breadcrumb and its filter scope).
#
# The URL is relative and of the "html" kind, so the Material skin opens the
# page *inside* the application, in an embedded window (its openWebLink
# embeds the relative links of the local server and opens only the external
# http(s) ones); the classic skins follow the same link.  A plain URL needs
# no replacement: the placeholders of the skins ({client}, ...) are not used.
sub _headerItem {
	my ($client, $path) = @_;
	my $order   = _choiceCurrent('o');
	my $time    = _choiceCurrent('t');
	my $quality = _choiceCurrent('q');
	my $limit   = _choiceCurrent('c');

	my $text = join(' ' . "\x{B7}" . ' ',
		_orderLabel($client, $order),
		_timeLabel($client, $time),
		_qualityLabel($client, $quality),
		_limitLabel($client, $limit),
	);

	# The query of the URL, in the "key=value" form: only the level and the
	# rail flag.  The first parameter is joined with a "?" (an older build
	# glued "&rail=1" onto a query-less URL, and the flag never reached the
	# page as a parameter).
	my @q;
	push @q, 'parent=' . _urlenc($path) if defined $path && $path ne '';
	# The rail (opt-in, parameter page): with it the page asks the Material
	# skin to dock itself beside the browse list instead of covering the
	# whole window; the small script at the end of the page does the rest.
	# Without the choice the page is the plain window it always was.
	push @q, 'rail=1' if $prefs->get('embedded_rail');
	my $url = '/plugins/LibraryMapper/index.html' . (@q ? '?' . join('&', @q) : '');

	return {
		name    => $text,
		title   => $text,
		id      => 'lm_header',
		type    => 'weblink',
		weblink => $url,
		# An attempt to give the header a "Play next" button that appends a
		# few random albums: the name of the "album_id" parameter (any value,
		# even 0) is what the Material skin looks for to show the button,
		# and the command is our own, which picks the albums and adds them.
		# The skin may still not build the button for a "weblink" item — the
		# page of the plugin keeps a link of its own for that.
		itemActions => {
			add => {
				command => [ 'librarymapper', 'randomadd' ],
				params  => { album_id => 0, n => ($prefs->get('random_default') || 10) },
			},
		},
	};
}

# a plain (not playable) entry of the virtual tree: a genre group, or an
# artist within a genre group.  A genre group carries its icon, an artist
# none ($icon undef there).  The walk carries the path only: the choices are
# read out of the preferences by the level that answers, no level pins them.
sub _levelItem {
	my ($path, $label, $icon) = @_;
	my $enc = _encode($path);
	my %item = (
		name        => $label,
		title       => $label,
		id          => $enc,
		type        => 'link',
		url         => \&feed,
		passthrough => [ { lm_path => $enc } ],
		itemActions => {
			items => _goAction($enc),
		},
	);
	$item{'icon'} = $icon if $icon;
	return \%item;
}

# The icon of a genre group: the one the user uploaded on the parameter page
# when the group has one (served by the icon endpoint), or an instrument
# drawing of the shipped icons8 pack otherwise (t\make_genre_icons.ps1).
# The path is relative: the client resolves it against the root of the server
# (Slim::Web::ImageProxy::proxiedImage lets the local paths through).
sub _genreIcon {
	my ($key) = @_;
	if (Plugins::LibraryMapper::Data::customIconFile($key)) {
		return 'plugins/LibraryMapper/icon.png?name=' . _urlenc($key);
	}
	return 'plugins/LibraryMapper/html/images/genre/'
		. Plugins::LibraryMapper::Data::genreIconFile($key) . '.png';
}

# an album: it can be played as such (Lyrion knows the album) and it can be
# opened to show its tracks
sub _albumItem {
	my ($path, $label, $row) = @_;
	my $enc = _encode($path);
	my %item = (
		name        => $label,
		title       => $label,
		id          => $enc,
		type        => 'playlist',
		playlist    => \&feed,
		url         => \&feed,
		passthrough => [ { lm_path => $enc } ],
		itemActions => {
			items  => _goAction($enc),
			play   => _playlistAction('load',   'album_id', $row->{'album_id'}),
			add    => _playlistAction('add',    'album_id', $row->{'album_id'}),
			insert => _playlistAction('insert', 'album_id', $row->{'album_id'}),
		},
	);
	# The cover art: the URL /music/<id>/cover wants the id of a *track*,
	# not the id of the album: the art of an album hangs on one of its
	# tracks (the "artwork" column of the albums table of Lyrion).
	my $art = $row->{'artwork_track_id'} || 0;
	if ($art) {
		$item{'artwork_track_id'} = $art;
		$item{'image'}            = 'music/' . $art . '/cover';
	}
	return \%item;
}

# one track of an album
sub _trackItem {
	my ($row) = @_;
	my $title = _chars($row->{'title'});
	return {
		name  => $title,
		title => $title,
		id    => $row->{'track_id'},
		type  => 'audio',
		play  => $row->{'url'},
		url   => $row->{'url'},
		itemActions => {
			play   => _playlistAction('load',   'track_id', $row->{'track_id'}),
			add    => _playlistAction('add',    'track_id', $row->{'track_id'}),
			insert => _playlistAction('insert', 'track_id', $row->{'track_id'}),
		},
	};
}

# the action used to walk one level down: browselibrary items mode:librarymapper
# with the path carried in the lm_path parameter — the path only, the choices
# are read out of the preferences by the level that answers
sub _goAction {
	my ($enc) = @_;
	return {
		command     => [ 'browselibrary', 'items' ],
		fixedParams => { mode => MODE, lm_path => $enc },
	};
}

# the value a group of choices currently holds, straight from the
# preferences (the strings the values of "default" resolve to are what the
# parameter page saves).  The line of the selections of the tree reads the
# four groups here; the choices themselves are picked on the page of the
# plugin only.
sub _choiceCurrent {
	my ($sec) = @_;
	if    ($sec eq 'o') { return $prefs->get('order_default')   || 'alpha'; }
	elsif ($sec eq 't') { return $prefs->get('time_default')    || 'all'; }
	elsif ($sec eq 'q') { return $prefs->get('quality_default') || 'all'; }
	elsif ($sec eq 'c') { return _limitMode($prefs->get('listLimit')); }
	return '';
}

sub _playlistAction {
	my ($cmd, $tag, $id) = @_;
	# The name of the parameter is the tag itself ("album_id", "track_id"):
	# the Material skin looks for exactly those names in the params of the
	# action (hasPlayableId) to decide whether an item is playable and so
	# whether it shows the Play/Play next/Append buttons.  A generic name
	# ("tag") hides the playability and the buttons stay away.
	return {
		command     => [ 'playlistcontrol' ],
		fixedParams => { cmd => $cmd, "$tag" => $id },
	};
}

# ------------------------------------------------------------------ helpers

# Resolve the drill-down path.  Priority:
#   1. the item passthrough (raw path, used by the classic web UI)
#   2. the lm_path parameter (base64url encoded)
# Both carry the same encoded path, so the order does not matter much; the
# decoding is done in every case.
sub _path {
	my ($args, $pt) = @_;

	if ($pt && defined $pt->{'lm_path'} && $pt->{'lm_path'} ne '') {
		return _decode($pt->{'lm_path'});
	}

	if ($args && $args->{'params'} && defined $args->{'params'}->{'lm_path'}) {
		return _decode($args->{'params'}->{'lm_path'});
	}

	if ($pt && $pt->{'searchTags'}) {
		for my $tag (@{ $pt->{'searchTags'} }) {
			next unless $tag =~ /^lm_path:(.*)$/;
			return _decode($1);
		}
	}

	return '';
}

# Read one request parameter, wherever it is carried.
sub _param {
	my ($args, $name) = @_;
	return '' unless $args;
	return $args->{'params'}->{$name}
		if $args->{'params'} && defined $args->{'params'}->{$name};
	if (ref $args eq 'HASH' && defined $args->{$name}) {
		return $args->{$name};
	}
	return '';
}

# One label of the strings of the server, in the language of the client.
sub _label {
	my ($client, $token) = @_;
	my $text = '';
	if ($client) {
		eval { $text = clientString($client, $token) || ''; };
	}
	$text = '' unless defined $text && $text ne '';
	if ($text eq '') {
		eval { $text = string($token) || ''; };
	}
	return $text || $token;
}

# The label of one row of the level of the genre groups: the pseudo entries
# ("Random", the "%%" aggregate, "All artists", the group without genre)
# carry their own name, the genre groups the name of the group itself.  The
# "%%" row is named by its scope: the library-wide shortcut at the top of
# the tree is "All albums", the aggregate of the genre walked into — the
# first row of the artist list of one genre, the albums of the whole genre
# under the selections — is "Selected albums".  Guard clauses, no nested
# ternary chain — one flag read at most, and no paren counting left to the
# reader.
sub _levelLabel {
	my ($client, $row, $path) = @_;
	$path = '' unless defined $path;
	return _label($client, 'PLUGIN_LIBRARYMAPPER_RANDOM') . ' (' . $row->{'n'} . ')'
		if $row->{'random'};
	if ($row->{'allalbums'}) {
		return _label($client, 'PLUGIN_LIBRARYMAPPER_SELECTED')   if $path ne '';
		return _label($client, 'PLUGIN_LIBRARYMAPPER_ALL_ALBUMS');
	}
	return _label($client, 'PLUGIN_LIBRARYMAPPER_ALL_ARTISTS')  if $row->{'all'};
	return _label($client, 'PLUGIN_LIBRARYMAPPER_UNCLASSIFIED') if $row->{'unclassified'};
	return _chars($row->{'key'});
}

sub _encode {
	my $s = shift;
	return '' unless defined $s && $s ne '';
	# the path is a text: it is encoded as UTF-8 bytes before it is put in
	# base64, so that the name of an artist keeps its accents on the way
	utf8::encode($s) if utf8::is_utf8($s);
	my $b = MIME::Base64::encode_base64($s, '');
	$b =~ tr{+/}{-_};
	$b =~ s/=+$//;
	return $b;
}

# The name of a value in the language of the client.
sub _orderLabel {
	my ($client, $v) = @_;
	my %map = (
		alpha     => 'PLUGIN_LIBRARYMAPPER_ORDER_ALPHA',
		newer     => 'PLUGIN_LIBRARYMAPPER_ORDER_NEWER',
		older     => 'PLUGIN_LIBRARYMAPPER_ORDER_OLDER',
		added     => 'PLUGIN_LIBRARYMAPPER_ORDER_ADDED',
		count     => 'PLUGIN_LIBRARYMAPPER_GROUP_COUNT',
		countasc  => 'PLUGIN_LIBRARYMAPPER_GROUP_COUNTASC',
		longest   => 'PLUGIN_LIBRARYMAPPER_ORDER_LONGEST',
		shortest  => 'PLUGIN_LIBRARYMAPPER_ORDER_SHORTEST',
	);
	return _label($client, $map{$v} || 'PLUGIN_LIBRARYMAPPER_ORDER_ALPHA');
}

sub _timeLabel {
	my ($client, $v) = @_;
	my %map = (
		all   => 'PLUGIN_LIBRARYMAPPER_T_ALL',
		day   => 'PLUGIN_LIBRARYMAPPER_T_DAY',
		week  => 'PLUGIN_LIBRARYMAPPER_T_WEEK',
		month => 'PLUGIN_LIBRARYMAPPER_T_MONTH',
		year  => 'PLUGIN_LIBRARYMAPPER_T_YEAR',
	);
	return _label($client, $map{$v} || 'PLUGIN_LIBRARYMAPPER_T_ALL');
}

sub _qualityLabel {
	my ($client, $v) = @_;
	my %map = (
		all     => 'PLUGIN_LIBRARYMAPPER_Q_ALL',
		hires   => 'PLUGIN_LIBRARYMAPPER_Q_HIRES',
		cd      => 'PLUGIN_LIBRARYMAPPER_Q_CD',
		lossy   => 'PLUGIN_LIBRARYMAPPER_Q_LOSSY',
		dsd     => 'PLUGIN_LIBRARYMAPPER_Q_DSD',
		unknown => 'PLUGIN_LIBRARYMAPPER_Q_UNKNOWN',
	);
	return _label($client, $map{$v} || 'PLUGIN_LIBRARYMAPPER_Q_ALL');
}

sub _urlenc {
	my $s = shift || '';
	$s =~ s/([^a-zA-Z0-9_.\-~])/sprintf('%%%02X', ord($1))/ge;
	return $s;
}

# The inverse of _urlenc, for the free text of the expression: anything that
# holds a space stays out of the plain form of the CLI parameters, and the
# encoder leaves no space behind; a value with a space is therefore taken as
# raw text (the passthrough of the web UI carries it unencoded).
sub _urldec {
	my ($s) = @_;
	return '' unless defined $s;
	return $s if $s =~ /\s/;
	$s = _chars($s);
	$s =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
	return $s;
}

# The *choice* of the number of items carried by a request: "default" when no
# explicit choice is there (or when a value is unknown), the choice itself
# otherwise.  The tree always carries a choice, never the resolved number,
# so that "default" keeps meaning "the preference of the parameter page
# decides" down the whole drill-down.
sub _limitMode {
	my ($value) = @_;
	return 'default' unless defined $value && $value ne '';
	return 'unlimited' if $value eq 'unlimited' || $value eq 'all' || $value eq '0';
	return $value      if $value =~ /^\d+$/ && $value > 0;
	return 'default';
}

# The *choice* of the number of the albums of the draw ("Random"): a number
# between 1 and 100, the preference of the parameter page otherwise.
sub _randomMode {
	my ($value) = @_;
	return 0 + $value if defined $value && $value =~ /^\d+$/ && $value >= 1 && $value <= 100;
	my $pref = $prefs->get('random_default') || '';
	return 0 + $pref if $pref =~ /^\d+$/ && $pref >= 1 && $pref <= 100;
	return 10;
}

# The name of a limit, in the language of the client.  The limit travels as
# a *choice* ("default" included), so its name is that choice.
sub _limitLabel {
	my ($client, $value) = @_;
	return _label($client, 'PLUGIN_LIBRARYMAPPER_DEFAULT')   if $value eq 'default';
	return _label($client, 'PLUGIN_LIBRARYMAPPER_UNLIMITED') if $value eq 'unlimited';
	return $value;
}

# The names of the database are UTF-8 bytes.  The server writes a byte
# string as Latin-1, which would show "Jules BillÃ©": the names are therefore
# given to the server as characters, so that they are encoded once.
sub _chars {
	my $s = shift;
	return '' unless defined $s;
	utf8::decode($s) unless utf8::is_utf8($s);
	return $s;
}
sub _decode {
	my $s = shift;
	return '' unless defined $s && $s ne '';
	return $s if $s =~ /\|/;                 # already a raw path
	$s =~ tr{-_}{+/};
	$s .= '=' x ((4 - length($s) % 4) % 4);
	my $d = eval { MIME::Base64::decode_base64($s) };
	return '' unless defined $d;
	# the path stays UTF-8 bytes: that is the language of the database
	return $d;
}

1;
