# LibraryMapper (LMS plugin)

Shareable **query-only** mapping workbench for Lyrion Music Server.
No file operations — ever. It builds a dedicated SQLite database
(`plugin persist dir/LibraryMapper/librarymapper.db`) from Lyrion's own
indexed library (`Slim::Schema`), lets you curate simplified genre groups
(10–20 groups from the raw genre list), consolidate album artists, and
browse the **virtual** target layout:

    Genre \ Artist \ Year - Album

with two extra filters that are part of the application:

- **Temporal filter** — albums added on the server in the last day/week/month/year
- **Quality filter** — Hi-Res (>48 kHz) / CD lossless / Lossy / **1bit Hi-Res
  (DSF/DFF)** / Unknown

## Pages
| URL | Purpose |
|---|---|
| `My Music > Simplified View` | The same drill-down, as a native browse mode of the server (every skin) |
| `/plugins/LibraryMapper/index.html` | Virtual browse app (filters + drill-down) |
| `/plugins/LibraryMapper/settings/basic.html` | Parameter page: initialization, validation report, mapping upload/download, trusted artists |
| `/plugins/LibraryMapper/download.json` | Export the mapping file (JSON) |

## The number of items that are shown
A level of the tree is cut at the limit of the plugin (`Items shown` on the
parameter page). The header of the tree shows the choice that is in use, and
five entries under it change it without leaving the tree:

    Default    10    100    1000    Unlimited

**Default** means that the limit of the parameter page decides; when the user
has chosen nothing, the tree carries *default* down the whole walk (`lm_limit`
is simply not pinned), so the choice of the parameter page keeps following any
change until an explicit choice is made. The same five values are offered by
the `Items shown` selector of the virtual browse page and by the parameter
page. The selector is in bold and its label in the accent colour of the skin,
and the header of the page wraps, so that the selector is not pushed out of
sight in the narrow window of the Material skin.

## The header of the tree
The first entry of the Simplified View shows the order, the filters and the
limit that are in use, and it **opens the page of the plugin** where they can
be changed. In the Material skin the page opens **inside the application**
(embedded window — the link is relative and of the html kind, which Material
embeds), in the classic skins it opens as a page.

## The icons of the genre groups
Every genre group carries a small icon in the tree (Simplified View) and on
the page (genre level). By default it is a **transparent** instrument drawing,
one muted colour per group — violet violin for Classical, amber saxophone for
Jazz, red guitar for Rock... The drawings come from the **Windows 8** set of
Icons8 (free with a link back to `icons8.com`), recoloured by
`t\make_genre_icons.ps1` (run it with `-White` to have them all in white).
Custom groups and the groups without a fitting instrument in the pack
(Country, Reggae) show the neutral treble clef. The full credits are in
`html/images/genre/CREDITS.txt`.

**Your own icons**: on the parameter page (*Genre group icons*) a **zip
archive** can be uploaded — one icon per genre group, named after the group
(`Jazz.png`, `Classical.png`...; png, gif, ico, jpg; a single loose icon file
is accepted as well). The archive is unpacked into the icon folder of the
plugin (`prefs/LibraryMapper/icons/`, beside the database: it survives a
restart), and every uploaded icon replaces the shipped drawing of that group.
The name of a file goes through the same folding as the group itself
(`Soul R&B.png` answers for the group "Soul/R&B"), and a customary group name
also finds its icon (`Metal.png` for the rock group). The group of the albums
without a genre is named `Unclassified.png` (`Default.png` is accepted; the
ship of the group is replaced the same way). Groups without an uploaded file
keep the shipped drawing. *Remove the uploaded icons* puts the shipped
drawings back in place.

## The quality classes
The class of an album (or of a track) is computed when the library is scanned:

| Class | What it is |
|---|---|
| `hires` | the samplerate is above 48 kHz |
| `cd` | the samplerate is above 40 kHz (CD and above) |
| `lossy` | the server reports the track as not lossless |
| `dsd` | the one bit files (`.dsf` and `.dff`) — **1bit Hi-Res** |
| `unknown` | the server reports nothing about the track |

The one bit files are a class of their own: the server reports them with a
samplerate of 2.8 MHz (a DSD64) or more, which would put them into the
hi-res class, but they are not a "96 kHz" of the PCM world — they are a
different technology. Two witnesses tell that a track is one of them: the
size of a sample (one bit) and the name of the file. An album is one bit
when **all** of its tracks are; a mixed album keeps the class of its other
tracks.

## The names
The names come out of the database as UTF-8 bytes and are handed to the
server as characters: the server writes a byte string as Latin-1, which
would show `Jules BillÃ©` instead of `Jules Billé`. The pages of the plugin
bring their own colours (the colours of the theme of the skin when they are
there), so that they stay readable in the light theme and in the dark theme.

## The order of the artists
The artists are not sorted by the name as it is written: **a person is filed
under its last name, a group under the name it carries**.

    "Claude Nougaro"        -> "nougaro claude"   (a person)
    "Nougaro, Claude"       -> "nougaro"          (the inverted form)
    "Metallica"             -> "metallica"        (a group)
    "The Beatles"           -> "beatles"          (the leading article is skipped)
    "Miles Davis Quintet"   -> "miles davis"      (the ensemble word is skipped)

The rules, in the order they are applied:

1. **a comma** means the name is already inverted — the part before the comma
   is the key (`Nougaro, Claude` → N). A group is not read that way: in
   `Earth, Wind & Fire` the comma is only a separator
2. **an ensemble word** — trio, quartet, quintet, sextet, septet, octet, duo,
   duet, ensemble, orchestra, philharmonia, symphony, chorus, choir, band,
   group, collective, players, company, works, feat., ft., and, et, with —
   makes it a group: the ensemble word is skipped and the rest is sorted as it
   stands (`Miles Davis Quintet` → `Miles Davis` → **M**)
3. **`&`, `+` or `/`** in the name makes it a group (`AC/DC` → `ac dc`)
4. **a leading "The"** is skipped (`The Beatles` → `Beatles`)
5. **otherwise it is a person**: the last name comes first and the suffixes
   (Jr., Sr., II, III, IV, PhD, MD) are ignored (`Claude Nougaro` →
   `nougaro claude` → **N**)

A group whose name is a single word (`Metallica`) is filed under that word, so
`Metallica` and `Miles Davis Quintet` both live under **M**, while the person
`Miles Davis` lives under **D**.

The album artist name is not shortened when the name carries an ensemble word:
`Miles Davis Quintet` stays `Miles Davis Quintet` (it is not turned into
`Miles Quintet`).

## Transliteration
A name that is not written in Latin letters is transliterated first, so that it
is filed under a readable letter and not after the "z":

| Script | Rule | Example |
|---|---|---|
| Cyrillic | letter by letter | `Шарль Азе` → `aze sharl` |
| Hebrew | letter by letter | `אביב` → `abyb` |
| Japanese | the kana are romanized from the name Unicode gives them, so no code point is written by hand | `中島りゆき` → `riyuki` |
| Chinese | the name is filed under its family name, taken from a table of the 217 most common ones | `王明` → `wang`, `欧阳修` → `ouyang` |

A name that cannot be transliterated (a Japanese name written in kanji only) is
filed at the end, under a stable key built from its code points: the order stays
the same from one run to the other.

The Chinese table is generated by `t/gen_zh_table.pl`, which checks every code
point — two names sharing one code point is an easy mistake to make.

## The artist filter
At the artist level a **regular expression** narrows the list down. It is
matched against the artist names, case insensitively:

    ^Miles              the artists whose name starts with "Miles"
    Davis$              the artists whose name ends with "Davis"
    (Quintet|Trio)      the ensembles

An invalid expression is ignored and reported on the page.

On the parameter page the same search can match the **name as written**, or its
**sort key** ("davis, miles" — the key the artist is filed under: the last name
first, both in lower case). The key is matched the same way (regular
expression, case insensitive unless the case sensitive box is ticked), so
`s,d ` finds every person filed under a surname starting with d. The result
table shows the sort key of every row either way.

## Album durations
The album list shows the **total duration** of the album. The libraries often
carry the same album in two encodings in one folder (the mp3 copies of the
flac files): the duration is computed **per encoding** (one bit files, lossless,
lossy/other) and the **longest** bucket is shown, not their sum.

The visibility of the entry of the application in the **Apps** list is a box on
the parameter page: at the very moment it is saved, the Apps menu of the
players, of the Material skin and of the web interface shows or hides the
entry — the server does not have to be restarted. The entry of **My Music**
(the Simplified View) is always there.

## Album artists
- Spellings are merged into one canonical name (`"miles davis"`, `"Davis, Miles"` → `Miles Davis`).
- A collaboration credited in one string (`"Claude Nougaro & David Lynx"`) is filed under **each** of its artists.
- **Trusted names** (uploaded on the parameter page, one name per line) are always
  one single album artist: the credit is never split and the albums credited to
  them are filed under them alone — no guest, no other collaborator.

## Deploy
The plugin is published as a plugin repository, so Lyrion installs it by
itself: **Settings → Advanced → Plugins**, *Plugin repositories*, add
`https://raw.githubusercontent.com/NSP-0123456/lms-librarymapper/main/extensions.xml`,
then tick **LibraryMapper** and apply. The server downloads the release,
checks its SHA1 and installs it at the next restart. (Copying the folder into
the `Plugins` directory also works, but the repository keeps the version up to
date.)

The plugin keeps its dedicated SQLite database in the **preferences folder of
the server** (`prefs/LibraryMapper/librarymapper.db`): that folder survives a
restart and is not wiped with the cache. The database is rebuilt by the
initialization phase; the mapping can be exported and imported as JSON.

## Structure
- `install.xml` — plugin descriptor (Lyrion ≥ 7.9)
- `Plugin.pm` — page registration: app page, download endpoint, settings page, browse node
- `Browse.pm` — the native browse mode ("Simplified View"): the drill-down path travels base64url encoded
- `Settings.pm` — parameter page handler (init, repropose, upload, trusted artists)
- `Data.pm` — **dedicated SQLite DB** (schema, initialization scan from Slim::Schema, browse queries)
- `Mapping.pm` — genre rules/propose, validation, artist resolution, trusted names, export/import JSON mapping files
- `SortKey.pm` — the alphabetical order of the artists and the transliteration (no server dependency, unit tested)
- `Upload.pm` — multipart/form-data parser (Lyrion only parses urlencoded bodies)
- `Strings.pm`, `HTML/EN/...` — labels and templates

## Tests
Run them on any machine with perl, no music server needed:

    pwsh -NoProfile -File t\run_tests.ps1

    perl t\sortkey_check.pl      # the order of the artists, the transliteration
    perl t\strings_check.pl      # the strings file against the Lyrion parser rules
    perl t\compile_check.pl      # every module compiles
    perl t\template_check.pl     # the template of the application page renders
    perl t\icon_check.pl         # the genre icons and the uploaded icon pack
