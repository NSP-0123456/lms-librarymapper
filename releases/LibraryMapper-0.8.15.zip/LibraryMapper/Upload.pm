package Plugins::LibraryMapper::Upload;

use strict;

# Minimal multipart/form-data parser.
#
# Lyrion does not parse multipart bodies itself: Slim::Web::HTTP only splits
# the request body into "key=value" pairs, so a file upload posted with
# enctype="multipart/form-data" would arrive as garbage parameters.  The raw
# body is however handed to the plugin as $params->{'content'}, so we parse
# the upload here.
#
# parse($body) returns
#   { fields => { name => value }, files => { name => { filename, content } } }
# or undef when the body is not a multipart body.

sub parse {
	my ($body) = @_;
	return undef unless defined $body && length $body;

	# the first line holds the boundary
	return undef unless $body =~ /^\r?\n?--([^\r\n]+)/;
	my $boundary = $1;
	return undef unless length $boundary;

	my $rest = $body;
	$rest =~ s/^\r?\n?--\Q$boundary\E[ \t]*\r?\n//;

	my %fields;
	my %files;
	for my $chunk (split /\r?\n--\Q$boundary\E(?:--)?[ \t]*\r?\n?/, $rest) {
		next unless $chunk =~ /\r?\n\r?\n/;
		my ($headers, $content) = split /\r?\n\r?\n/, $chunk, 2;
		next unless defined $content;
		my ($name)     = $headers =~ /name="([^"]*)"/;
		my ($filename) = $headers =~ /filename="([^"]*)"/;
		next unless defined $name && $name ne '';
		if (defined $filename && $filename ne '') {
			$files{$name} = { filename => $filename, content => $content };
		}
		else {
			$fields{$name} = $content;
		}
	}
	return { fields => \%fields, files => \%files };
}

1;
