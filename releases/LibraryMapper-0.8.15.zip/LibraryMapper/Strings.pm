package Plugins::LibraryMapper::Strings;

use strict;

our %strings = (
	'EN' => {
		'PLUGIN_LIBRARYMAPPER'              => 'LibraryMapper',
		'PLUGIN_LIBRARYMAPPER_DESC'         => 'Library mapping workbench: simplify genres, consolidate album artists, browse the virtual target layout. Query-only — never touches files.',
		'PLUGIN_LIBRARYMAPPER_STATUS'       => 'Status',
		'PLUGIN_LIBRARYMAPPER_INIT'         => 'Initialization',
		'PLUGIN_LIBRARYMAPPER_RUN_INIT'     => 'Run initialization scan',
		'PLUGIN_LIBRARYMAPPER_INIT_RUNNING' => 'Initialization in progress...',
		'PLUGIN_LIBRARYMAPPER_GENRE_GROUPS' => 'Genre groups',
		'PLUGIN_LIBRARYMAPPER_VALIDATION'   => 'Validation',
		'PLUGIN_LIBRARYMAPPER_DOWNLOAD_MAP' => 'Download mapping file (JSON)',
		'PLUGIN_LIBRARYMAPPER_UPLOAD_MAP'   => 'Paste mapping file (JSON) and import',
		'PLUGIN_LIBRARYMAPPER_APP'          => 'Virtual browse',
		'PLUGIN_LIBRARYMAPPER_TIME_FILTER'  => 'Albums added',
		'PLUGIN_LIBRARYMAPPER_QUALITY_FILTER' => 'Quality',
		'PLUGIN_LIBRARYMAPPER_Q_ALL'        => 'Any quality',
		'PLUGIN_LIBRARYMAPPER_Q_HIRES'      => 'Hi-Res (> 48kHz)',
		'PLUGIN_LIBRARYMAPPER_Q_CD'         => 'CD lossless (44.1/48kHz)',
		'PLUGIN_LIBRARYMAPPER_Q_LOSSY'      => 'Lossy (mp3/aac/...)',
		'PLUGIN_LIBRARYMAPPER_T_ALL'        => 'Any date',
		'PLUGIN_LIBRARYMAPPER_T_DAY'        => 'Last day',
		'PLUGIN_LIBRARYMAPPER_T_WEEK'       => 'Last week',
		'PLUGIN_LIBRARYMAPPER_T_MONTH'      => 'Last month',
		'PLUGIN_LIBRARYMAPPER_T_YEAR'       => 'Last year',
	},
	'FR' => {
		'PLUGIN_LIBRARYMAPPER'              => 'LibraryMapper',
		'PLUGIN_LIBRARYMAPPER_DESC'         => 'Atelier de mappage : genres simplifies, artistes consolides, vue virtuelle. Lecture seule - ne deplace aucun fichier.',
		'PLUGIN_LIBRARYMAPPER_T_ALL'        => 'Toute date',
		'PLUGIN_LIBRARYMAPPER_T_DAY'        => 'Dernier jour',
		'PLUGIN_LIBRARYMAPPER_T_WEEK'       => 'Derniere semaine',
		'PLUGIN_LIBRARYMAPPER_T_MONTH'      => 'Dernier mois',
		'PLUGIN_LIBRARYMAPPER_T_YEAR'       => 'Derniere annee',
	},
);

1;
