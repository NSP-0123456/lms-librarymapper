package Plugins::LibraryMapper::SortKey;

use strict;

use Encode qw(decode FB_DEFAULT);

# The alphabetical order of the artists.
#
# A person is filed under its last name, a group under the name it carries:
#
#   "Claude Nougaro"       -> "nougaro claude"    (a person: last name first)
#   "Metallica"            -> "metallica"         (a group: as it stands)
#   "Miles Davis Quintet"  -> "miles davis"       (the ensemble word is skipped)
#   "Nougaro, Claude"      -> "nougaro claude"    (the inverted form)
#
# The names that are not written in Latin letters are transliterated first,
# so that a Russian, a Hebrew, a Chinese or a Japanese name is filed under
# a readable letter instead of after the "z".
#
# The module is free of any Lyrion dependency so that it can be tested on
# its own.

# Words that name an ensemble instead of a person.  They are skipped when
# the order is computed:
#   "Miles Davis Quintet" -> "Miles Davis"
#   "Dave Brubeck Trio"   -> "Dave Brubeck"
#   "Simon and Garfunkel" -> "Simon Garfunkel"
#
# The words are written in several languages: an ensemble can be called
# Trio, Trío, Quatuor, Orquesta...  The list holds the PLAIN letters (the
# words are matched on the accent-folded name: "Trío" is folded to "trio"
# before the match, see _foldAccents).  The phrases stand first ("big
# band": the lone "big" must not stay behind in the name).  A word is
# matched as a whole word only (\b around the built pattern).
my @DESIGNATOR_WORDS = (
	# --- the phrases ------------------------------------------------------
	'big bands?',          # en
	'bigband',             # de, sv, fi
	'storband',            # da, no, sv
	'gran bandas?',        # es, pt
	'grand orchestres?',   # fr
	'grosses orchesters?', # de ("Großes Orchester", folded)
	'gros orchestres?',    # fr
	# --- how many players: duo, duo-musical, trio, quartet, quintet... ----
	'duos?',                        # en, fr, it, es (dúo), de, nl, da, no, sv, fi, pl
	'duets?',                       # en, pl, cs
	'duett(?:ts?|os?|es?)?',        # de, it (duetto/duetti)
	'duetti?',                      # it (plural)
	'duetos?',                      # es
	'duplas?',                      # pt
	'trios?',                       # en, fr, it, es (trío), de, hu (trió), fi...
	'quartets?',                    # en, ru (translit.)
	'quartetts?',                   # de, hu (kvartett handled below)
	'quartet(?:ts?|os?|ettes?)',    # en (quartette), de (quartett), es (cuarteto), fr
	'quintets?', 		    # en
	'quintet(?:ts?|os?|ettes?)',    # de (quintett), es (quinteto), fr (quintette)
	'sextets?', 'septets?', 'octets?', 'nonets?',   # en
	'sextet(?:ts?|os?|ettes?)', 'septet(?:ts?|os?|ettes?)',
	'octet(?:ts?|os?|ettes?)', 'nonet(?:ts?|os?|ettes?)',
	'quartetti?', 'quintetti?', 'sestetti?', 'settetti?', 'ottetti?', 'nonetti?', # it
	'quartettos?', 'quintettos?', 'sestettos?', 'settettos?', 'ottettos?', 'nonettos?', # it
	'quartetten?', 'quintetten?', 'sextetten?', 'septetten?', 'oktetten?', # nl, sv, de (kwartet(ten))
	'quatuors?',                    # fr
	'quintettes?', 'sextuors?', 'septuors?', 'octuors?', 'octettes?', # fr
	'cuartetos?', 'quintetos?', 'sextetos?', 'septetos?', 'octetos?', 'nonetos?', # es
	'cuartetto?s?', 'kwartety?s?', 'kwintety?s?', 'duety?', # pl, hu
	'kwartets?', 'kwintets?', 'sekstets?',          # pl (kwartet, kwintet, sekstet)
	'kvartetty?', 'kvintetty?', 'sextety?', 'septety?', 'oktety?', 'nonety?', # cs
	'kvartett(?:ek|er|en?|is?)?',   # de (quartett), hu (kvartettek), da/no/sv
	'kvintett(?:ek|er|en?|is?)?', 'sextett(?:er|en?|is?)?', 'septett(?:er|en?|is?)?', # de, hu, sv...
	'oktetts?', 'nonetts?',         # de
	'kvartetti[st]?', 'kvintetti[st]?', 'sekstetti[st]?', 'septetti[st]?', 'oktetti[st]?', 'nonetti[st]?', # fi
	# --- orchestras, bands, choirs, the rest ------------------------------
	'orchestras?',                  # en, it, ro
	'orchestres?',                  # fr
	'orquestas?',                   # es
	'orquestras?',                  # pt, ca
	'orchesters?',                  # de
	'orkesten?',                    # nl
	'orkester(?:ne?|re?)?',         # da, no
	'orkester(?:n|rar)?',           # sv
	'orkesteri[tn]?',               # fi
	'orkiestr[ay]',                 # pl
	'orchestr(?:y|u)?',             # cs, sk
	'orkestars?',                   # hr, sr
	'orkestra?',                    # tr, ru (translit.)
	'bands?', 'bandas?',            # en; es, pt, it, ro
	'groups?', 'groupes?',          # en; fr
	'gruppos?',                     # it
	'gruppens?', 'grupper?', 'grupp(?:en|ar)?', 'grup[aoy]', # de; da/no; sv; pl
	'groep(?:s|en)?',               # nl
	'conjuntos?',                   # es, pt (the Latin ensembles)
	'compless[io]',                 # it
	'kapel[ay]?', 'kappellen?',     # cs, sk; de
	'yhtyee?t?s?',                  # fi
	'zespo[\x{0142}l](?:y|owie)?',  # pl (zespół, folded)
	'zenekar(?:ok)?', 'egyuttes(?:ek)?', # hu
	'ansambl[uiay]?s?',             # ru (translit.), hr, ro
	'kooren?',                      # nl
	'korets?',                      # da, no
	'kor(?:us|uses)',               # en (kept from the old list)
	'choirs?', 'chor(?:us|uses)',   # en
	'cho[\x{0153}oe]urs?', 'chorales?', # fr (choeur/chœur), fr/da choir-like
	'coros?', 'cori',               # es, it; it (plural)
	'cors?',                        # ca, es
	'chors?', 'chores?',            # de, cs
	'khoras?',                      # ru (translit.)
	'kuoro[st]?',                   # fi
	'sbor(?:y|u)?', 'soubor(?:y|u)?', 'skupin[ay]?', # cs, sk
	'symfonieorkesten?', 'symfoniorkesters?', # nl; sv
	'philharmonias?', 'philharmonics?', 'philharmoniker', # en; de/sv compounds
	'ensembles?',                   # en, fr, de, nl
	'collectives?', 'players', 'company', 'works',  # en (the old words stay)
	'feat\\.?', 'ft\\.?', 'featuring', 'and', 'et', 'with',
);
my $DESIGNATOR = qr/\b(?:@{[ join( '|', @DESIGNATOR_WORDS ) ]})\b/i;

# --- transliteration tables ------------------------------------------------

# Cyrillic (Russian, Ukrainian and the other Slavic alphabets)
my %CYRILLIC = (
	"\x{0430}" => 'a',  "\x{0431}" => 'b',  "\x{0432}" => 'v',  "\x{0433}" => 'g',
	"\x{0434}" => 'd',  "\x{0435}" => 'e',  "\x{0451}" => 'e',  "\x{0436}" => 'zh',
	"\x{0437}" => 'z',  "\x{0438}" => 'i',  "\x{0439}" => 'y',  "\x{043a}" => 'k',
	"\x{043b}" => 'l',  "\x{043c}" => 'm',  "\x{043d}" => 'n',  "\x{043e}" => 'o',
	"\x{043f}" => 'p',  "\x{0440}" => 'r',  "\x{0441}" => 's',  "\x{0442}" => 't',
	"\x{0443}" => 'u',  "\x{0444}" => 'f',  "\x{0445}" => 'kh', "\x{0446}" => 'ts',
	"\x{0447}" => 'ch', "\x{0448}" => 'sh', "\x{0449}" => 'shch', "\x{044a}" => '',
	"\x{044b}" => 'y',  "\x{044c}" => '',   "\x{044d}" => 'e',  "\x{044e}" => 'yu',
	"\x{044f}" => 'ya', "\x{0456}" => 'i',  "\x{0457}" => 'yi', "\x{0454}" => 'ye',
	"\x{0491}" => 'g',
);

# Hebrew
my %HEBREW = (
	"\x{05d0}" => 'a',  "\x{05d1}" => 'b',  "\x{05d2}" => 'g',  "\x{05d3}" => 'd',
	"\x{05d4}" => 'h',  "\x{05d5}" => 'v',  "\x{05d6}" => 'z',  "\x{05d7}" => 'kh',
	"\x{05d8}" => 't',  "\x{05d9}" => 'y',  "\x{05da}" => 'k',  "\x{05db}" => 'kh',
	"\x{05dc}" => 'l',  "\x{05dd}" => 'm',  "\x{05de}" => 'm',  "\x{05df}" => 'n',
	"\x{05e0}" => 'n',  "\x{05e1}" => 's',  "\x{05e2}" => 'a',  "\x{05e3}" => 'p',
	"\x{05e4}" => 'f',  "\x{05e5}" => 'ts', "\x{05e6}" => 'ts', "\x{05e7}" => 'q',
	"\x{05e8}" => 'r',  "\x{05e9}" => 'sh', "\x{05ea}" => 't',
);

# The Japanese kana are romanized from the name Unicode gives them
# ("HIRAGANA LETTER KA"), so that no code point has to be written by hand.
# The table is built the first time a kana is met.
my %KANA;
my $KANA_READY = 0;

sub _kanaTable {
	return 1 if $KANA_READY;
	$KANA_READY = 1;
	return 0 unless eval { require Unicode::UCD; 1 };
	for my $cp (0x3000 .. 0x30FF) {
		my $ci = Unicode::UCD::charinfo($cp);
		next unless $ci && $ci->{'name'};
		my $name = $ci->{'name'};
		if ($name =~ /^(?:HIRAGANA|KATAKANA) LETTER (.+)$/) {
			$KANA{ chr($cp) } = _kanaRoman($1);
		}
		elsif ($name =~ /PROLONGED SOUND MARK$/) {
			$KANA{ chr($cp) } = '';
		}
	}
	return 1;
}

# The romanization of one kana, from the name Unicode gives it.
sub _kanaRoman {
	my $r = shift;
	# the small tsu doubles the consonant that follows
	return "\x{3064}" if $r eq 'SMALL TU';
	return 'tsu'  if $r eq 'TU';
	return 'shi'  if $r eq 'SI';
	return 'chi'  if $r eq 'TI';
	return 'fu'   if $r eq 'HU';
	return 'ji'   if $r eq 'ZI';
	$r =~ s/^SMALL //;
	return lc $r;
}

# The most common Chinese family names.  A Chinese name carries no space:
# the family name comes first, so it is enough to transliterate it to file
# the artist under a readable letter.
#
# The table is generated by t\gen_zh_table.pl from the list of the common
# Chinese surnames, and the code points are checked there: a name written
# twice under the same code point is a mistake that is easy to make.
my %CHINESE_SURNAME = (
	"\x{738b}" => 'wang',
	"\x{674e}" => 'li',
	"\x{5f20}" => 'zhang',
	"\x{5218}" => 'liu',
	"\x{9648}" => 'chen',
	"\x{6768}" => 'yang',
	"\x{9ec4}" => 'huang',
	"\x{8d75}" => 'zhao',
	"\x{5434}" => 'wu',
	"\x{5468}" => 'zhou',
	"\x{5f90}" => 'xu',
	"\x{5b59}" => 'sun',
	"\x{9a6c}" => 'ma',
	"\x{6731}" => 'zhu',
	"\x{80e1}" => 'hu',
	"\x{90ed}" => 'guo',
	"\x{4f55}" => 'he',
	"\x{6797}" => 'lin',
	"\x{9ad8}" => 'gao',
	"\x{7f57}" => 'luo',
	"\x{90d1}" => 'zheng',
	"\x{6881}" => 'liang',
	"\x{8c22}" => 'xie',
	"\x{5b8b}" => 'song',
	"\x{5510}" => 'tang',
	"\x{8bb8}" => 'xu',
	"\x{9093}" => 'deng',
	"\x{97e9}" => 'han',
	"\x{51af}" => 'feng',
	"\x{66f9}" => 'cao',
	"\x{5f6d}" => 'peng',
	"\x{66fe}" => 'zeng',
	"\x{8427}" => 'xiao',
	"\x{7530}" => 'tian',
	"\x{8463}" => 'dong',
	"\x{6f58}" => 'pan',
	"\x{8881}" => 'yuan',
	"\x{8521}" => 'cai',
	"\x{848b}" => 'jiang',
	"\x{4f59}" => 'yu',
	"\x{4e8e}" => 'yu',
	"\x{675c}" => 'du',
	"\x{53f6}" => 'ye',
	"\x{7a0b}" => 'cheng',
	"\x{9b4f}" => 'wei',
	"\x{82cf}" => 'su',
	"\x{5415}" => 'lv',
	"\x{4e01}" => 'ding',
	"\x{4efb}" => 'ren',
	"\x{5362}" => 'lu',
	"\x{59da}" => 'yao',
	"\x{6c88}" => 'shen',
	"\x{59dc}" => 'jiang',
	"\x{5d14}" => 'cui',
	"\x{949f}" => 'zhong',
	"\x{8c2d}" => 'tan',
	"\x{9646}" => 'lu',
	"\x{6c6a}" => 'wang',
	"\x{8303}" => 'fan',
	"\x{91d1}" => 'jin',
	"\x{77f3}" => 'shi',
	"\x{5ed6}" => 'liao',
	"\x{8d3e}" => 'jia',
	"\x{590f}" => 'xia',
	"\x{97e6}" => 'wei',
	"\x{4ed8}" => 'fu',
	"\x{65b9}" => 'fang',
	"\x{767d}" => 'bai',
	"\x{90b9}" => 'zou',
	"\x{5b5f}" => 'meng',
	"\x{718a}" => 'xiong',
	"\x{79e6}" => 'qin',
	"\x{90b1}" => 'qiu',
	"\x{6c5f}" => 'jiang',
	"\x{5c39}" => 'yin',
	"\x{859b}" => 'xue',
	"\x{95eb}" => 'yan',
	"\x{6bb5}" => 'duan',
	"\x{96f7}" => 'lei',
	"\x{4faf}" => 'hou',
	"\x{9f99}" => 'long',
	"\x{53f2}" => 'shi',
	"\x{9676}" => 'tao',
	"\x{9ece}" => 'li',
	"\x{8d3a}" => 'he',
	"\x{987e}" => 'gu',
	"\x{6bdb}" => 'mao',
	"\x{90dd}" => 'hao',
	"\x{9f9a}" => 'gong',
	"\x{90b5}" => 'shao',
	"\x{4e07}" => 'wan',
	"\x{94b1}" => 'qian',
	"\x{4e25}" => 'yan',
	"\x{8983}" => 'qin',
	"\x{6b66}" => 'wu',
	"\x{6234}" => 'dai',
	"\x{83ab}" => 'mo',
	"\x{5b54}" => 'kong',
	"\x{5411}" => 'xiang',
	"\x{6c64}" => 'tang',
	"\x{5e38}" => 'chang',
	"\x{6e29}" => 'wen',
	"\x{5eb7}" => 'kang',
	"\x{65bd}" => 'shi',
	"\x{6587}" => 'wen',
	"\x{725b}" => 'niu',
	"\x{6a0a}" => 'fan',
	"\x{845b}" => 'ge',
	"\x{90a2}" => 'xing',
	"\x{5b89}" => 'an',
	"\x{9f50}" => 'qi',
	"\x{6613}" => 'yi',
	"\x{4e54}" => 'qiao',
	"\x{4f0d}" => 'wu',
	"\x{5e9e}" => 'pang',
	"\x{989c}" => 'yan',
	"\x{502a}" => 'ni',
	"\x{5e84}" => 'zhuang',
	"\x{8042}" => 'nie',
	"\x{7ae0}" => 'zhang',
	"\x{9c81}" => 'lu',
	"\x{5cb3}" => 'yue',
	"\x{7fdf}" => 'zhai',
	"\x{6bb7}" => 'yin',
	"\x{8a79}" => 'zhan',
	"\x{7533}" => 'shen',
	"\x{6b27}" => 'ou',
	"\x{803f}" => 'geng',
	"\x{5173}" => 'guan',
	"\x{5170}" => 'lan',
	"\x{7126}" => 'jiao',
	"\x{4fde}" => 'yu',
	"\x{5de6}" => 'zuo',
	"\x{67f3}" => 'liu',
	"\x{7518}" => 'gan',
	"\x{795d}" => 'zhu',
	"\x{5305}" => 'bao',
	"\x{5b81}" => 'ning',
	"\x{5c1a}" => 'shang',
	"\x{7b26}" => 'fu',
	"\x{8212}" => 'shu',
	"\x{962e}" => 'ruan',
	"\x{67ef}" => 'ke',
	"\x{7eaa}" => 'ji',
	"\x{6885}" => 'mei',
	"\x{7ae5}" => 'tong',
	"\x{51cc}" => 'ling',
	"\x{6bd5}" => 'bi',
	"\x{5355}" => 'shan',
	"\x{5b63}" => 'ji',
	"\x{88f4}" => 'pei',
	"\x{970d}" => 'huo',
	"\x{6d82}" => 'tu',
	"\x{6210}" => 'cheng',
	"\x{82d7}" => 'miao',
	"\x{8c37}" => 'gu',
	"\x{76db}" => 'sheng',
	"\x{66f2}" => 'qu',
	"\x{7fc1}" => 'weng',
	"\x{5189}" => 'ran',
	"\x{9a86}" => 'luo',
	"\x{84dd}" => 'lan',
	"\x{8def}" => 'lu',
	"\x{6e38}" => 'you',
	"\x{8f9b}" => 'xin',
	"\x{9773}" => 'jin',
	"\x{7ba1}" => 'guan',
	"\x{67f4}" => 'chai',
	"\x{8499}" => 'meng',
	"\x{9c8d}" => 'bao',
	"\x{534e}" => 'hua',
	"\x{55bb}" => 'yu',
	"\x{7941}" => 'qi',
	"\x{84b2}" => 'pu',
	"\x{623f}" => 'fang',
	"\x{6ed5}" => 'teng',
	"\x{5c48}" => 'qu',
	"\x{9976}" => 'rao',
	"\x{89e3}" => 'xie',
	"\x{725f}" => 'mu',
	"\x{827e}" => 'ai',
	"\x{5c24}" => 'you',
	"\x{9633}" => 'yang',
	"\x{65f6}" => 'shi',
	"\x{7a46}" => 'mu',
	"\x{519c}" => 'nong',
	"\x{53f8}" => 'si',
	"\x{5353}" => 'zhuo',
	"\x{53e4}" => 'gu',
	"\x{5409}" => 'ji',
	"\x{7f2a}" => 'miao',
	"\x{7b80}" => 'jian',
	"\x{8f66}" => 'che',
	"\x{9879}" => 'xiang',
	"\x{8fde}" => 'lian',
	"\x{82a6}" => 'lu',
	"\x{9ea6}" => 'mai',
	"\x{891a}" => 'chu',
	"\x{5a04}" => 'lou',
	"\x{7aa6}" => 'dou',
	"\x{621a}" => 'qi',
	"\x{5c91}" => 'cen',
	"\x{666f}" => 'jing',
	"\x{515a}" => 'dang',
	"\x{5bab}" => 'gong',
	"\x{8d39}" => 'fei',
	"\x{535c}" => 'bu',
	"\x{51b7}" => 'leng',
	"\x{664f}" => 'yan',
	"\x{5e2d}" => 'xi',
	"\x{536b}" => 'wei',
	"\x{7c73}" => 'mi',
	"\x{67cf}" => 'bai',
	"\x{5b97}" => 'zong',
	"\x{77bf}" => 'qu',
	"\x{6842}" => 'gui',
	"\x{5168}" => 'quan',
);
my %CHINESE_COMPOUND = (
	"\x{6b27}\x{9633}" => 'ouyang',
	"\x{53f8}\x{9a6c}" => 'sima',
	"\x{8bf8}\x{845b}" => 'zhuge',
	"\x{4e0a}\x{5b98}" => 'shangguan',
	"\x{4e1c}\x{65b9}" => 'dongfang',
	"\x{72ec}\x{5b64}" => 'dugu',
	"\x{6155}\x{5bb9}" => 'murong',
	"\x{590f}\x{4faf}" => 'xiahou',
	"\x{7687}\x{752b}" => 'huangfu',
	"\x{5c09}\x{8fdf}" => 'yuchi',
	"\x{516c}\x{7f8a}" => 'gongyang',
	"\x{6fb9}\x{53f0}" => 'tantai',
	"\x{957f}\x{5b59}" => 'zhangsun',
	"\x{5b87}\x{6587}" => 'yuwen',
);

# --- the sort key ----------------------------------------------------------

# The name with the accents folded and in lower case: "Trío" -> "trio",
# "Peyceré" -> "peycere".  The ensemble words are matched on the folded
# name, so an accented spelling ("Trío", "Dúo") is recognized as well as
# the plain one.  (The same folding as in _sortText, without the
# transliteration and without the punctuation.)
sub _foldAccents {
	my $s = shift;
	return '' unless defined $s;

	# the names come from the database as UTF-8 bytes
	if (!eval { utf8::is_utf8($s) }) {
		my $d = eval { decode('UTF-8', $s, FB_DEFAULT) };
		$s = $d if defined $d;
	}
	$s = lc $s;
	if (eval { require Unicode::Normalize; 1 }) {
		$s = Unicode::Normalize::NFD($s);
		$s =~ s/\p{NonspacingMark}//g;
	}
	else {
		# no Unicode::Normalize: the accents are simply dropped
		$s =~ s/[\x{00C0}-\x{00DE}\x{00E0}-\x{00FE}]//g;
	}
	return $s;
}

# Does the name carry an ensemble word ("Miles Davis Quintet")?
# The words are also recognized with their accent ("Trío", "Dúo", "Quartetto"
# is already plain): the name is folded first, see _foldAccents.
sub hasDesignator {
	my $s = shift;
	return 0 unless defined $s && $s ne '';
	return _foldAccents($s) =~ $DESIGNATOR ? 1 : 0;
}

# Is this the name of a group rather than of a person?
#   "Simon & Garfunkel", "AC/DC", "Earth, Wind & Fire", "Miles Davis Quintet"
sub isBandName {
	my $s = shift;
	return 0 unless defined $s && $s ne '';
	return 1 if $s =~ /[&+]|\//;
	return 1 if _foldAccents($s) =~ $DESIGNATOR;
	return 0;
}

# The key the artists are sorted by.
#
# $raw is the original spelling.  It is used to tell a group from a person
# when the normalized name has lost the clue.
sub artistSortKey {
	my ($name, $raw) = @_;
	return '' unless defined $name && $name ne '';

	my $s = $name;
	$s =~ s/\x{00a0}/ /g;
	$s =~ s/\s+/ /g;
	$s =~ s/^\s+|\s+$//g;
	return '' if $s eq '';

	# the accents are folded first, so that the ensemble words are recognized
	# with their accent ("Peyceré Trío" -> the word "Trío" holds no accent
	# any more when the designator is looked for)
	$s = _foldAccents($s);

	my $band = isBandName($s) || (defined $raw && isBandName($raw));

	# "Nougaro, Claude": the last name comes first.
	# A group is not read that way: "Earth, Wind & Fire" is not cut at the
	# comma, the comma is only a separator there.
	if (!$band && $s =~ /^([^,]+?),/) {
		my $head = $1;
		$head =~ s/^\s+|\s+$//g;
		return _sortText($head);
	}

	# the ensemble words are skipped: "Miles Davis Quartet" -> "Miles Davis"
	# — but only if a word is left over: a group can be called just "Trio"
	# (a French group) or "Duet" (a French jazz duo); the word is then the
	# whole name of the group, and it is kept.
	my $bare = $s;
	$bare =~ s/,/ /g if $band;      # "Earth, Wind & Fire" -> "Earth Wind & Fire"
	# a leading article is not part of the order: "The Beatles" -> "Beatles"
	$bare =~ s/^the\s+//i;
	$bare =~ s/$DESIGNATOR/ /g;
	$bare =~ s/\s+/ /g;
	$bare =~ s/^\s+|\s+$//g;
	if ($bare eq '') {
		# nothing was left but ensemble words: the words are the name itself
		$bare = $s;
		$bare =~ s/,/ /g if $band;
		$bare =~ s/^the\s+//i;
		$bare =~ s/\s+/ /g;
		$bare =~ s/^\s+|\s+$//g;
	}

	if ($band) {
		return _sortText($bare);
	}

	# a person: the last name comes last, the suffixes are ignored
	my @tok = split /\s+/, $bare;
	while (@tok > 1 && $tok[-1] =~ /^(?:jr\.?|sr\.?|ii|iii|iv|phd|md)$/i) { pop @tok; }
	return '' unless @tok;
	my $last = pop @tok;
	return _sortText($last) . (@tok ? ' ' . _sortText(join ' ', @tok) : '');
}

# The text of a sort key: lower case, transliterated, without the accents
# and without the punctuation, so that "Bjork" and "Bjork" (the second one
# carries the accent) are filed together.
sub _sortText {
	my $s = shift;
	return '' unless defined $s;

	# the names come from the database as UTF-8 bytes
	if (!eval { utf8::is_utf8($s) }) {
		my $d = eval { decode('UTF-8', $s, FB_DEFAULT) };
		$s = $d if defined $d;
	}
	$s = lc $s;
	my $orig = $s;

	# the accents are removed first: "Bjork" (with the accent on the o) and
	# "Bjork" are the same artist
	if (eval { require Unicode::Normalize; 1 }) {
		$s = Unicode::Normalize::NFD($s);
		$s =~ s/\p{NonspacingMark}//g;
	}
	else {
		# no Unicode::Normalize: the accents are simply dropped
		$s =~ s/[\x{00C0}-\x{00DE}\x{00E0}-\x{00FE}]//g;
	}

	# the Cyrillic, the Hebrew, the kana and the Chinese family names are
	# transliterated
	$s = _translit($s);

	$s =~ s/[^a-z0-9]+/ /g;
	$s =~ s/\s+/ /g;
	$s =~ s/^\s+|\s+$//g;
	return $s if $s ne '';

	# nothing could be transliterated (a Japanese name written in kanji for
	# instance): the name is filed at the end, in a stable order
	return '~' . join(' ', map { sprintf('%04x', ord $_) } split //, $orig);
}

# Transliterate a name into Latin letters.  The Cyrillic and the Hebrew
# are lettered, the kana are romanized, and a Chinese name is filed under
# its family name.  The characters that have no Latin equivalent (the kanji
# of a given name for instance) are dropped: they only break the ties.
sub _translit {
	my $s = shift;
	return $s if $s !~ /[^\x00-\x7f]/;

	_kanaTable();

	my @ch = split //, $s;

	# a name without kana may be a Chinese name
	my $has_kana = 0;
	for my $c (@ch) {
		if (exists $KANA{$c}) { $has_kana = 1; last; }
	}

	my $out = '';
	my $sokuon = 0;
	my $first = 1;

	# a Chinese family name of two characters: "欧阳" -> "ouyang"
	my $skip = 0;
	if (!$has_kana) {
		for my $c (keys %CHINESE_COMPOUND) {
			if (index($s, $c) == 0) {
				$out = $CHINESE_COMPOUND{$c};
				$skip = length($c);
				$first = 0;
				last;
			}
		}
	}

	for (my $i = 0; $i <= $#ch; $i++) {
		my $c = $ch[$i];

		# the characters of the family name are already romanized
		next if $i < $skip;

		# the small tsu doubles the next consonant
		if ($c eq "\x{3064}") { $sokuon = 1; next; }

		# the small ya / yu / yo: "ki" + small ya -> "kya"
		if ($c eq "\x{3083}" || $c eq "\x{3085}" || $c eq "\x{3087}") {
			my $vowel = $c eq "\x{3083}" ? 'a' : ($c eq "\x{3085}" ? 'u' : 'o');
			if ($out =~ /([a-z]+)\z/) {
				my $syll = $1;
				if ($syll =~ /^(sh|ch|[a-z])([a-z]+)$/) {
					my ($cons) = ($1);
					my $y = ($cons eq 'sh' || $cons eq 'ch') ? '' : 'y';
					$out =~ s/[a-z]+\z//;
					$out .= $cons . $y . $vowel;
				}
				else { $out .= $vowel; }
			}
			next;
		}

		my $t;
		if ($c =~ /^[\x00-\x7f]$/) {
			$t = $c;                       # the Latin letters stay as they are
		}
		elsif (exists $CYRILLIC{$c})   { $t = $CYRILLIC{$c}; }
		elsif (exists $HEBREW{$c})     { $t = $HEBREW{$c}; }
		elsif (exists $KANA{$c})       { $t = $KANA{$c}; }
		elsif (!$has_kana && $first && exists $CHINESE_SURNAME{$c}) {
			$t = $CHINESE_SURNAME{$c};
		}
		else { $t = ''; }

		if ($sokuon && $t ne '') {
			$t =~ s/^(sh|ch|[bcdfghjklmnpqrstvwxyz])/$1$1/;
			$sokuon = 0;
		}
		$first = 0 unless $c =~ /\s/;
		$out .= $t;
	}
	return $out;
}

1;
