package Plugins::LibraryMapper::Browse;

use strict;

use MIME::Base64 ();

use Slim::Utils::Log qw(logger logError);
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(clientString string);

use Plugins::LibraryMapper::Data;

my $log   = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

use constant MODE => 'librarymapper';

# The virtual browse tree is exposed as a native LMS browse mode so that it
# shows up in "My Music" of every skin (Material Skin included) and can be
# walked with the standard LMS drill-down machinery.
#
# The drill-down path ("Genre|Artist|Year - Album") is carried in the
# "lm_path" parameter.  It is transported base64url encoded so that album
# titles containing spaces, commas, ampersands or colons survive every
# transport (CLI parameter lists, web query strings, JSON): a plain "|" in a
# request parameter would be read by Lyrion as a search tag.

sub feed {
	my ($client, $callback, $args, $pt) = @_;

	my $path = _path($args, $pt);

	# The order, the filters and the order of the groups travel with the
	# request: the node of "My Music" that the user picked carries them and
	# every item repeats them, so that the drill-down keeps them.
	my $order      = _param($args, 'lm_order')        || _param($args, 'order')
	                || $prefs->get('order_default')   || 'alpha';
	my $groupOrder = _param($args, 'lm_group_order') || $prefs->get('group_order')
	                || 'alpha';
	my $time       = _param($args, 'lm_time')        || $prefs->get('time_default')
	                || 'all';
	my $quality    = _param($args, 'lm_quality')     || $prefs->get('quality_default')
	                || 'all';

	# The number of items of a level: the choice of the user travels with the
	# request, so that it holds for the whole drill-down.  It is carried as a
	# *choice* ("default" included), never as the resolved number: when the
	# user has chosen nothing, the preference of the plugin decides, and that
	# must stay so down the tree.  The query itself resolves the choice (see
	# Data::_limitOf, which falls back to the preference for "default").
	my $limit = _limitMode(_param($args, 'lm_limit'));

	my $view = Plugins::LibraryMapper::Data::browse(
		parent     => $path,
		time       => $time,
		quality    => $quality,
		order      => $order,
		groupOrder => $groupOrder,
		list       => $limit,
		filter     => _param($args, 'filter'),
	);

	my $type = $view->{'type'} || 'level';
	my @items;

	# The header comes first: it shows the order and the filters that are in
	# use and opens the page of the plugin, where they can be changed.  A
	# browse tree cannot carry a form, so the header is a link.  The number
	# of items is chosen on that page as well (and on the parameter page):
	# the tree itself shows the choice only, it does not offer it.
	push @items, _headerItem($client, $order, $groupOrder, $time, $quality, $limit);

	if ($type eq 'level') {
		for my $row (@{ $view->{'rows'} }) {
			my $next = $path ? $path . '|' . $row->{'key'} : $row->{'key'};
			# the group of the albums that carry no genre is not a genre:
			# it is shown under a name that says it
			my $label = $row->{'unclassified'}
				? _label($client, 'PLUGIN_LIBRARYMAPPER_UNCLASSIFIED')
				: _chars($row->{'key'});
			# at the level of the genre groups the number of albums of the
			# group is shown beside the name
			$label .= ' (' . $row->{'n'} . ')' if !$path && $row->{'n'};
			# the first level is the level of the genre groups: every group
			# carries its icon (t\make_genre_icons.ps1)
			my $icon = $path ? undef : _genreIcon($row->{'unclassified'} ? '' : $row->{'key'});
			push @items, _levelItem($next, $label, $order, $groupOrder, $time, $quality, $limit, $icon);
		}
	}
	elsif ($type eq 'albums') {
		for my $row (@{ $view->{'rows'} }) {
			# the path carries the album id: an album that belongs to several
			# artists is filed under each of them
			my $next = join('|', $row->{'vpath_genre'}, $row->{'vpath_artist'}, $row->{'album_id'});
			my $label = ($row->{'year'} ? $row->{'year'} . ' - ' : '') . _chars($row->{'name'});
			# the total duration of the album (the longest of the buckets of
			# the encodings), when the scan found one.  The middle dot is
			# written as the code point U+00B7 and not as a literal of the
			# file: the source is no UTF-8 text for perl, a literal of two
			# bytes would be read as the characters "Â·" when the label
			# (characters) meets it (bytes) — the trap of the double
			# encoding, seen on the pilot.
			$label .= '  ' . "\x{B7}" . '  ' . $row->{'durationText'} if $row->{'durationText'};
			push @items, _albumItem($next, $label, $row, $order, $groupOrder, $time, $quality, $limit);
		}
	}
	elsif ($type eq 'tracks') {
		for my $row (@{ $view->{'rows'} }) {
			push @items, _trackItem($row);
		}
	}

	# The "items" action walks one level down.  The path of the level is
	# carried by the "lm_path" parameter, which every item sets itself.  The
	# limit is only pinned when the user has chosen one: "default" must keep
	# meaning "the preference decides" down the whole tree.
	my %actions = (
		commonVariables => [ 'lm_path' => 'id' ],
		items => {
			command     => [ 'browselibrary', 'items' ],
			fixedParams => {
				mode           => MODE,
				lm_order       => $order,
				lm_group_order => $groupOrder,
				lm_time        => $time,
				lm_quality     => $quality,
				( $limit eq 'default' ? () : ( lm_limit => $limit ) ),
			},
		},
	);

	$callback->({ items => \@items, actions => \%actions, sorted => 1 }, undef);
}

# The header of the tree: it tells which order, which filters and which limit
# are in use and opens the page of the plugin, where they can be changed.
# The URL carries the *choice* of the limit ("default" included), not the
# resolved number: the page of the plugin understands "default".
#
# The URL is relative and of the "html" kind, so the Material skin opens the
# page *inside* the application, in an embedded window (its openWebLink
# embeds the relative links of the local server and opens only the external
# http(s) ones); the classic skins follow the same link.  A plain URL needs
# no replacement: the placeholders of the skins ({client}, ...) are not used.
sub _headerItem {
	my ($client, $order, $groupOrder, $time, $quality, $limit) = @_;

	my $text = join('  |  ',
		_label($client, 'PLUGIN_LIBRARYMAPPER_ORDER') . ': ' . _orderLabel($client, $order),
		_label($client, 'PLUGIN_LIBRARYMAPPER_TIME_FILTER') . ': ' . _timeLabel($client, $time),
		_label($client, 'PLUGIN_LIBRARYMAPPER_QUALITY_FILTER') . ': ' . _qualityLabel($client, $quality),
		_label($client, 'PLUGIN_LIBRARYMAPPER_LIST') . ': ' . _limitLabel($client, $limit),
	);

	my $url = '/plugins/LibraryMapper/index.html'
		. '?time='   . _urlenc($time)
		. '&quality='. _urlenc($quality)
		. '&order='  . _urlenc($order)
		. '&group='  . _urlenc($groupOrder)
		. '&list='   . _urlenc($limit);

	return {
		name    => $text,
		title   => $text,
		id      => 'lm_header',
		type    => 'weblink',
		weblink => $url,
	};
}

# a plain (not playable) entry of the virtual tree: a genre group or an
# artist within a genre group.  A genre group carries its icon, an artist
# none ($icon undef there).
sub _levelItem {
	my ($path, $label, $order, $groupOrder, $time, $quality, $limit, $icon) = @_;
	my $enc = _encode($path);
	my %item = (
		name        => $label,
		title       => $label,
		id          => $enc,
		type        => 'link',
		url         => \&feed,
		passthrough => [ { lm_path => $enc, lm_order => $order, lm_group_order => $groupOrder,
		                   lm_time => $time, lm_quality => $quality, lm_limit => $limit } ],
		itemActions => {
			items => _goAction($enc, $order, $groupOrder, $time, $quality, $limit),
		},
	);
	$item{'icon'} = $icon if $icon;
	return \%item;
}

# The icon of a genre group: the one the user uploaded on the parameter page
# when the group has one (served by the icon endpoint), or an instrument
# drawing of the shipped icons8 pack otherwise (t\make_genre_icons.ps1).
# The path is relative: the client resolves it against the root of the server
# (Slim::Web::ImageProxy::proxiedImage lets the local paths through).
sub _genreIcon {
	my ($key) = @_;
	if (Plugins::LibraryMapper::Data::customIconFile($key)) {
		return 'plugins/LibraryMapper/icon.png?name=' . _urlenc($key);
	}
	return 'plugins/LibraryMapper/html/images/genre/'
		. Plugins::LibraryMapper::Data::genreIconFile($key) . '.png';
}

# an album: it can be played as such (Lyrion knows the album) and it can be
# opened to show its tracks
sub _albumItem {
	my ($path, $label, $row, $order, $groupOrder, $time, $quality, $limit) = @_;
	my $enc = _encode($path);
	my %item = (
		name        => $label,
		title       => $label,
		id          => $enc,
		type        => 'playlist',
		playlist    => \&feed,
		url         => \&feed,
		passthrough => [ { lm_path => $enc, lm_order => $order, lm_group_order => $groupOrder,
		                   lm_time => $time, lm_quality => $quality, lm_limit => $limit } ],
		itemActions => {
			items  => _goAction($enc, $order, $groupOrder, $time, $quality, $limit),
			play   => _playlistAction('load',   'album_id', $row->{'album_id'}),
			add    => _playlistAction('add',    'album_id', $row->{'album_id'}),
			insert => _playlistAction('insert', 'album_id', $row->{'album_id'}),
		},
	);
	# The cover art: the URL /music/<id>/cover wants the id of a *track*,
	# not the id of the album: the art of an album hangs on one of its
	# tracks (the "artwork" column of the albums table of Lyrion).
	my $art = $row->{'artwork_track_id'} || 0;
	if ($art) {
		$item{'artwork_track_id'} = $art;
		$item{'image'}            = 'music/' . $art . '/cover';
	}
	return \%item;
}

# one track of an album
sub _trackItem {
	my ($row) = @_;
	my $title = _chars($row->{'title'});
	return {
		name  => $title,
		title => $title,
		id    => $row->{'track_id'},
		type  => 'audio',
		play  => $row->{'url'},
		url   => $row->{'url'},
		itemActions => {
			play   => _playlistAction('load',   'track_id', $row->{'track_id'}),
			add    => _playlistAction('add',    'track_id', $row->{'track_id'}),
			insert => _playlistAction('insert', 'track_id', $row->{'track_id'}),
		},
	};
}

# the action used to walk one level down: browselibrary items mode:librarymapper
# with the path carried in the lm_path parameter
sub _goAction {
	my ($enc, $order, $groupOrder, $time, $quality, $limit) = @_;
	return {
		command     => [ 'browselibrary', 'items' ],
		fixedParams => {
			mode           => MODE,
			lm_path        => $enc,
			lm_order       => $order,
			lm_group_order => $groupOrder,
			lm_time        => $time,
			lm_quality     => $quality,
			lm_limit       => $limit,
		},
	};
}

sub _playlistAction {
	my ($cmd, $tag, $id) = @_;
	return {
		command     => [ 'playlistcontrol' ],
		fixedParams => { cmd => $cmd, tag => $id },
	};
}

# ------------------------------------------------------------------ helpers

# Resolve the drill-down path.  Priority:
#   1. the item passthrough (raw path, used by the classic web UI)
#   2. the lm_path parameter (base64url encoded)
# Both carry the same encoded path, so the order does not matter much; the
# decoding is done in every case.
sub _path {
	my ($args, $pt) = @_;

	if ($pt && defined $pt->{'lm_path'} && $pt->{'lm_path'} ne '') {
		return _decode($pt->{'lm_path'});
	}

	if ($args && $args->{'params'} && defined $args->{'params'}->{'lm_path'}) {
		return _decode($args->{'params'}->{'lm_path'});
	}

	if ($pt && $pt->{'searchTags'}) {
		for my $tag (@{ $pt->{'searchTags'} }) {
			next unless $tag =~ /^lm_path:(.*)$/;
			return _decode($1);
		}
	}

	return '';
}

# Read one request parameter, wherever it is carried.
sub _param {
	my ($args, $name) = @_;
	return '' unless $args;
	return $args->{'params'}->{$name}
		if $args->{'params'} && defined $args->{'params'}->{$name};
	if (ref $args eq 'HASH' && defined $args->{$name}) {
		return $args->{$name};
	}
	return '';
}

# One label of the strings of the server, in the language of the client.
sub _label {
	my ($client, $token) = @_;
	my $text = '';
	if ($client) {
		eval { $text = clientString($client, $token) || ''; };
	}
	$text = '' unless defined $text && $text ne '';
	if ($text eq '') {
		eval { $text = string($token) || ''; };
	}
	return $text || $token;
}

sub _encode {
	my $s = shift;
	return '' unless defined $s && $s ne '';
	# the path is a text: it is encoded as UTF-8 bytes before it is put in
	# base64, so that the name of an artist keeps its accents on the way
	utf8::encode($s) if utf8::is_utf8($s);
	my $b = MIME::Base64::encode_base64($s, '');
	$b =~ tr{+/}{-_};
	$b =~ s/=+$//;
	return $b;
}

# The name of a value in the language of the client.
sub _orderLabel {
	my ($client, $v) = @_;
	my %map = (
		alpha => 'PLUGIN_LIBRARYMAPPER_ORDER_ALPHA',
		newer => 'PLUGIN_LIBRARYMAPPER_ORDER_NEWER',
		older => 'PLUGIN_LIBRARYMAPPER_ORDER_OLDER',
		added => 'PLUGIN_LIBRARYMAPPER_ORDER_ADDED',
	);
	return _label($client, $map{$v} || 'PLUGIN_LIBRARYMAPPER_ORDER_ALPHA');
}

sub _timeLabel {
	my ($client, $v) = @_;
	my %map = (
		all   => 'PLUGIN_LIBRARYMAPPER_T_ALL',
		day   => 'PLUGIN_LIBRARYMAPPER_T_DAY',
		week  => 'PLUGIN_LIBRARYMAPPER_T_WEEK',
		month => 'PLUGIN_LIBRARYMAPPER_T_MONTH',
		year  => 'PLUGIN_LIBRARYMAPPER_T_YEAR',
	);
	return _label($client, $map{$v} || 'PLUGIN_LIBRARYMAPPER_T_ALL');
}

sub _qualityLabel {
	my ($client, $v) = @_;
	my %map = (
		all     => 'PLUGIN_LIBRARYMAPPER_Q_ALL',
		hires   => 'PLUGIN_LIBRARYMAPPER_Q_HIRES',
		cd      => 'PLUGIN_LIBRARYMAPPER_Q_CD',
		lossy   => 'PLUGIN_LIBRARYMAPPER_Q_LOSSY',
		dsd     => 'PLUGIN_LIBRARYMAPPER_Q_DSD',
		unknown => 'PLUGIN_LIBRARYMAPPER_Q_UNKNOWN',
	);
	return _label($client, $map{$v} || 'PLUGIN_LIBRARYMAPPER_Q_ALL');
}

sub _urlenc {
	my $s = shift || '';
	$s =~ s/([^a-zA-Z0-9_.\-~])/sprintf('%%%02X', ord($1))/ge;
	return $s;
}

# The *choice* of the number of items carried by a request: "default" when no
# explicit choice is there (or when a value is unknown), the choice itself
# otherwise.  The tree always carries a choice, never the resolved number,
# so that "default" keeps meaning "the preference of the parameter page
# decides" down the whole drill-down.
sub _limitMode {
	my ($value) = @_;
	return 'default' unless defined $value && $value ne '';
	return 'unlimited' if $value eq 'unlimited' || $value eq 'all' || $value eq '0';
	return $value      if $value =~ /^\d+$/ && $value > 0;
	return 'default';
}

# The name of a limit, in the language of the client.  The limit travels as
# a *choice* ("default" included), so its name is that choice.
sub _limitLabel {
	my ($client, $value) = @_;
	return _label($client, 'PLUGIN_LIBRARYMAPPER_DEFAULT')   if $value eq 'default';
	return _label($client, 'PLUGIN_LIBRARYMAPPER_UNLIMITED') if $value eq 'unlimited';
	return $value;
}

# The names of the database are UTF-8 bytes.  The server writes a byte
# string as Latin-1, which would show "Jules BillÃ©": the names are therefore
# given to the server as characters, so that they are encoded once.
sub _chars {
	my $s = shift;
	return '' unless defined $s;
	utf8::decode($s) unless utf8::is_utf8($s);
	return $s;
}
sub _decode {
	my $s = shift;
	return '' unless defined $s && $s ne '';
	return $s if $s =~ /\|/;                 # already a raw path
	$s =~ tr{-_}{+/};
	$s .= '=' x ((4 - length($s) % 4) % 4);
	my $d = eval { MIME::Base64::decode_base64($s) };
	return '' unless defined $d;
	# the path stays UTF-8 bytes: that is the language of the database
	return $d;
}

1;
