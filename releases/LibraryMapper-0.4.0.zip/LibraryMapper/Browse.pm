package Plugins::LibraryMapper::Browse;

use strict;

use MIME::Base64 ();

use Slim::Utils::Log qw(logger logError);
use Slim::Utils::Prefs;

use Plugins::LibraryMapper::Data;

my $log   = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

use constant MODE => 'librarymapper';

# The virtual browse tree is exposed as a native LMS browse mode so that it
# shows up in "My Music" of every skin (Material Skin included) and can be
# walked with the standard LMS drill-down machinery.
#
# The drill-down path ("Genre|Artist|Year - Album") is carried in the
# "lm_path" parameter.  It is transported base64url encoded so that album
# titles containing spaces, commas, ampersands or colons survive every
# transport (CLI parameter lists, web query strings, JSON): a plain "|" in a
# request parameter would be read by Lyrion as a search tag.

sub feed {
	my ($client, $callback, $args, $pt) = @_;

	my $path = _path($args, $pt);

	my $view = Plugins::LibraryMapper::Data::browse(
		parent  => $path,
		time    => $prefs->get('time_default'),
		quality => $prefs->get('quality_default'),
		order   => $prefs->get('order_default'),
		list    => $prefs->get('listLimit'),
		filter  => _param($args, 'filter'),
	);

	my $type = $view->{'type'} || 'level';
	my @items;

	if ($type eq 'level') {
		for my $row (@{ $view->{'rows'} }) {
			my $next = $path ? $path . '|' . $row->{'key'} : $row->{'key'};
			push @items, _levelItem($next, $row->{'key'});
		}
	}
	elsif ($type eq 'albums') {
		for my $row (@{ $view->{'rows'} }) {
			# the path carries the album id: an album that belongs to several
			# artists is filed under each of them
			my $next = join('|', $row->{'vpath_genre'}, $row->{'vpath_artist'}, $row->{'album_id'});
			my $label = ($row->{'year'} ? $row->{'year'} . ' - ' : '') . $row->{'name'};
			push @items, _albumItem($next, $label, $row);
		}
	}
	elsif ($type eq 'tracks') {
		for my $row (@{ $view->{'rows'} }) {
			push @items, _trackItem($row);
		}
	}

	# The "items" action walks one level down.  The path of the level is
	# carried by the "lm_path" parameter, which every item sets itself.
	my %actions = (
		commonVariables => [ 'lm_path' => 'id' ],
		items => {
			command     => [ 'browselibrary', 'items' ],
			fixedParams => { mode => MODE },
		},
	);

	$callback->({ items => \@items, actions => \%actions, sorted => 1 }, undef);
}

# a plain (not playable) entry of the virtual tree: a genre group or an
# artist within a genre group
sub _levelItem {
	my ($path, $label) = @_;
	my $enc = _encode($path);
	return {
		name        => $label,
		title       => $label,
		id          => $enc,
		type        => 'link',
		url         => \&feed,
		passthrough => [ { lm_path => $enc } ],
		itemActions => {
			items => _goAction($enc),
		},
	};
}

# an album: it can be played as such (Lyrion knows the album) and it can be
# opened to show its tracks
sub _albumItem {
	my ($path, $label, $row) = @_;
	my $enc = _encode($path);
	return {
		name        => $label,
		title       => $label,
		id          => $enc,
		type        => 'playlist',
		playlist    => \&feed,
		url         => \&feed,
		image       => 'music/' . $row->{'album_id'} . '/cover',
		passthrough => [ { lm_path => $enc } ],
		itemActions => {
			items  => _goAction($enc),
			play   => _playlistAction('load',   'album_id', $row->{'album_id'}),
			add    => _playlistAction('add',    'album_id', $row->{'album_id'}),
			insert => _playlistAction('insert', 'album_id', $row->{'album_id'}),
		},
	};
}

# one track of an album
sub _trackItem {
	my ($row) = @_;
	return {
		name  => $row->{'title'},
		title => $row->{'title'},
		id    => $row->{'track_id'},
		type  => 'audio',
		play  => $row->{'url'},
		url   => $row->{'url'},
		itemActions => {
			play   => _playlistAction('load',   'track_id', $row->{'track_id'}),
			add    => _playlistAction('add',    'track_id', $row->{'track_id'}),
			insert => _playlistAction('insert', 'track_id', $row->{'track_id'}),
		},
	};
}

# the action used to walk one level down: browselibrary items mode:librarymapper
# with the path carried in the lm_path parameter
sub _goAction {
	my ($enc) = @_;
	return {
		command     => [ 'browselibrary', 'items' ],
		fixedParams => { mode => MODE, lm_path => $enc },
	};
}

sub _playlistAction {
	my ($cmd, $tag, $id) = @_;
	return {
		command     => [ 'playlistcontrol' ],
		fixedParams => { cmd => $cmd, $tag => $id },
	};
}

# ------------------------------------------------------------------ helpers

# Resolve the drill-down path.  Priority:
#   1. the item passthrough (raw path, used by the classic web UI)
#   2. the lm_path parameter (base64url encoded)
# Both carry the same encoded path, so the order does not matter much; the
# decoding is done in every case.
sub _path {
	my ($args, $pt) = @_;

	if ($pt && defined $pt->{'lm_path'} && $pt->{'lm_path'} ne '') {
		return _decode($pt->{'lm_path'});
	}

	if ($args && $args->{'params'} && defined $args->{'params'}->{'lm_path'}) {
		return _decode($args->{'params'}->{'lm_path'});
	}

	if ($pt && $pt->{'searchTags'}) {
		for my $tag (@{ $pt->{'searchTags'} }) {
			next unless $tag =~ /^lm_path:(.*)$/;
			return _decode($1);
		}
	}

	return '';
}

# Read one request parameter, wherever it is carried.
sub _param {
	my ($args, $name) = @_;
	return '' unless $args;
	return $args->{'params'}->{$name}
		if $args->{'params'} && defined $args->{'params'}->{$name};
	if (ref $args eq 'HASH' && defined $args->{$name}) {
		return $args->{$name};
	}
	return '';
}

sub _encode {
	my $s = shift;
	return '' unless defined $s && $s ne '';
	my $b = MIME::Base64::encode_base64($s, '');
	$b =~ tr{+/}{-_};
	$b =~ s/=+$//;
	return $b;
}

sub _decode {
	my $s = shift;
	return '' unless defined $s && $s ne '';
	return $s if $s =~ /\|/;                 # already a raw path
	$s =~ tr{-_}{+/};
	$s .= '=' x ((4 - length($s) % 4) % 4);
	my $d = eval { MIME::Base64::decode_base64($s) };
	return defined $d ? $d : '';
}

1;
