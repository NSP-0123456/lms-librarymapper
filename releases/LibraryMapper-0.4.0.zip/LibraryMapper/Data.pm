package Plugins::LibraryMapper::Data;

use strict;

use File::Basename qw(dirname);
use File::Spec;

use DBI;

use Slim::Utils::Log qw(logger logError logWarning);
use Slim::Utils::Prefs;
use Slim::Utils::OSDetect;

my $log = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

my $DBH;   # dedicated plugin database handle

# The mapping module needs the data module, so it cannot be loaded at the
# top here: it is loaded on demand instead.
sub _mapping { require Plugins::LibraryMapper::Mapping; return 1; }

# The sort order of the artists has no Lyrion dependency either.
sub _sortkey { require Plugins::LibraryMapper::SortKey; return 1; }

# Shared accessors used by Mapping.pm
sub dbh { return $DBH; }
sub to_json {
	my ($data) = @_;
	if (!ref $data) {
		# diagnose instead of dying: log the caller and answer with a JSON error
		require Carp;
		logError("LibraryMapper to_json: non-ref argument '" . ($data // 'undef') . "'\n" . Carp::longmess());
		return '{"error": "librarymapper: to_json received non-ref argument (see server log)"}';
	}
	require JSON::XS;
	return JSON::XS::encode_json($data);
}
sub from_json {
	my ($text) = @_;
	require JSON::XS;
	return JSON::XS::decode_json($text);
}

# ---------------------------------------------------------------- persist dir

sub dbPath {
	my $dir = $prefs->get('dataDir');
	if (!$dir) {
		$dir = eval { Slim::Utils::OSDetect::OS()->dir('prefs') } || '/tmp';
		# never append the plugin dir twice (dir may already end in LibraryMapper)
		$dir = File::Spec->catdir($dir, 'LibraryMapper')
			unless File::Basename::basename($dir) eq 'LibraryMapper';
		$prefs->set('dataDir', $dir);   # persist so we never re-guess
	}
	return File::Spec->catfile($dir, 'librarymapper.db');
}

# ----------------------------------------------------------------- schema

my $SCHEMA = <<'SQL';
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS genre_groups (
	id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE,
	sort_order INTEGER DEFAULT 0, is_default INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS genre_variants (
	variant TEXT PRIMARY KEY,            -- folded display form
	occurrences INTEGER NOT NULL DEFAULT 0,   -- albums referencing it
	proposed_group TEXT, approved TEXT DEFAULT '', approved_by TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS genre_proposals (
	variant TEXT NOT NULL, part TEXT NOT NULL, pos INTEGER NOT NULL,
	group_name TEXT, PRIMARY KEY (variant, pos));
CREATE TABLE IF NOT EXISTS artist_variants (
	variant TEXT PRIMARY KEY, canonical TEXT,
	occurrences INTEGER NOT NULL DEFAULT 0, approved TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS album_artists (
	album_id INTEGER NOT NULL,
	artist_raw TEXT NOT NULL,
	n INTEGER NOT NULL DEFAULT 1,
	PRIMARY KEY (album_id, artist_raw));
CREATE INDEX IF NOT EXISTS idx_aa_album ON album_artists(album_id);
CREATE TABLE IF NOT EXISTS album_artist_map (
	album_id INTEGER PRIMARY KEY,
	artist_raw TEXT,
	resolved TEXT,
	confidence REAL,
	source TEXT);
CREATE TABLE IF NOT EXISTS album_artist_list (
	album_id INTEGER NOT NULL,
	artist TEXT NOT NULL,          -- canonical artist name
	weight INTEGER NOT NULL DEFAULT 1,
	PRIMARY KEY (album_id, artist));
CREATE INDEX IF NOT EXISTS idx_aal_artist ON album_artist_list(artist);
CREATE TABLE IF NOT EXISTS trusted_artists (
	name TEXT PRIMARY KEY,         -- as typed by the user
	added_at INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS contributor_cache (
	contributor_id INTEGER NOT NULL,
	name TEXT NOT NULL,
	role INTEGER NOT NULL,         -- 1 artist, 2 composer, 3 conductor,
	albums INTEGER NOT NULL DEFAULT 0,   -- 4 band, 5 album artist, 6 track artist
	tracks INTEGER NOT NULL DEFAULT 0,
	PRIMARY KEY (contributor_id, role));
CREATE INDEX IF NOT EXISTS idx_cc_name ON contributor_cache(name);
CREATE INDEX IF NOT EXISTS idx_cc_role ON contributor_cache(role);
CREATE TABLE IF NOT EXISTS contributor_mappings (
	role INTEGER NOT NULL,        -- 1 artist, 2 composer, 3 conductor ...
	variant TEXT NOT NULL,         -- the name as written in the tags
	canonical TEXT NOT NULL,       -- the name the user wants to see
	updated_at INTEGER NOT NULL DEFAULT 0,
	PRIMARY KEY (role, variant));
CREATE TABLE IF NOT EXISTS query_results (
	nr INTEGER PRIMARY KEY,       -- the number to use as a reference
	name TEXT NOT NULL,
	role INTEGER NOT NULL DEFAULT 0,
	roles TEXT DEFAULT '',        -- every role of that name, comma separated
	albums INTEGER NOT NULL DEFAULT 0,
	tracks INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS albums_cache (
	album_id INTEGER PRIMARY KEY,
	name TEXT NOT NULL, artist_raw TEXT, genre_raw TEXT,
	year INTEGER, added INTEGER,       -- epoch seconds, from Lyrion index
	quality TEXT,                      -- hires | cd | lossy | unknown
	vpath_genre TEXT, vpath_artist TEXT, vpath_album TEXT);
CREATE INDEX IF NOT EXISTS idx_ac_group ON albums_cache(vpath_genre);
CREATE INDEX IF NOT EXISTS idx_ac_artist ON albums_cache(vpath_artist);
CREATE INDEX IF NOT EXISTS idx_ac_added ON albums_cache(added);
CREATE TABLE IF NOT EXISTS tracks_cache (
	track_id INTEGER PRIMARY KEY,
	album_id INTEGER NOT NULL,
	title TEXT, tracknum INTEGER, disc INTEGER, quality TEXT, url TEXT);
CREATE INDEX IF NOT EXISTS idx_tc_album ON tracks_cache(album_id);
SQL

sub init {
	my $path = dbPath();
	mkdir dirname($path) unless -d dirname($path);
	$DBH = DBI->connect("dbi:SQLite:dbname=$path", '', '', {
		AutoCommit => 1, sqlite_use_immediate_transaction => 1
	}) or do { logError("LibraryMapper: cannot open dedicated db $path: $DBI::errstr"); return; };
	$DBH->do("PRAGMA journal_mode=WAL");
	for my $ddl (split /;\n/, $SCHEMA) {
		$DBH->do($ddl) or logError("LibraryMapper DDL failed: " . $DBI::errstr);
	}
	_migrate();
	$log->info("LibraryMapper dedicated database: $path");
}

# The schema grew after 0.3.0: a table that was created with fewer columns is
# rebuilt instead of being left as it is.
sub _migrate {
	my $cols = $DBH->selectall_arrayref('PRAGMA table_info(query_results)', { Slice => {} });
	my %have = map { $_->{'name'} => 1 } @{ $cols || [] };
	if (%have && !$have{'roles'}) {
		$DBH->do('DROP TABLE query_results');
		$DBH->do('CREATE TABLE query_results (
			nr INTEGER PRIMARY KEY, name TEXT NOT NULL,
			role INTEGER NOT NULL DEFAULT 0, roles TEXT DEFAULT "",
			albums INTEGER NOT NULL DEFAULT 0, tracks INTEGER NOT NULL DEFAULT 0)');
		$log->info("LibraryMapper: query_results table rebuilt");
	}
}

# ------------------------------------------------------------ initialization

# Schema-sensitive probes: Lyrion internal table/column names vary between
# versions; we probe once and remember what worked in meta.
sub _probe {
	require Slim::Schema;
	my $dbh = Slim::Schema->storage->dbh;
	return $dbh;
}

sub _tryQueries {
	my ($dbh, @candidates) = @_;
	for my $sql (@candidates) {
		# no bind parameters are passed: the trailing 3 used here previously
		# made every probe fail with 'called with 1 bind variables'
		my $rows = eval { $dbh->selectall_arrayref($sql, { Slice => {} }) };
		return $rows if $rows;
	}
	return undef;
}

# Runs the initialization scan: reads Lyrion's own index (Slim::Schema) and
# fills albums_cache + raw genre/artist variant lists. Query-only: no tag or
# file writes. Returns a stats hash for the parameter page.
sub runInitialization {
	my $stats = { started => time() };
	unless ($DBH) {
		$stats->{'ok'} = 0;
		$stats->{'error'} = 'database not initialised';
		return $stats;
	}
	my $dbh = _probe();

	# --- probe joins once, remember which shapes worked (Lyrion 9.x: genre_track) --
	my ($gTab, $gJoinA, $gJoinB);
	for my $c (
		['genre_track',  q{SELECT genre, track FROM genre_track LIMIT 2},  'gt.genre = g.id',  'gt.track = t.id'],
		['genres_track', q{SELECT track_id, genre_id FROM genres_track LIMIT 2}, 'gt.genre_id = g.id', 'gt.track_id = t.id'],
		['track_genres', q{SELECT track_id, genre_id FROM track_genres LIMIT 2}, 'gt.genre_id = g.id', 'gt.track_id = t.id'],
	) {
		my ($label, $probeSql, $joinA, $joinB) = @$c;
		if (_tryQueries($dbh, $probeSql)) {
			($gTab, $gJoinA, $gJoinB) = ($label, $joinA, $joinB);
			last;
		}
	}
	$stats->{'genreJoin'} = $gTab || '';

	my $hasAdded = _tryQueries($dbh,
		q{SELECT id, added_time FROM tracks ORDER BY id DESC LIMIT 2},
		q{SELECT id, timestamp FROM tracks ORDER BY id DESC LIMIT 2});
	$stats->{'addedColumn'} = '';
	if ($hasAdded && ref $hasAdded->[0]) {
		$stats->{'addedColumn'} = exists $hasAdded->[0]{added_time} ? 'added_time' : 'timestamp';
	}

	# --- genres ------------------------------------------------------------
	my $genres = [];
	if ($gTab) {
		$genres = eval {
			$dbh->selectall_arrayref(qq{
				SELECT g.name, COUNT(DISTINCT t.album) AS albums
				FROM genres g
				JOIN $gTab gt ON $gJoinA
				JOIN tracks t ON $gJoinB
				GROUP BY g.name ORDER BY albums DESC}, { Slice => {} })
		};
		if (!$genres) { logError("LibraryMapper genres query failed: $@"); $genres = []; }
	}
	else {
		logWarning("LibraryMapper: no genre join table probed - genres skipped");
	}
	for my $g (@$genres) {
		$DBH->do("INSERT OR IGNORE INTO genre_variants(variant, occurrences) VALUES (?, ?)",
			undef, _fold($g->{name}), $g->{albums});
	}
	$stats->{'genreVariants'} = scalar @$genres;

	# seed keyword-rule proposals so the virtual path has groups to use
	Plugins::LibraryMapper::Mapping::repropose();

	# --- artists -----------------------------------------------------------
	# Lyrion 9.x: track <-> contributor links live in contributor_track
	my $artists = eval {
		$dbh->selectall_arrayref(qq{
			SELECT c.name, COUNT(DISTINCT t.album) AS albums
			FROM contributors c
			JOIN contributor_track ct ON ct.contributor = c.id
			JOIN tracks t ON t.id = ct.track
			WHERE ct.role IN (1,5,6)
			GROUP BY c.name ORDER BY albums DESC}, { Slice => {} })
	};
	if (!$artists) { logError("LibraryMapper artists query failed: $@"); $artists = []; }
	my $style = $prefs->get('artistNameStyle') || 'firstlast';
	for my $a (@$artists) {
		# keep an existing (user approved) row untouched
		_setArtistVariant(_fold($a->{name}),
			Plugins::LibraryMapper::Mapping::normalizeArtistName($a->{name}, $style),
			$a->{albums});
	}
	$stats->{'artistVariants'} = scalar @$artists;

	# --- albums cache (artist/genre/year/added/quality) ---------------------
	my $addedExpr = $stats->{'addedColumn'} ? "t.$stats->{addedColumn}" : 'NULL';
	my $albums = eval {
		$dbh->selectall_arrayref(qq{
			SELECT me.id, me.title, me.year, c.name AS artist,
			       MAX($addedExpr) AS added,
			       MAX(t.samplerate) AS sr, MAX(t.lossless) AS lossless, MAX(t.bitrate) AS br
			FROM albums me
			JOIN tracks t ON t.album = me.id
			LEFT JOIN contributors c ON c.id = me.contributor
			GROUP BY me.id, me.title, me.year, artist}, { Slice => {} })
	};
	if (!$albums) { logError("LibraryMapper albums query failed: $@"); $albums = []; }
	$stats->{'albums'} = scalar @$albums;

	my $albumGenre = [];
	if ($gTab) {
		$albumGenre = eval {
			$dbh->selectall_arrayref(qq{
				SELECT t.album, g.name, COUNT(*) AS c
				FROM tracks t
				JOIN $gTab gt ON $gJoinB
				JOIN genres g ON $gJoinA
				GROUP BY t.album, g.name}, { Slice => {} })
		};
		if (!$albumGenre) { logError("LibraryMapper albumGenre query failed: $@"); $albumGenre = []; }
	}
	my %ag;
	for my $r (@$albumGenre) {
		push @{ $ag{ $r->{album} } ||= [] }, [ $r->{name}, $r->{c} ];
	}

	# --- album artists: one canonical name per album ------------------------
	my $artistRows = _albumArtistRows($dbh);
	my $resolution = Plugins::LibraryMapper::Mapping::resolveAlbumArtists(
		$artistRows, $prefs->get('artistNameStyle') || 'firstlast', trustedNames());
	$stats->{'albumArtistRows'} = scalar @$artistRows;
	$stats->{'albumsResolved'} = scalar keys %$resolution;

	$DBH->begin_work;
	$DBH->do("DELETE FROM album_artists");
	$DBH->do("DELETE FROM album_artist_map");
	$DBH->do("DELETE FROM album_artist_list");
	for my $r (@$artistRows) {
		$DBH->do("INSERT OR REPLACE INTO album_artists(album_id, artist_raw, n) VALUES (?,?,?)",
			undef, $r->{album}, $r->{name}, $r->{n});
	}
	for my $a (@$albums) {
		my $g = $ag{ $a->{id} };
		my $genreRaw = $g ? _majority($g) : '';
		my $quality = _quality($a);
		my $res = $resolution->{ $a->{id} };
		my $artist = $res ? $res->{artist} : ($a->{artist} // '');
		my $vPath = _virtualPath($a, $genreRaw, $artist);
		$DBH->do("INSERT OR REPLACE INTO albums_cache(album_id, name, artist_raw, genre_raw, year, added, quality, vpath_genre, vpath_artist, vpath_album)
			VALUES (?,?,?,?,?,?,?,?,?,?)",
			undef, $a->{id}, $a->{title}, ($artist // ''), ($genreRaw ? $genreRaw->[0] : ''),
			$a->{year} || 0, $a->{added} || 0, $quality,
			$vPath->[0], $vPath->[1], $vPath->[2]);
		if ($res) {
			$DBH->do("INSERT OR REPLACE INTO album_artist_map(album_id, artist_raw, resolved, confidence, source)
				VALUES (?,?,?,?,?)",
				undef, $a->{id}, $res->{raw}, $res->{artist}, $res->{confidence}, 'auto');
			# every artist the album belongs to (a collaboration shows up under
			# each of its artists)
			for my $ar (@{ $res->{artists} || [] }) {
				$DBH->do("INSERT OR REPLACE INTO album_artist_list(album_id, artist, weight) VALUES (?,?,?)",
					undef, $a->{id}, $ar->{name}, $ar->{weight});
			}
		}
		else {
			my $unknown = $artist || 'Unknown artist';
			$DBH->do("INSERT OR REPLACE INTO album_artist_list(album_id, artist, weight) VALUES (?,?,?)",
				undef, $a->{id}, $unknown, 1);
		}
	}
	$DBH->commit;

	# --- artist variants: raw spelling -> canonical "First Last" ------------
	{
		my %perVariant;
		for my $r (@$artistRows) {
			my $norm = Plugins::LibraryMapper::Mapping::normalizeArtistName(
				$r->{name}, $prefs->get('artistNameStyle') || 'firstlast');
			next unless $norm;
			my $key = _fold($r->{name});
			$perVariant{$key}{canonical} = $norm;
			$perVariant{$key}{albums}{$r->{album}} = 1;
		}
		for my $key (keys %perVariant) {
			my $occ = scalar keys %{ $perVariant{$key}{albums} };
			_setArtistVariant($key, $perVariant{$key}{canonical}, $occ);
		}
	}

	# --- contributor cache: artists, composers, conductors -------------------
	# Every contributor of the library with the roles it is credited with.
	# This is what the regex search runs on.
	{
		my $ct = eval {
			$dbh->selectall_arrayref(qq{
				SELECT ct.contributor AS cid, c.name AS name, ct.role AS role,
				       COUNT(DISTINCT t.album) AS albums, COUNT(*) AS tracks
				FROM contributor_track ct
				JOIN tracks t ON t.id = ct.track
				JOIN contributors c ON c.id = ct.contributor
				GROUP BY ct.contributor, ct.role}, { Slice => {} })
		};
		if (!$ct) { logError("LibraryMapper contributor_track query failed: $@"); $ct = []; }
		my $ca = eval {
			$dbh->selectall_arrayref(qq{
				SELECT ca.contributor AS cid, c.name AS name, ca.role AS role,
				       COUNT(DISTINCT ca.album) AS albums, 0 AS tracks
				FROM contributor_album ca
				JOIN contributors c ON c.id = ca.contributor
				GROUP BY ca.contributor, ca.role}, { Slice => {} })
		};
		if (!$ca) { logError("LibraryMapper contributor_album query failed: $@"); $ca = []; }

		my %agg;
		for my $r (@$ct, @$ca) {
			next unless defined $r->{'cid'} && defined $r->{'name'};
			my $key = $r->{'cid'} . ':' . $r->{'role'};
			my $e = $agg{$key} ||= {
				cid => $r->{'cid'}, name => $r->{'name'},
				role => $r->{'role'}, albums => 0, tracks => 0 };
			$e->{'albums'} += $r->{'albums'} || 0;
			$e->{'tracks'} += $r->{'tracks'} || 0;
		}
		$DBH->begin_work;
		$DBH->do('DELETE FROM contributor_cache');
		my $ins = $DBH->prepare(
			'INSERT OR REPLACE INTO contributor_cache(contributor_id, name, role, albums, tracks) VALUES (?,?,?,?,?)');
		for my $e (values %agg) {
			$ins->execute($e->{'cid'}, $e->{'name'}, $e->{'role'}, $e->{'albums'}, $e->{'tracks'});
		}
		$ins->finish;
		$DBH->commit;
		$stats->{'contributors'} = scalar keys %agg;
	}

	# --- tracks cache (track lists ordered by disc / track number) ----------
	{
		my $tracks = eval {
			$dbh->selectall_arrayref(qq{
				SELECT me.id, me.title, me.tracknum, me.disc, me.album AS album_id,
				       me.samplerate AS sr, me.lossless AS lossless, me.bitrate AS br,
				       me.url AS url
				FROM tracks me}, { Slice => {} })
		};
		if (!$tracks) { logError("LibraryMapper tracks scan failed: $@"); $tracks = []; }
		$stats->{'tracks'} = scalar @$tracks;
		{
			my $ins = $DBH->prepare(
				'INSERT OR REPLACE INTO tracks_cache(track_id, album_id, title, tracknum, disc, quality, url) VALUES (?,?,?,?,?,?,?)');
			$DBH->begin_work;
			for my $t (@$tracks) {
				$ins->execute($t->{id}, $t->{album_id}, $t->{title}, $t->{tracknum}, $t->{disc},
					_quality($t), $t->{url});
			}
			$ins->finish;
			$DBH->commit;
		}
	}

	$DBH->do("INSERT OR REPLACE INTO meta(key, value) VALUES ('lastInit', ?)", undef, time());
	$stats->{'duration'} = time() - $stats->{'started'};
	$stats->{'ok'} = 1;
	return $stats;
}

# Artist spellings per album.  Album-artist links (role 5 = ALBUMARTIST) weigh
# much more than plain track artists so that the album artist wins.
sub _albumArtistRows {
	my ($dbh) = @_;
	my @rows;

	my $albumArtists = eval {
		$dbh->selectall_arrayref(qq{
			SELECT ca.album AS album, c.name AS name, COUNT(*) AS n
			FROM contributor_album ca
			JOIN contributors c ON c.id = ca.contributor
			WHERE ca.role = 5
			GROUP BY ca.album, c.name}, { Slice => {} })
	};
	if ($albumArtists && @$albumArtists) {
		for my $r (@$albumArtists) {
			push @rows, { album => $r->{album}, name => $r->{name}, n => 10 * ($r->{n} || 1) };
		}
	}
	else {
		logWarning("LibraryMapper: no contributor_album rows - falling back to track artists");
	}

	my $trackArtists = eval {
		$dbh->selectall_arrayref(qq{
			SELECT t.album AS album, c.name AS name, COUNT(*) AS n
			FROM tracks t
			JOIN contributor_track ct ON ct.track = t.id
			JOIN contributors c ON c.id = ct.contributor
			WHERE ct.role IN (1,5)
			GROUP BY t.album, c.name}, { Slice => {} })
	};
	if ($trackArtists && @$trackArtists) {
		for my $r (@$trackArtists) {
			push @rows, { album => $r->{album}, name => $r->{name}, n => ($r->{n} || 1) };
		}
	}
	return \@rows;
}

sub _fold { my $s = shift; return '' unless defined $s; $s =~ s/^\s+|\s+$//g; return lc $s; }

# Upsert one artist spelling.  The "approved" column (a user correction made
# on the parameter page) is never overwritten by a re-run of the scan.
sub _setArtistVariant {
	my ($variant, $canonical, $occurrences) = @_;
	return 0 unless defined $variant && $variant ne '';
	my $n = $DBH->do('UPDATE artist_variants SET canonical=?, occurrences=? WHERE variant=?',
		undef, $canonical, $occurrences, $variant);
	return 1 if $n && $n ne '0' && $n ne '0E0';
	$DBH->do('INSERT INTO artist_variants(variant, canonical, occurrences, approved) VALUES (?,?,?,?)',
		undef, $variant, $canonical, $occurrences, '');
	return 1;
}
sub _majority {
	my $list = shift;
	my @sorted = sort { $b->[1] <=> $a->[1] } @$list;
	return $sorted[0];
}
sub _quality {
	my $a = shift;
	return 'lossy'  if defined $a->{'lossless'} && !$a->{'lossless'};
	return 'hires'  if $a->{'sr'} && $a->{'sr'} > 48400;
	return 'cd'     if $a->{'sr'} && $a->{'sr'} > 40000;
	return 'unknown';
}
sub _virtualPath {
	my ($a, $genreRaw, $artistRaw) = @_;
	my $group   = Plugins::LibraryMapper::Mapping::mappedGroup($genreRaw ? $genreRaw->[0] : '') // 'Unsorted';
	my $artist  = $artistRaw || 'Unknown artist';
	my $year    = $a->{'year'} || '????';
	return [ $group, $artist, "$year - $a->{'title'}" ];
}

# ------------------------------------------------------------------ queries

sub status {
	my ($out) = @_;
	return { error => 'database not initialised', albums => 0 } unless $DBH;
	my ($lastInit) = $DBH->selectrow_array("SELECT value FROM meta WHERE key='lastInit'");
	$out = {
		dbPath    => dbPath(),
		lastInit  => $lastInit || 0,
		lastInitText => $lastInit ? scalar(localtime($lastInit)) : '',
		albums    => $DBH->selectrow_array('SELECT COUNT(*) FROM albums_cache'),
		genreVariants => $DBH->selectrow_array('SELECT COUNT(*) FROM genre_variants'),
		groups    => $DBH->selectrow_array('SELECT COUNT(*) FROM genre_groups'),
		mapped    => $DBH->selectrow_array('SELECT COUNT(*) FROM genre_variants WHERE approved<>""'),
		artistVariants => $DBH->selectrow_array('SELECT COUNT(*) FROM artist_variants'),
		artistMapped  => $DBH->selectrow_array('SELECT COUNT(*) FROM artist_variants WHERE approved<>""'),
		albumsResolved => $DBH->selectrow_array('SELECT COUNT(*) FROM album_artist_map'),
		artistLinks    => $DBH->selectrow_array('SELECT COUNT(*) FROM album_artist_list'),
		collaborations => $DBH->selectrow_array(
			'SELECT COUNT(*) FROM (SELECT album_id FROM album_artist_list GROUP BY album_id HAVING COUNT(*) > 1)'),
		trusted    => $DBH->selectrow_array('SELECT COUNT(*) FROM trusted_artists'),
		contributors => $DBH->selectrow_array('SELECT COUNT(DISTINCT name) FROM contributor_cache'),
	};
	return $out;
}

sub getGenreGroups {
	return [] unless $DBH;
	return $DBH->selectall_arrayref('SELECT id, name, sort_order, is_default FROM genre_groups ORDER BY sort_order, name', { Slice => {} });
}

sub topVariants {
	my $n = shift || 25;
	return [] unless $DBH;
	return $DBH->selectall_arrayref('SELECT variant, occurrences, proposed_group, approved FROM genre_variants ORDER BY occurrences DESC LIMIT ?', { Slice => {} }, $n );
}

sub topArtistVariants {
	my $n = shift || 25;
	return [] unless $DBH;
	return $DBH->selectall_arrayref(
		'SELECT variant, CASE WHEN approved<>"" THEN approved ELSE canonical END AS canonical,
		        occurrences, approved
		 FROM artist_variants ORDER BY occurrences DESC LIMIT ?',
		{ Slice => {} }, $n );
}

# Albums that are credited to more than one artist (a collaboration) or that
# carry several spellings of the same artist: the report of albums that could
# show up twice in the tree.
sub ambiguousAlbums {
	my $n = shift || 25;
	return [] unless $DBH;
	return $DBH->selectall_arrayref(qq{
		SELECT m.album_id, a.name AS album, m.resolved, m.confidence,
		       (SELECT COUNT(*) FROM album_artist_list l WHERE l.album_id = m.album_id) AS artists,
		       (SELECT COUNT(*) FROM album_artists aa WHERE aa.album_id = m.album_id) AS spellings,
		       (SELECT GROUP_CONCAT(l2.artist) FROM album_artist_list l2 WHERE l2.album_id = m.album_id) AS artist_list
		FROM album_artist_map m
		JOIN albums_cache a ON a.album_id = m.album_id
		WHERE artists > 1 OR spellings > 1
		ORDER BY artists DESC, spellings DESC, m.album_id LIMIT ?}, { Slice => {} }, $n );
}

# Approve (or clear) the canonical name of one artist spelling.  The row is
# created when it does not exist yet: a composer or a conductor may have no
# spelling row at all.
sub setArtistCanonical {
	my ($variant, $canonical) = @_;
	return 0 unless $DBH;
	return 0 unless defined $variant && $variant ne '';
	$canonical = '' unless defined $canonical;
	my $n = $DBH->do('UPDATE artist_variants SET approved=? WHERE variant=?',
		undef, $canonical, $variant);
	return 1 if $n && $n ne '0' && $n ne '0E0';
	$DBH->do('INSERT INTO artist_variants(variant, canonical, occurrences, approved) VALUES (?,?,?,?)',
		undef, $variant, '', 0, $canonical);
	return 1;
}

# ------------------------------------------------------- trusted artists
#
# A trusted name is an artist that is always ONE artist: the credit is never
# split and the albums credited to it are filed under it alone.  The user
# uploads the list of those names on the parameter page.

# The trusted names, with the number of albums currently filed under them.
sub trustedArtists {
	return [] unless $DBH;
	return $DBH->selectall_arrayref(qq{
		SELECT t.name AS name, t.added_at AS added_at,
		       (SELECT COUNT(*) FROM album_artist_list l WHERE l.artist = t.name) AS albums
		FROM trusted_artists t ORDER BY t.name}, { Slice => {} });
}

# The trusted names only (used by the artist resolution).
sub trustedNames {
	return [] unless $DBH;
	my $rows = $DBH->selectcol_arrayref('SELECT name FROM trusted_artists ORDER BY name');
	return $rows || [];
}

# Add names to the trusted list.  With $replace the whole list is replaced.
sub addTrustedArtists {
	my ($names, $replace) = @_;
	return 0 unless $DBH;
	my @clean;
	my %seen;
	for my $n (@{ $names || [] }) {
		next unless defined $n;
		$n =~ s/^\s+|\s+$//g;
		next unless $n ne '';
		next if $seen{lc $n}++;
		push @clean, $n;
	}
	return 0 unless @clean;
	$DBH->do('DELETE FROM trusted_artists') if $replace;
	my $ins = $DBH->prepare('INSERT OR REPLACE INTO trusted_artists(name, added_at) VALUES (?,?)');
	$DBH->begin_work;
	for my $n (@clean) { $ins->execute($n, time()); }
	$DBH->commit;
	$ins->finish;
	return scalar @clean;
}

# Remove one name from the trusted list.
sub removeTrustedArtist {
	my ($name) = @_;
	return 0 unless $DBH;
	return 0 unless defined $name && $name ne '';
	$DBH->do('DELETE FROM trusted_artists WHERE name=?', undef, $name);
	return 1;
}

# Re-resolve the album artists from the cached raw credits.  No Lyrion access
# is needed, so this runs in a second: it is used after the trusted list or
# the artist corrections changed.  Returns the number of albums resolved.
sub reresolveArtists {
	return 0 unless $DBH;
	my $rows = $DBH->selectall_arrayref(
		'SELECT album_id AS album, artist_raw AS name, n FROM album_artists', { Slice => {} });
	return 0 unless $rows && @$rows;

	my $style = $prefs->get('artistNameStyle') || 'firstlast';
	my $res = Plugins::LibraryMapper::Mapping::resolveAlbumArtists(
		$rows, $style, trustedNames());

	$DBH->begin_work;
	$DBH->do('DELETE FROM album_artist_list');
	my $upArt = $DBH->prepare('UPDATE album_artist_map SET resolved=?, confidence=? WHERE album_id=?');
	my $upAlb = $DBH->prepare('UPDATE albums_cache SET artist_raw=?, vpath_artist=? WHERE album_id=?');
	for my $a (@$rows) {
		my $r = $res->{ $a->{'album'} };
		next unless $r;
		for my $ar (@{ $r->{'artists'} || [] }) {
			$DBH->do('INSERT OR REPLACE INTO album_artist_list(album_id, artist, weight) VALUES (?,?,?)',
				undef, $a->{'album'}, $ar->{'name'}, $ar->{'weight'});
		}
		$upArt->execute($r->{'artist'}, $r->{'confidence'}, $a->{'album'});
		$upAlb->execute($r->{'artist'}, $r->{'artist'}, $a->{'album'});
	}
	$upArt->finish;
	$upAlb->finish;
	# albums without any artist credit keep their "Unknown artist" entry
	$DBH->do(qq{
		INSERT OR IGNORE INTO album_artist_list(album_id, artist, weight)
		SELECT a.album_id, 'Unknown artist', 1
		FROM albums_cache a
		WHERE NOT EXISTS (SELECT 1 FROM album_artist_list l WHERE l.album_id = a.album_id)});
	$DBH->commit;
	return scalar keys %$res;
}

# ------------------------------------------------------------------ search
#
# A regex search over the contributors of the library (artists, composers,
# conductors).  The result is an ordered and numbered list: the number is the
# reference the user can use to apply a mapping to that row later on.

my %ROLE_TOKEN = (
	1 => 'PLUGIN_LIBRARYMAPPER_ROLE_ARTIST',
	2 => 'PLUGIN_LIBRARYMAPPER_ROLE_COMPOSER',
	3 => 'PLUGIN_LIBRARYMAPPER_ROLE_CONDUCTOR',
	4 => 'PLUGIN_LIBRARYMAPPER_ROLE_BAND',
	5 => 'PLUGIN_LIBRARYMAPPER_ROLE_ALBUMARTIST',
	6 => 'PLUGIN_LIBRARYMAPPER_ROLE_TRACKARTIST',
);

# the string token of a role number ('' for an unknown role)
sub roleToken { my $r = shift || 0; return $ROLE_TOKEN{ 0 + $r } || ''; }

# The names of the roles the search can filter on.
sub searchRoles {
	return [
		{ value => 'all', token => 'PLUGIN_LIBRARYMAPPER_S_ALLROLES' },
		{ value => 1, token => $ROLE_TOKEN{1} },
		{ value => 2, token => $ROLE_TOKEN{2} },
		{ value => 3, token => $ROLE_TOKEN{3} },
		{ value => 4, token => $ROLE_TOKEN{4} },
		{ value => 5, token => $ROLE_TOKEN{5} },
		{ value => 6, token => $ROLE_TOKEN{6} },
	];
}

# Search the contributors.
#   $pattern : a Perl regular expression
#   $roles   : 'all' or a role number (1 artist, 2 composer, 3 conductor ...)
#   $opts    : { caseSensitive => 0|1 }
# Returns { rows => [ { nr, name, role, roleTokens, albums, tracks, mapping } ],
#           count, pattern, error }
sub queryContributors {
	my ($pattern, $roles, $opts) = @_;
	$opts ||= {};
	return { error => 'database not initialised', rows => [], count => 0 } unless $DBH;

	$pattern = '' unless defined $pattern;
	$pattern =~ s/^\s+|\s+$//g;
	return { error => 'no pattern', rows => [], count => 0 } if $pattern eq '';

	# the pattern is a regular expression; the match ignores the case unless
	# the page asks for a case sensitive search
	my $re = $opts->{'caseSensitive'}
		? eval { qr/$pattern/ }
		: eval { qr/$pattern/i };
	if (!$re) {
		logError("LibraryMapper search: invalid regular expression '$pattern'");
		return { error => 'invalid regular expression', rows => [], count => 0, pattern => $pattern };
	}

	# the role filter
	my %want;
	if (defined $roles && $roles ne '' && lc $roles ne 'all' && $roles ne '0') {
		for my $r ($roles =~ /(\d+)/g) { $want{0 + $r} = 1; }
	}

	my $rows = $DBH->selectall_arrayref(
		'SELECT name, role, albums, tracks FROM contributor_cache', { Slice => {} }) || [];

	my %byName;
	for my $r (@$rows) {
		next unless defined $r->{'name'} && $r->{'name'} ne '';
		next if %want && !$want{ $r->{'role'} };
		next unless $r->{'name'} =~ $re;
		my $e = $byName{ $r->{'name'} };
		if (!$e) {
			$e = $byName{ $r->{'name'} } = {
				name => $r->{'name'}, role => $r->{'role'},
				albums => 0, tracks => 0, roles => {} };
		}
		$e->{'albums'} += $r->{'albums'} || 0;
		$e->{'tracks'} += $r->{'tracks'} || 0;
		$e->{'roles'}{ $r->{'role'} } = 1;
		$e->{'role'} = $r->{'role'} if $r->{'role'} < $e->{'role'};
	}

	# alphabetical order: a person under its last name, a group under the
	# name it carries; then numbered: the number is the reference
	_sortkey();
	my @out = sort {
		my $ka = Plugins::LibraryMapper::SortKey::artistSortKey($a->{'name'});
		my $kb = Plugins::LibraryMapper::SortKey::artistSortKey($b->{'name'});
		$ka cmp $kb || lc($a->{'name'}) cmp lc($b->{'name'});
	} values %byName;

	my $style = $prefs->get('artistNameStyle') || 'firstlast';
	my $nr = 0;
	_mapping();
	for my $e (@out) {
		$e->{'nr'} = ++$nr;
		# the key the name is filed under: it shows the user where the
		# artist will end up in the alphabetical order
		$e->{'sortKey'} = Plugins::LibraryMapper::SortKey::artistSortKey($e->{'name'});
		$e->{'roleTokens'} = [ map { roleToken($_) } sort { $a <=> $b } keys %{ $e->{'roles'} } ];
		$e->{'mapping'} = Plugins::LibraryMapper::Mapping::roleCanonical(
			$e->{'name'}, $e->{'role'}, $style);
	}

	# keep the result: the numbers are the references of the mapping
	$DBH->begin_work;
	$DBH->do('DELETE FROM query_results');
	my $ins = $DBH->prepare(
		'INSERT OR REPLACE INTO query_results(nr, name, role, roles, albums, tracks) VALUES (?,?,?,?,?,?)');
	for my $e (@out) {
		$ins->execute($e->{'nr'}, $e->{'name'}, $e->{'role'},
			join(',', @{ $e->{'roleTokens'} }), $e->{'albums'}, $e->{'tracks'});
	}
	$ins->finish;
	$DBH->commit;

	return { rows => \@out, count => scalar @out, pattern => $pattern };
}

# The result of the last search, with the current mapping of every row.
sub lastQueryResults {
	return [] unless $DBH;
	my $rows = $DBH->selectall_arrayref(
		'SELECT nr, name, role, roles, albums, tracks FROM query_results ORDER BY nr',
		{ Slice => {} }) || [];
	my $style = $prefs->get('artistNameStyle') || 'firstlast';
	_mapping();
	for my $r (@$rows) {
		my @roles = grep { $_ =~ /^\d+$/ } split /,/, ($r->{'roles'} // '');
		$r->{'roleTokens'} = @roles ? [ map { 0 + $_ } @roles ] : [ $r->{'role'} ];
		$r->{'mapping'} = Plugins::LibraryMapper::Mapping::roleCanonical(
			$r->{'name'}, $r->{'role'}, $style);
	}
	return $rows;
}

# The name of a search result, by its reference number.
sub queryResultName {
	my ($nr) = @_;
	return '' unless $DBH;
	return '' unless defined $nr && $nr =~ /^\d+$/;
	my ($name) = $DBH->selectrow_array('SELECT name FROM query_results WHERE nr=?', undef, $nr);
	return $name || '';
}

# Apply a mapping to one search result.  $ref is the reference number of the
# row (or the name itself).  An empty canonical name clears the mapping.
sub setContributorMapping {
	my ($ref, $canonical, $role) = @_;
	return 0 unless $DBH;
	return 0 unless defined $ref && $ref ne '';

	my ($name, $useRole);
	if ($ref =~ /^\d+$/ && $ref > 0) {
		my $row = $DBH->selectrow_hashref(
			'SELECT name, role FROM query_results WHERE nr=?', undef, $ref);
		return 0 unless $row;
		$name = $row->{'name'};
		$useRole = $row->{'role'};
	}
	else {
		$name = $ref;
		$useRole = ($role && $role =~ /^\d+$/) ? 0 + $role : 1;
	}
	$useRole = 1 unless $useRole;
	$canonical = '' unless defined $canonical;
	$canonical =~ s/^\s+|\s+$//g;

	# the mapping cell accepts the number of another row as a reference:
	# "12" means "the name of row 12"
	if ($canonical =~ /^\d+$/ && $canonical > 0 && !($ref =~ /^\d+$/ && $ref == $canonical)) {
		my ($other) = $DBH->selectrow_array(
			'SELECT name FROM query_results WHERE nr=?', undef, $canonical);
		$canonical = $other if defined $other && $other ne '';
	}

	if ($canonical eq '') {
		$DBH->do('DELETE FROM contributor_mappings WHERE role=? AND variant=?',
			undef, $useRole, _fold($name));
	}
	else {
		$DBH->do('INSERT OR REPLACE INTO contributor_mappings(role, variant, canonical, updated_at) VALUES (?,?,?,?)',
			undef, $useRole, _fold($name), $canonical, time());
	}
	# an artist mapping is also the artist spelling correction: the tree
	# shows the corrected name
	if ($useRole == 1) {
		setArtistCanonical(_fold($name), $canonical);
		# a corrected artist changes the tree: re-resolve from the cached credits
		reresolveArtists();
	}
	return 1;
}

# virtual browse: categories query only.
# Returns { type, rows, title } where:
#   level  -> list of { key, n }          (genres, or artists within a genre)
#   albums -> list of album rows          (within a genre + artist)
#   tracks -> list of tracks (disc/tracknum order) of ONE album
sub browse {
	my %args = @_;
	return { type => 'level', rows => [], title => '' } unless $DBH;
	my $limit = ($args{'list'} && $args{'list'} =~ /^\d+$/ && $args{'list'} > 0)
		? $args{'list'} : ($prefs->get('listLimit') || 100);
	my $order = $args{'order'} || 'alpha';
	my $filterSql = ' WHERE 1=1';
	my @filterP;
	if (my $t = $args{'time'}) {
		if ($t ne 'all') { $filterSql .= ' AND a.added >= ?'; push @filterP, _timeStart($t); }
	}
	if (my $q = $args{'quality'}) {
		if ($q ne 'all') { $filterSql .= ' AND a.quality = ?'; push @filterP, $q; }
	}

	# The artist filter is a regular expression: it selects the artists of
	# the current genre group.
	my $pattern = $args{'filter'};
	$pattern = '' unless defined $pattern;
	$pattern =~ s/^\s+|\s+$//g;
	my $filterRe;
	my $filterError = 0;
	if ($pattern ne '') {
		$filterRe = eval { qr/$pattern/i };
		if (!$filterRe) {
			logError("LibraryMapper browse: invalid artist filter '$pattern'");
			$filterRe = undef;
			$filterError = 1;
		}
	}

	# The drill-down path is "genre|artist|album_id":
	#   1 element  - the genre groups
	#   2 elements - the artists of one genre group
	#   3 elements - the albums of one artist within one genre group
	# and the album id identifies the tracks.
	if (my $p = $args{'parent'}) {
		my @path = split /\|/, $p;
		if (@path >= 3) {
			# drill into an album: tracks in disc / track-number order
			my $rows = $DBH->selectall_arrayref(qq{
				SELECT title, tracknum, disc, quality, track_id, url FROM tracks_cache
				WHERE album_id = ?
				ORDER BY COALESCE(disc,1), COALESCE(tracknum,9999), title
				LIMIT ?}, { Slice => {} }, $path[2], $limit);
			return { type => 'tracks', rows => $rows, title => $path[1], parent => $p,
			         filter => $pattern, filterError => $filterError };
		}
		elsif (@path == 2) {
			# albums of one artist within one genre group
			my $ordering = $order eq 'newer' ? 'a.year DESC, a.name ASC' : 'a.name ASC';
			my $rows = $DBH->selectall_arrayref(qq{
				SELECT a.vpath_genre AS vpath_genre, l.artist AS vpath_artist,
				       a.vpath_album AS vpath_album, a.name AS name, a.year AS year,
				       a.album_id AS album_id, a.quality AS quality
				FROM albums_cache a
				JOIN album_artist_list l ON l.album_id = a.album_id
				$filterSql
				AND a.vpath_genre = ? AND l.artist = ?
				ORDER BY $ordering LIMIT ?}, { Slice => {} }, @filterP, $path[0], $path[1], $limit);
			return { type => 'albums', rows => $rows, title => $path[1], parent => $p,
			         filter => $pattern, filterError => $filterError };
		}
		elsif ($path[0]) {
			# artists within one genre group
			my $rows = $DBH->selectall_arrayref(qq{
				SELECT l.artist AS key, COUNT(DISTINCT a.album_id) AS n
				FROM album_artist_list l
				JOIN albums_cache a ON a.album_id = l.album_id
				$filterSql
				AND a.vpath_genre = ?
				GROUP BY l.artist},
				{ Slice => {} }, @filterP, $path[0]);
			# the order is the alphabetical one of the artists: a person under
			# its last name, a group under the name it carries
			$rows = _sortArtists($rows);
			# the regex filter narrows the list down
			$rows = [ grep { $_->{'key'} =~ $filterRe } @$rows ] if $filterRe;
			$rows = [ @{$rows}[ 0 .. $limit - 1 ] ] if @$rows > $limit;
			return { type => 'level', rows => $rows, title => $path[0], parent => $p,
			         level => 'artists',
			         filter => $pattern, filterError => $filterError };
		}
	}

	# top: genre groups
	my $rows = $DBH->selectall_arrayref(qq{
		SELECT a.vpath_genre AS key, COUNT(DISTINCT a.album_id) AS n
		FROM albums_cache a$filterSql
		GROUP BY a.vpath_genre ORDER BY a.vpath_genre LIMIT ?},
		{ Slice => {} }, @filterP, $limit);
	return { type => 'level', rows => $rows, title => '', filter => $pattern,
	         level => 'genres',
	         filterError => $filterError };
}

# The alphabetical order of the artists: a person is filed under its last
# name, a group under the name it carries ("Claude Nougaro" -> N,
# "Metallica" -> M).
sub _sortArtists {
	my $rows = shift;
	_sortkey();
	my @out = sort {
		my $ka = Plugins::LibraryMapper::SortKey::artistSortKey($a->{'key'});
		my $kb = Plugins::LibraryMapper::SortKey::artistSortKey($b->{'key'});
		$ka cmp $kb || lc($a->{'key'}) cmp lc($b->{'key'});
	} @$rows;
	return \@out;
}

sub _timeStart {
	my $what = shift;
	my $now = time();
	return $now - 86_400        if $what eq 'day';
	return $now - 7 * 86_400    if $what eq 'week';
	return $now - 30 * 86_400   if $what eq 'month';
	return $now - 365 * 86_400  if $what eq 'year';
	return 0;
}

1;
