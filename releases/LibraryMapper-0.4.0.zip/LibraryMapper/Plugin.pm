package Plugins::LibraryMapper::Plugin;

use strict;
use base qw(Slim::Plugin::Base);

use Slim::Web::Pages;
use Slim::Web::HTTP;
use Slim::Utils::Log qw(logger logError logWarning);
use Slim::Utils::Prefs;
use POSIX qw(strftime);

use Plugins::LibraryMapper::Data;
use Plugins::LibraryMapper::Mapping;

my $log   = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

$prefs->init({
	quality_default => 'all',
	time_default    => 'all',
	order_default   => 'alpha',
	listLimit       => 100,
	artistNameStyle => 'firstlast',
});

sub initPlugin {
	my $class = shift;
	$class->SUPER::initPlugin(@_);

	# Every part of the plugin is guarded: a plugin error must never keep the
	# music server from starting.  Each step logs its own failure.
	eval {
		Plugins::LibraryMapper::Data::init();
		1;
	} or do { logError("LibraryMapper: database init failed: $@"); };

	# Main application page ("virtual browse")
	eval {
		Slim::Web::Pages->addPageFunction(
			"plugins/LibraryMapper/index\.(?:htm|ml)?",
			\&pageApp
		);

		# Download endpoint: mapping file as JSON
		Slim::Web::Pages->addPageFunction(
			"plugins/LibraryMapper/download\.(?:htm|json)?",
			\&pageDownload
		);

		# Download endpoint: the mapping as an editable plain text list.
		# The name does not start with "download" so that it cannot match
		# the JSON endpoint above.
		Slim::Web::Pages->addPageFunction(
			"plugins/LibraryMapper/mapping-list\.(?:txt|list)?",
			\&pageDownloadList
		);
		1;
	} or do { logError("LibraryMapper: page registration failed: $@"); };

	# Settings page (parameter page: init + validation + upload mapping)
	eval {
		require Plugins::LibraryMapper::Settings;
		Plugins::LibraryMapper::Settings->new();
		1;
	} or do { logError("LibraryMapper: settings page failed: $@"); };

	# --- native browse mode: "Simplified View" inside My Music --------------
	eval {
		require Plugins::LibraryMapper::Browse;
		require Slim::Menu::BrowseLibrary;

		# the drill-down path travels in "lm_path": make it a top level argument
		# so that it survives the Lyrion browse parameter handling
		push @Slim::Menu::BrowseLibrary::topLevelArgs, 'lm_path'
			unless grep { $_ eq 'lm_path' } @Slim::Menu::BrowseLibrary::topLevelArgs;

		Slim::Menu::BrowseLibrary->registerNode({
			id           => 'myMusicLibraryMapper',
			type         => 'link',
			name         => 'PLUGIN_LIBRARYMAPPER_VIEW',
			params       => { mode => 'librarymapper' },
			feed         => \&Plugins::LibraryMapper::Browse::feed,
			icon         => 'html/images/genres.png',
			jiveIcon     => 'html/images/genres.png',
			homeMenuText => 'PLUGIN_LIBRARYMAPPER_VIEW',
			condition    => \&Slim::Menu::BrowseLibrary::isEnabledNode,
			weight       => 28,             # just before the genres (30)
			cache        => 1,
		});
		1;
	} or do { logError("LibraryMapper: browse node registration failed: $@"); };

	# classic skins: My Music entry pointing at the standard LMS browse page
	eval {
		Slim::Web::Pages->addPageLinks('browse', {
			'PLUGIN_LIBRARYMAPPER_VIEW' =>
				'clixmlbrowser/clicmd=browselibrary+items&linktitle=PLUGIN_LIBRARYMAPPER_VIEW&mode=librarymapper/',
		});
		1;
	} or do { logError("LibraryMapper: home page link failed: $@"); };

	# CLI helpers (used for scripted initialization and diagnostics)
	eval {
		require Slim::Control::Request;
		Slim::Control::Request::addDispatch(
			[ 'librarymapper', 'init' ],   [ 0, 1, 1, \&cmdInit ] );
		Slim::Control::Request::addDispatch(
			[ 'librarymapper', 'status' ], [ 0, 1, 1, \&cmdStatus ] );
		Slim::Control::Request::addDispatch(
			[ 'librarymapper', 'browse' ], [ 0, 1, 1, \&cmdBrowse ] );
		Slim::Control::Request::addDispatch(
			[ 'librarymapper', 'query' ],  [ 0, 1, 1, \&cmdQuery ] );
		Slim::Control::Request::addDispatch(
			[ 'librarymapper', 'map' ],    [ 0, 1, 1, \&cmdMap ] );
		1;
	} or do { logError("LibraryMapper: CLI dispatch failed: $@"); };

	$log->info("LibraryMapper initialized");
}

# ---------------------------------------------------------------- app page

sub pageApp {
	my ($client, $params, $cb, $httpClient, $response) = @_;

	$log->debug("pageApp requested: parent=" . ($params->{'parent'} // ''));

	my $time  = $params->{'time'}    || $prefs->get('time_default');
	my $qualt = $params->{'quality'} || $prefs->get('quality_default');
	my $order = $params->{'order'}   || $prefs->get('order_default');
	my $list  = $params->{'list'}    || $prefs->get('listLimit');
	my $filter = $params->{'filter'} || '';

	my $view = Plugins::LibraryMapper::Data::browse(
		parent    => $params->{'parent'},     # e.g. "Blues|John Mayall|1970 - Empty Rooms" drill path
		time      => $time,
		quality   => $qualt,
		order     => $order,                  # alpha | newer (album order at the last level)
		list      => $list,                   # max items shown per list step
		filter    => $filter,                 # regular expression on the artists
	);

	$params->{'view'}        = $view;
	$params->{'parentFilter'} = $params->{'parent'} || '';
	$params->{'time'}    = $time;
	$params->{'quality'} = $qualt;
	$params->{'order'}   = $order;
	$params->{'list'}    = $list;
	$params->{'filter'}  = $filter;

	return Slim::Web::HTTP::filltemplatefile('plugins/LibraryMapper/index.html', $params);
}

# ------------------------------------------------------------ settings page

sub pageSettings {
	my ($client, $params) = @_;
	require Plugins::LibraryMapper::Settings;
	Plugins::LibraryMapper::Settings::handler($client, $params);
}

# ------------------------------------------------------------- download API

sub pageDownload {
	my ($client, $params, $cb, $httpClient, $response) = @_;

	$log->debug("pageDownload requested");

	my $json = Plugins::LibraryMapper::Mapping::exportMapping()
		|| '{"error": "no mapping exists yet"}';

	if ($response) {
		$response->content_type('application/json');
		# the browser saves the file instead of showing it
		my $name = 'librarymapper-' . strftime('%Y-%m-%d', localtime()) . '.json';
		$response->header('Content-Disposition' => "attachment; filename=\"$name\"");
	}

	return \$json;
}

# The mapping as an editable plain text list: this is the file the user
# edits and pastes back into the parameter page.
sub pageDownloadList {
	my ($client, $params, $cb, $httpClient, $response) = @_;

	$log->debug("pageDownloadList requested");

	my $text = Plugins::LibraryMapper::Mapping::exportList();

	if ($response) {
		$response->content_type('text/plain; charset=utf-8');
		my $name = 'librarymapper-mapping-' . strftime('%Y-%m-%d', localtime()) . '.txt';
		$response->header('Content-Disposition' => "attachment; filename=\"$name\"");
	}

	return \$text;
}

# ------------------------------------------------------------------- CLI
sub cmdInit {
	my $request = shift;
	my $stats = Plugins::LibraryMapper::Data::runInitialization();
	$request->addResult('ok',      $stats->{'ok'} ? 1 : 0);
	$request->addResult('albums',  $stats->{'albums'}      || 0);
	$request->addResult('genres',  $stats->{'genreVariants'} || 0);
	$request->addResult('artists', $stats->{'artistVariants'} || 0);
	$request->addResult('tracks',  $stats->{'tracks'}       || 0);
	$request->addResult('resolved',$stats->{'albumsResolved'} || 0);
	$request->addResult('seconds', $stats->{'duration'}     || 0);
	$request->setStatusDone();
}

sub cmdStatus {
	my $request = shift;
	my $status = Plugins::LibraryMapper::Data::status();
	for my $k (keys %$status) {
		$request->addResult($k, $status->{$k});
	}
	$request->setStatusDone();
}

sub cmdBrowse {
	my $request = shift;
	my $path = $request->getParam('path') || '';
	my $view = Plugins::LibraryMapper::Data::browse(
		parent  => $path,
		time    => $request->getParam('time')    || $prefs->get('time_default'),
		quality => $request->getParam('quality') || $prefs->get('quality_default'),
		order   => $request->getParam('order')   || $prefs->get('order_default'),
		list    => $request->getParam('list')    || $prefs->get('listLimit'),
		filter  => $request->getParam('filter')  || '',
	);
	$request->addResult('type',  $view->{'type'});
	$request->addResult('title', $view->{'title'});
	$request->addResult('count', scalar @{ $view->{'rows'} });
	if ($view->{'filter'}) {
		$request->addResult('filter', $view->{'filter'});
	}
	if ($view->{'filterError'}) {
		$request->addResult('filterError', 1);
	}
	my $i = 0;
	for my $row (@{ $view->{'rows'} }) {
		$request->addResultLoop('rows_loop', $i, 'json', Plugins::LibraryMapper::Data::to_json($row));
		$i++;
	}
	$request->setStatusDone();
}

# Regex search over the artists, composers and conductors.
#   librarymapper query pattern=^Miles role=1
# The result is numbered: the number is the reference used by "map".
sub cmdQuery {
	my $request = shift;
	my $pattern = $request->getParam('pattern') || '';
	my $role    = $request->getParam('role')    || 'all';
	my $res = Plugins::LibraryMapper::Data::queryContributors($pattern, $role, {});
	if ($res->{'error'}) {
		$request->addResult('error', $res->{'error'});
		$request->setStatusDone();
		return;
	}
	$request->addResult('count',   scalar @{ $res->{'rows'} });
	$request->addResult('pattern', $res->{'pattern'});
	my $i = 0;
	for my $row (@{ $res->{'rows'} }) {
		$request->addResultLoop('rows_loop', $i, 'json',
			Plugins::LibraryMapper::Data::to_json($row));
		$i++;
	}
	$request->setStatusDone();
}

# Apply a mapping to one row of the last query result.
#   librarymapper map nr=12 canonical="Miles Davis"
# The "canonical" value may also be the number of another row: it then means
# the name of that row.
sub cmdMap {
	my $request = shift;
	my $nr       = $request->getParam('nr');
	my $canonical = $request->getParam('canonical');
	$canonical = '' unless defined $canonical;
	my $ok = Plugins::LibraryMapper::Data::setContributorMapping($nr, $canonical);
	$request->addResult('ok',   $ok);
	$request->addResult('name', Plugins::LibraryMapper::Data::queryResultName($nr));
	$request->addResult('canonical', $canonical);
	$request->setStatusDone();
}

1;

__END__

=head1 LibraryMapper

LMS server plugin presenting a categories/query application over the indexed
library. Query-only: it never performs file operations. All logic is Perl so
the plugin is shareable without external tooling.

=over

=item My Music > Simplified View - native browse mode (Genre\Artist\Year-Album)

=item /plugins/LibraryMapper/index.html   - virtual browse (Genre\Artist\Year-Album)

=item /plugins/LibraryMapper/settings/basic.html - parameter page (init, validation, uploads)

=item /plugins/LibraryMapper/download.json - export mapping file

=back

=cut
