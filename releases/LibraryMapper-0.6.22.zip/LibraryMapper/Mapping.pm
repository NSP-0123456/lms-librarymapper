package Plugins::LibraryMapper::Mapping;

use strict;

use Encode ();
use Unicode::Normalize;

use Plugins::LibraryMapper::Data;
use Plugins::LibraryMapper::SortKey;

# UTF-8 bytes <-> characters.
#
# The database of the plugin speaks UTF-8 bytes, exactly like the index of
# Lyrion: the SQLite driver of the server writes a text that carries the
# UTF-8 flag as Latin-1 bytes, so a character string must never reach the
# database.  The work on the names (the no-break space, the case of the
# letters that carry an accent) is done on characters, and the result is
# turned back into bytes before it is returned.
sub _chars {
	my $s = shift;
	return $s unless defined $s;
	utf8::decode($s) unless utf8::is_utf8($s);
	return $s;
}
sub _bytes {
	my $s = shift;
	return $s unless defined $s;
	utf8::encode($s) if utf8::is_utf8($s);
	return $s;
}

# Keyword rule table: the DEFAULT list, written the way the user reads it on
# the parameter page: "Group : word ; word ; word word".  The user can replace
# the whole list with one of their own (see setGenreRules); these lines stay
# behind it as the base.
#
# A keyword is matched as a *whole word* (several words are allowed: "piano
# solo") of the *normalized* form of the spelling (see normalizeGenre):
# without accents, without punctuation and without a word that only says
# "music".  That way "Classica", "Classical", "Classique", "Symphonic music"
# and "Piano Solo" all land in the same group.
#
# The order matters: the first rule that matches wins.  The rules that are
# about a combination of two genres come first ("Classic Rock" is a rock
# record, "Symphonic Rock" too).  A keyword that ends with * also matches the
# words that start with it: "classic*" = classic, classical, classics...
# (use it only where the family is a genre one: "rock*" would also catch
# "rocket").
#
# The LAST line carries no keyword: it is the FALLBACK.  It decides where a
# spelling goes when no rule recognized it.  Its position in the list is the
# order of the application: the rules that would stand after it never match,
# because the fallback catches everything that is left.  "NeedApproval" is a
# pseudo group: the albums filed there ask the user for a decision (the
# spelling is approved on the parameter page, and the albums move at once).
my @DEFAULT_ROWS = (
	# the word "blues" decides on its own: the tag that carries it is a blues
	# record, whatever the other words say (blues, blues rock, chicago blues,
	# country blues, rhythm and blues).  That is why this rule stands before
	# the ones that match the single words jazz, rock or country: "blues
	# rock" belongs to the blues, not to the rock.
	[ 'Blues',      'blues' ],
	[ 'Rock',       'classic rock; symphonic rock; symphonic metal; prog rock; hard rock; psychedelic*; prog metal' ],
	[ 'Pop',        'christmas; xmas; holiday; seasonal; noel; weihnacht*' ],
	[ 'Classical',  'classic*; classique*; opera*; baroque*; romantic*; symphon*; chamber*; chambre*; concerto*; sonata*; cantata*; oratorio*; requiem*; piano solo; solo piano; renaissance' ],
	[ 'Jazz',       'jazz; bebop; swing; fusion; bossa; scat' ],
	[ 'Rock',       'rock; prog; punk*; grunge; alternative*; metal*; indie; psychedel*' ],
	[ 'Pop',        'pop; chanson; variety; variete; disco; synth pop; synthpop*' ],
	# "americana" has its home here: it is a country music, not a region
	[ 'Country',    'country; bluegrass; honky; western; americana' ],
	[ 'Hip-Hop',    'hip hop; rap; trap; grime' ],
	[ 'Electronic', 'electro*; techno; house; trance; ambient; dnb; drum n bass; drum and bass; jungle; synthwave; synth wave; edm' ],
	# the regional words are NOT in the folk rule: a regional genre stands
	# LAST ("French Folk" is folk first of all, "Indian Music" only regional)
	[ 'Folk',       'folk; celtic; trad' ],
	[ 'Soul/R&B',   'soul; rnb; r b; funk; gospel; motown' ],
	[ 'Soundtrack', 'soundtrack; ost; score; bande originale; film' ],
	[ 'Reggae',     'reggae; dub; ska; dancehall' ],
	[ 'New Age',    'new age; meditation; relaxation' ],
);

# The words of the regional rule: the countries, the languages and their
# demonym forms, plus the words that only say "of the world" (world, monde,
# ethnic...).  The rule stands LAST of the styled rules, before the fallback
# (see the note above): a style in the spelling wins ("French Folk" stays
# Folk, "World Jazz" stays Jazz), the regional rule takes only what no style
# claimed ("Indian Music", "Folklore peruano", "Musique du monde").
my $REGIONAL_WORDS = <<'END_WORDS';
world monde musiques ethnique ethnic
afghanistan afghan albania albanian algeria algerian algerienne andorra angola
angolan argentina argentine argentinian argentinien armenia armenian australia
australian austria austrian azerbaijan azerbaijani bahamas bahrain bangladesh
bangladeshi barbados belarus belarusian belgium belgian belize benin bhutan
bolivia bolivian bosnia botswana brazil brazilian brasileiro brunei bulgaria
bulgarian burkina burma myanmar cambodia cambodian cameroon cameroonian canada
canadian chad chile chilean china chinese colombia colombian colombiano congo
congolese costarica croatia croatian cuba cuban cubano cyprus cypriot czech
czechia danish denmark djibouti dominica dominican ecuador ecuadorian
egypt egyptian eritrea eritrean estonia estonian ethiopia ethiopian fiji
finland finnish france french francais francaise gabon gambia georgian
germany german deutsch deutschland ghana ghanaian greece greek
grenada guatemala guatemalan guinea guyana haiti haitian honduras honduran
hungary hungarian iceland icelandic india indian indien indou pakistan
indonesia indonesian iran iranian iraq iraqi ireland irish israeli israel
italy italian italien italienne ivory jamaica jamaican japan
japanese japonais japonaise jordan jordanian kazakhstan kenya kenyan
kiribati kosovo kuwait kyrgyz laos lao latvia latvian lebanon lebanese
lesotho liberia libyan libya liban liechtenstein lithuania lithuanian
luxembourg madagascar malagasy malawi malaysian malaysia maldivian mali
maltese malta mauritania mauritius mexican mexicain mexicaine mexico
micronesia moldova monaco mongolia mongolian montenegro morocco moroccan
maroc marocain mozambique namibia nauru nepal nepalese netherlands dutch
hollande neerlandais nicaragua nicaraguan niger nigeria nigerian
northkorea norway norwegian oman pakistani pakistan palau panama panamanian
paraguay paraguayan persia persian peruvian peruano peru perou philippines
filipino poland polish pologne portugal portuguese portugais
qatar romania romanian roumain russia russian russo rwanda samoa senegal
senegalese serbia serbian seychelles singapore
slovakia slovak slovenia slovenian solomon somalia somali srilanka sudan
sudanese suriname sweden swedish sverige switzerland swiss suisse syria
syrian taiwan taiwanese tajikistan tanzania tanzanian thailand thai togo tonga
trinidad tunisia tunisian tunisie turkmenistan tuvalu uganda
ugandan ukraine ukrainian emirates emirati united britain england english
anglais scotland scottish wales welsh uruguay uruguayan uzbekistan uzbek
vanuatu venezuela venezuelan vietnam vietnamese vietnamien yemen yemeni
zambia zimbabwe
arabic arabisch mandarin cantonese hindi urdu bengali punjabi tamil telugu
marathi farsi kurdish pashto macedonian gaelic basque catalan galician
quechua guarani aymara nahuatl maya tagalog hmong maori hawaiian samoan
tongan tahitian creole kreol patois pidgin lingua sign
african afro africain africaine andean andino andina balkan baltic
scandinavian nordic gypsy romani oriental caribbean caribe hispanic
latino latina latin american american asian
european europeen polynesian melanesian indigenous native
tribal bedouin berber saharan sahara
END_WORDS

# The default list, as rows [ group, keywords ].  The regional line stands
# after every styled rule, the fallback line closes the list.
my ($REG_LINE) = (undef);
sub _regionalLine {
	unless (defined $REG_LINE) {
		$REG_LINE = join('; ', split(/\s+/, $REGIONAL_WORDS));
	}
	return $REG_LINE;
}

sub _defaultRows {
	my @rows = @DEFAULT_ROWS;
	push @rows, [ 'Regional Music', _regionalLine() ];
	push @rows, [ 'NeedApproval', '' ];
	return @rows;
}

# The normalized form of a genre spelling: the comparison of the rules is
# made on it, so that the spelling of the tags does not decide the group.
#   "Classique"      -> "classique"
#   "Symphonic Music"-> "symphonic"
#   "Piano Solo"     -> "piano solo"
#   "variété"        -> "variete"
sub normalizeGenre {
	my $s = shift || '';
	# the spelling may come out of the database as bytes: it is decoded, so
	# that the accents can be recognized
	if (!utf8::is_utf8($s)) {
		my $decoded = eval { Encode::decode('UTF-8', $s, Encode::FB_CROAK()) };
		$s = $decoded if defined $decoded;
	}
	$s = lc $s;
	# the accents are dropped: "variété" and "variete" are the same genre
	eval {
		$s = NFD($s);
		$s =~ s/\p{M}//g;
		$s = NFC($s);
		1;
	};
	# the punctuation becomes a space
	$s =~ s/[^\w]+/ /g;
	$s =~ s/\s+/ /g;
	$s =~ s/^\s+|\s+$//g;
	# the word that only says "music" says nothing about the genre
	$s =~ s/\b(musique|musica|musik|music)\b/ /g;
	$s =~ s/\s+/ /g;
	$s =~ s/^\s+|\s+$//g;
	return $s;
}

# Mapped group for a raw genre string (cache-side lookup), used by Data.pm.
sub mappedGroup {
	my $raw = shift || '';
	my $dbh = _dbh() or return '';
	# resolution order: approved group > proposed group > the rules > the
	# fallback ("NeedApproval": the spelling waits for the user)
	my ($group) = $dbh->selectrow_array(
		'SELECT CASE
			WHEN approved<>"" THEN approved
			WHEN proposed_group<>"" THEN proposed_group
			ELSE NULL END
		FROM genre_variants WHERE variant = ?', undef, _fold($raw));
	return $group if $group;
	my $trim = $raw;
	$trim =~ s/^\s+|\s+$//g;
	return 'Unsorted' if $trim eq '';
	my $walked = _walkList(normalizeGenre($trim));
	return defined $walked ? $walked : fallbackGroup();
}

sub _fold { my $s = shift || ''; $s =~ s/^\s+|\s+$//g; return lc $s; }

# The group the mapping table itself carries for a spelling (approved or
# proposed), without the fallback to the spelling as its own group.  '' for
# nothing.  This is the question "does the user, or the rules, already have
# decided this spelling?": a decision of the user wins over every guess.  Used
# by the guessing pass of Data.pm for the spellings that carry no genre
# ("unknown", empty tag...).
sub decidedGroup {
	my $raw = shift || '';
	my $dbh = _dbh() or return '';
	my ($group) = $dbh->selectrow_array(
		'SELECT CASE
			WHEN approved<>"" THEN approved
			WHEN proposed_group<>"" THEN proposed_group
			ELSE NULL END
		FROM genre_variants WHERE variant = ?', undef, _fold($raw));
	return $group // '';
}

# Propose groups for all unmapped variants (cheap: no Lyrion access needed).
sub repropose {
	my $dbh = _dbh() or return 0;
	my $changed = 0;
	for my $v (@{ _rows('SELECT variant, occurrences FROM genre_variants WHERE approved=""') }) {
		my ($variant, $occ) = @$v;
		my $group = proposeGroup($variant);
		next unless $group;
		$dbh->do('UPDATE genre_variants SET proposed_group=? WHERE variant=?',
			undef, $group, $variant);
		$changed++;
	}
	return $changed;
}

# --- the keyword rules: the list, its order and the fallback ------------------
#
# The rules live in one single list: the default lines of the plugin (the
# table above, with the regional line and the fallback line), and the list
# of the user ahead of them.  A list of the user that ends with its own
# fallback line (a line without keywords) takes the place of the default
# list as a whole: it is the only one applied.  A user list without a
# fallback line stays additive: every default line follows it, and the
# fallback line of the plugin closes the order.  An empty user list is the
# default list again.

# The list the user has stored, read back as rows [ group, keywords ]
# (the keywords are empty for the fallback line).  The group keeps the
# bytes it is stored with (the groups travel from the database to the
# database), only the keywords are decoded for the compile.
sub _savedRows {
	return [] unless _dbh();
	return [ map { [ $_->[0], _chars($_->[1]) ] }
		@{ _rows('SELECT group_name, keywords FROM genre_rules ORDER BY ord') } ];
}

# One compiled row of the match: a regex that matches the keywords of the
# line as whole words of the normalized spelling.  undef for a line without
# usable keywords.
sub _rowRegex {
	my $kw = shift;
	my @alt;
	for my $item (split /;/, $kw) {
		my $w = trim($item);
		next if $w eq '';
		my $star = ($w =~ s/\*\z//);
		my $norm = normalizeGenre($w);
		next if $norm eq '';
		my $re = quotemeta($norm);
		# the words of a multi-word keyword may be joined by one or more
		# blanks ("drum and bass" and "drum & bass" normalize the same)
		$re =~ s/\\ /\\s+/g;
		push @alt, '\b(?:' . $re . ($star ? '\\w*' : '') . ')\b';
	}
	return undef unless @alt;
	my $joined = join('|', @alt);
	return qr/$joined/i;
}

# The compiled list: { rows => [ [ group, qr ] ], fallback => group }.  The
# rows carry no fallback: the first line without keywords is taken out, it
# closes the order (every line after it would never be reached).  What a
# spelling gets when no rule matched is answered by fallbackGroup() alone —
# the rules never *propose* the fallback as a group of their own.
my $RULES_CACHE;

sub _compiledRules {
	return $RULES_CACHE if defined $RULES_CACHE;
	my $saved = _savedRows();
	# a line without keywords in the user list turns it into the whole
	# order; without one, the default lines follow, fallback line last
	my $full = (grep { trim($_->[1]) eq '' } @$saved) ? 1 : 0;
	my @list = $full ? (@$saved) : (@$saved, _defaultRows());
	my (@rows, $fallback);
	for my $r (@list) {
		if (trim($r->[1]) eq '') {
			$fallback = $r->[0] unless defined $fallback;
			last;
		}
		my $re = _rowRegex($r->[1]);
		push @rows, [ $r->[0], $re ] if $re;
	}
	$fallback = 'NeedApproval' unless defined $fallback;
	return $RULES_CACHE = { rows => \@rows, fallback => $fallback };
}

# The group of the fallback: where a spelling goes when no rule recognized
# it.  'NeedApproval', unless the user carries another fallback line.
sub fallbackGroup {
	my $f = _compiledRules()->{'fallback'};
	return $f || 'NeedApproval';
}

# Is this group the fallback one?  Used by the guessing pass of Data.pm: the
# albums that ride on the fallback carry the low confidence flag, exactly
# like the albums whose group was derived from the artist or the title.
sub isFallbackGroup {
	my $group = defined $_[0] ? $_[0] : '';
	my $f = fallbackGroup();
	return ($f ne '' && _fold(_chars($group)) eq _fold(_chars($f))) ? 1 : 0;
}

# The group a normalized spelling falls into under the list, WITHOUT the
# fallback: '' when no rule matched.  The fallback never takes part: the
# spelling then stays unmapped, and what will give it a group is the
# approval of the user (the rules never propose a pseudo group).
sub _walkList {
	my $norm = shift;
	for my $r (@{ _compiledRules()->{'rows'} }) {
		my ($group, $re) = @$r;
		return $group if $norm =~ $re;
	}
	return undef;
}

# Parse the ordered list.  '#' starts a comment; a line that carries no ':'
# is reported back in the errors.  Returns (list, errors), each item of the
# list is [ group, rules ].
sub parseGenreRules {
	my ($text) = @_;
	my (@list, @err);
	for my $line (split /\r?\n/, (defined $text ? $text : '')) {
		$line =~ s/^\s+|\s+$//g;
		next if $line eq '' || $line =~ /^[#;]/;
		if ($line !~ /^(.+?)\s*:\s*(.*)$/) {
			push @err, $line;
			next;
		}
		my ($group, $rules) = (trim($1), trim($2));
		push @list, [$group, $rules] if $group ne '';
	}
	return (\@list, \@err);
}

sub trim { my $s = shift // ''; $s =~ s/^\s+|\s+$//g; return $s; }

# Store the list of the user (it replaces what was stored before), then
# re-propose the spellings under the new rules.  An empty list erases the
# stored rules: the default list alone decides again.  Returns
# { added, removed, errors }.
sub setGenreRules {
	my ($text) = @_;
	my $dbh = _dbh() or return { added => 0, removed => 0, errors => ['no database'] };
	my ($list, $err) = parseGenreRules($text);
	# a line without keywords is the fallback: it catches everything that
	# no rule before it matched, so no line after it can ever be reached —
	# the user is told (the lines still go into the list, for the display)
	my $fall = -1;
	for my $i (0 .. $#$list) {
		if (trim($list->[$i][1]) eq '') { $fall = $i; last; }
	}
	if ($fall >= 0) {
		push @$err, map
			{ "after the fallback line (\"$list->[$fall][0]\"), the line \"$list->[$_][0]\" can never match" }
			grep { $_ > $fall }
			(0 .. $#$list);
	}
	unless (@$list) {
		$RULES_CACHE = undef;
		my $n = $dbh->do('DELETE FROM genre_rules');
		repropose();
		return { added => 0, removed => ($n || 0) + 0, errors => $err };
	}
	my $removed = 0;
	eval {
		$dbh->begin_work;
		($removed) = $dbh->selectrow_array('SELECT COUNT(*) FROM genre_rules');
		$dbh->do('DELETE FROM genre_rules');
		my $ins = $dbh->prepare('INSERT OR REPLACE INTO genre_rules(ord, group_name, keywords) VALUES (?,?,?)');
		my $ord = 0;
		for my $g (@$list) {
			$ord++;
			$ins->execute($ord, _bytes($g->[0]), _bytes($g->[1]));
		}
		$ins->finish;
		$dbh->commit;
		1;
	} or do {
		my $msg = $@ || 'unknown error';
		eval { $dbh->rollback; 1 };
		return { added => 0, removed => 0, errors => [@$err, "the rules could not be stored: $msg"] };
	};
	$RULES_CACHE = undef;
	repropose();
	return { added => scalar(@$list), removed => $removed || 0, errors => $err };
}

# The list ready for the textarea and for the download: the list of the user
# when it has one ("Group : rule ; rule", the fallback line without words
# included), the default list of the plugin, with its short manual, when it
# has none.  An empty textarea (or the Clear button) goes back to the
# default list.
sub genreRulesText {
	my $saved = _savedRows();
	if (@$saved) {
		return join("\n", map { $_->[0] . ' : ' . $_->[1] } @$saved) . "\n";
	}
	my $manual = <<'END_MANUAL';
# The rules of the genre groups, in their order: the first line that
# matches a word of the spelling wins ("French Folk" is Folk, "Indian
# Music" is Regional Music).  One line per group: "Group : word ; word ;
# two words".  A word that ends with * also matches the words that start
# with it ("classic*": classic, classical, classics...).  A "#" starts a
# comment.  The last line carries no word: it is the fallback, the albums
# of every spelling that no rule matched land there - a fallback line
# earlier in the list closes the order, the lines after it can never match.
END_MANUAL
	my $rows = join("\n", map { $_->[0] . ' : ' . $_->[1] } _defaultRows());
	return $manual . "\n" . $rows . "\n";
}

# The group the rules propose for a spelling: the whole list, without the
# fallback — '' when nothing matched (the spelling then stays unmapped, and
# what will give it a group is the approval of the user: the rules never
# propose a pseudo group).
sub proposeGroup {
	my $norm = normalizeGenre($_[0] // '');
	return '' if $norm eq '';
	return _walkList($norm) // '';
}

# The group a free text suggests, read through the keyword rules — used for
# the title of an album that carries no genre at all: a compilation named
# "The Story of Jazz" is proposed for the jazz group.  The fallback never
# takes part (else every title would resolve).  '' for nothing.
sub titleGroup {
	return proposeGroup($_[0] // '');
}

# Validation report shown on the parameter page.
sub validate {
	return { variants_total => 0, coverage_pct => 0, unmapped_top => [] } unless _dbh();
	my $rows = _rows('SELECT variant, occurrences, approved, approved_by FROM genre_variants');
	my $total = 0; my $mapped = 0;
	for my $r (@$rows) { $total += $r->[1]; $mapped += $r->[1] if $r->[2]; }
	return {
		variants_total  => scalar @$rows,
		coverage_pct    => $total ? sprintf('%.2f', 100 * $mapped / $total) : 0,
		unmapped_top    => _rows('SELECT variant, occurrences FROM genre_variants WHERE approved="" ORDER BY occurrences DESC LIMIT 15'),
	};
}

# --------------------------------------------------------------- artists

# Canonical display form of an artist name.
#   "john  lennon "           -> "John Lennon" (case kept from the source)
#   "Lennon, John"            -> "John Lennon"
#   "Miles Davis (feat. X)"   -> "Miles Davis"
#   "John Ronald Reuel Tolkien" -> "John Tolkien"  (style 'firstlast')
#   "AC/DC", "Earth, Wind & Fire" are left alone (bands, not persons)
sub normalizeArtistName {
	my ($raw, $style) = @_;
	return '' unless defined $raw && $raw ne '';
	# the name comes from the index of the server as UTF-8 bytes: it is
	# decoded for the work (the no-break space, the case of the letters that
	# carry an accent), and encoded again before it is returned, because the
	# result goes into the database, which speaks bytes.
	my $s = _chars($raw);
	$s =~ s/\x{00a0}/ /g;
	$s =~ s/[\(\[][^\)\]]*[\)\]]//g;               # drop (feat. ..) / [remaster]
	$s =~ s/\s+(?:feat\.?|ft\.?|featuring|with)\b.*$//i;
	$s =~ s/\s+/ /g;
	$s =~ s/^\s+|\s+$//g;
	$s =~ s/[.,;:_]+$//;
	# "Last, First" -> "First Last" (only for simple person-like names).
	# The captures must be copied out first: any further regex match would
	# reset $1/$2.
	if ($s =~ /^([^,]+),\s*([^,]+)$/) {
		my ($last, $first) = ($1, $2);
		if ($last !~ /[&+]/ && $first !~ /[&+|\/]/ && $first =~ /^\S+(\s\S+)?$/) {
			$s = "$first $last";
		}
	}
	if (($style || 'firstlast') eq 'firstlast') {
		my @tok = split /\s+/, $s;
		# an ensemble keeps its full name: "Miles Davis Quintet" must not
		# become "Miles Quintet".  Only a name that carries at least two
		# middle names is shortened: "John Ronald Reuel Tolkien" becomes
		# "John Tolkien", but "Pierre Emmanuel Poizat" keeps its name.
		if (@tok > 3 && $s !~ /[&+|\/]/
		    && !Plugins::LibraryMapper::SortKey::hasDesignator($s)) {
			$s = "$tok[0] $tok[-1]";
		}
	}
	# a name written all in lower case is title cased ("miles davis" ->
	# "Miles Davis"); a name that already carries capitals is left alone
	# ("AC/DC", "Earth, Wind & Fire", "McDonald").
	if ($s !~ /[A-Z]/) {
		$s = join ' ', map { ucfirst lc $_ } split /\s+/, $s;
	}
	elsif ($s =~ /^[a-z]/) {
		$s = ucfirst $s;
	}
	return _bytes($s);
}

# ---------------------------------------------------------------- sort order

# The alphabetical order of the artists lives in its own module, so that it
# can be tested without a music server:
#   Plugins::LibraryMapper::SortKey::artistSortKey()
sub artistSortKey { return Plugins::LibraryMapper::SortKey::artistSortKey(@_); }
sub isBandName   { return Plugins::LibraryMapper::SortKey::isBandName(@_); }

# Resolve exactly one canonical artist per album so that the same album is
# never listed under several artist spellings.
#   $rows : [ { album => id, name => raw spelling, n => weight } ]
# Returns { album_id => { artist, raw, confidence, variants } }
# A tail that shows that the credit names one artist and not two:
#   "Hans Zimmer & Friends", "Smith & Co.", "The Gibbs Brothers"
my $GROUP_TAIL = qr/^(?:and\s+)?(?:friends?|co\.?|company|sons?|brothers?|sisters?|family|companions?|crew|stars?|all[- ]?stars)$/i;

# Split one artist credit into the individual artists it names.
#
#   "Claude Nougaro & David Lynx"  -> ("Claude Nougaro", "David Lynx")
#   "Andrea Keller & Sandy Evans"  -> ("Andrea Keller", "Sandy Evans")
#   "Anna Butterss, John Raymond, Ben Lumsdaine"
#                                   -> three artists
#   "Earth, Wind & Fire"            -> ("Earth, Wind & Fire")   (band listing)
#   "Simon & Garfunkel"             -> ("Simon & Garfunkel")    (band, one word each)
#   "AC/DC"                         -> ("AC/DC")
#   "Miles Davis feat. John Coltrane" -> ("Miles Davis", "John Coltrane")
#
# The rule that decides is simple: a credit is split when every part of it
# carries at least two words.  A band whose members are named by one word
# each ("Simon & Garfunkel", "Earth, Wind & Fire") therefore stays whole,
# while a collaboration between two artists is split into its artists.
sub splitArtistNames {
	my ($raw) = @_;
	return () unless defined $raw && $raw ne '';

	# the guests written in brackets are artists of their own:
	#   "Miles Davis (feat. John Coltrane)" -> two artists
	my @guests;
	my $tmp = $raw;
	while ($tmp =~ /[\(\[]([^\)\]]*)[\)\]]/g) {
		my $inner = $1;
		next unless $inner =~ /(?:feat|ft|featuring|with)\b/i;
		$inner =~ s/^\s*(?:feat\.?|ft\.?|featuring|with)\s*//i;
		push @guests, splitArtistNames($inner);
	}

	my $s = $raw;
	$s =~ s/[\(\[][^\)\]]*[\)\]]//g;          # drop (feat. ..) / [remaster]
	$s =~ s/\s+/ /g;
	$s =~ s/^\s+|\s+$//g;
	return () unless $s ne '';

	# "Last, First" is a single person
	if (_isLastFirst($s)) {
		my ($last, $first) = split /,\s*/, $s, 2;
		return ("$first $last", @guests);
	}

	# the separators between two artists: the comma, the ampersand, the plus,
	# the conjunction, the latin "et", "vs" and the guest markers
	my @parts = split /,|\s*&\s*|\s*\+\s*|\s+(?:and|et|vs\.?)\s+|\s+(?:feat\.?|ft\.?|featuring|with)\s+/i, $s;
	@parts = grep { /\S/ } @parts;
	for my $p (@parts) {
		$p =~ s/^\s+|\s+$//g;
	}
	return ($s, @guests) unless @parts > 1;

	# "Hans Zimmer & Friends" names one artist, not two
	for my $p (@parts) {
		return ($s, @guests) if $p =~ $GROUP_TAIL;
	}

	# only split when every part looks like the name of an artist (at least
	# two words): "Claude Nougaro & David Lynx" splits, "Simon & Garfunkel"
	# does not
	for my $p (@parts) {
		my @w = split /\s+/, $p;
		return ($s, @guests) if @w < 2;
	}
	return (@parts, @guests);
}

sub _isLastFirst {
	my $s = shift;
	return 0 unless $s =~ /^([^,]+),\s*([^,]+)$/;
	my ($last, $first) = ($1, $2);
	return 0 if $last =~ /[&+]/ || $first =~ /[&+|\/]/;
	return 0 unless $first =~ /^\S+(\s\S+)?$/;
	return 1;
}

# ------------------------------------------------------------ trusted artists

# A trusted name is an artist that is always ONE artist:
#   * the credit is never split ("Simon & Garfunkel" stays one entry),
#   * the albums credited to it are filed under it alone - no guest and no
#     other collaborator is listed next to it.
# The user uploads the list of such names on the parameter page.

# Matching keys of one artist name: the raw form and its normalized form.
#   "Miles Davis"  ->  "miles davis", "miles davis"
#   "Davis, Miles" ->  "davis, miles", "miles davis"
#   "Miles Davis feat. John Coltrane" -> "miles davis feat. john coltrane", "miles davis"
sub artistMatchKeys {
	my ($raw) = @_;
	my @keys;
	my $s = defined $raw ? $raw : '';
	$s =~ s/\x{00a0}/ /g;
	$s =~ s/\s+/ /g;
	$s =~ s/^\s+|\s+$//g;
	push @keys, lc $s if $s ne '';
	my $norm = normalizeArtistName($s, 'full');
	if (defined $norm && $norm ne '') {
		$norm =~ s/\s+/ /g;
		$norm =~ s/^\s+|\s+$//g;
		push @keys, lc $norm if $norm ne '' && !grep { $_ eq lc $norm } @keys;
	}
	return @keys;
}

# { matching key => the trusted name as the user typed it }
sub trustedKeyMap {
	my ($names) = @_;
	my %map;
	for my $n (@{ $names || [] }) {
		next unless defined $n;
		my $t = $n;
		$t =~ s/^\s+|\s+$//g;
		next unless $t ne '';
		for my $k (artistMatchKeys($t)) { $map{$k} = $t; }
	}
	return \%map;
}

# the trusted list kept in the plugin database
sub _trustedKeyMap {
	my $names = eval { Plugins::LibraryMapper::Data::trustedNames() };
	return trustedKeyMap($names);
}

# the trusted entry a credit matches, if any
sub _trustedMatch {
	my ($raw, $trusted) = @_;
	return undef unless $trusted && %$trusted;
	for my $k (artistMatchKeys($raw)) {
		return $trusted->{$k} if exists $trusted->{$k};
	}
	return undef;
}

# Resolve the artists of every album.
#   $rows : [ { album => id, name => raw spelling, n => weight } ]
# Returns { album_id => {
#              artist  => primary artist (the one the album is filed under),
#              artists => [ { name, weight, confidence } ],   # all entities
#              raw     => the most frequent original spelling,
#              confidence, variants } }
#
# An album is filed under every artist entity it names, so a collaboration
# ("Claude Nougaro & David Lynx") shows up under both artists.  Spellings of
# the same entity are merged into one canonical name, so the same album never
# appears under "Miles Davis", "miles davis" and "Davis, Miles".
sub resolveAlbumArtists {
	my ($rows, $style, $trustedNames) = @_;
	$style ||= 'firstlast';
	my %byAlbum;
	for my $r (@$rows) {
		next unless defined $r->{'album'};
		push @{ $byAlbum{ $r->{'album'} } }, $r;
	}

	# the user corrections (approved canonical names) win over the heuristic
	my $canon = _artistCanonicalMap();

	# the trusted names: one single artist, never split
	my $trusted = defined $trustedNames ? trustedKeyMap($trustedNames) : _trustedKeyMap();

	# global weight of each canonical name across the whole library
	my %global;
	for my $album (keys %byAlbum) {
		for my $r (@{ $byAlbum{$album} }) {
			for my $pair (_entitiesFor($r->{'name'}, $style, $canon, $trusted)) {
				$global{ $pair->[0] } += ($r->{'n'} || 1);
			}
		}
	}

	my %out;
	for my $album (keys %byAlbum) {
		my (%score, %raws, %trustedScore);
		for my $r (@{ $byAlbum{$album} }) {
			my $w = $r->{'n'} || 1;
			for my $pair (_entitiesFor($r->{'name'}, $style, $canon, $trusted)) {
				my ($entity, $isTrusted) = @$pair;
				$score{$entity} += $w;
				$raws{$entity}{ $r->{'name'} } += $w;
				$trustedScore{$entity} += $w if $isTrusted;
			}
		}
		next unless %score;

		# a trusted artist is the album artist of that album: it is listed
		# alone, no guest and no other collaborator next to it
		if (%trustedScore) {
			for my $entity (keys %score) {
				delete $score{$entity} unless $trustedScore{$entity};
			}
		}

		# the main artist: most credited, ties broken by library-wide weight
		my ($best) = sort { $score{$b} <=> $score{$a}
			|| $global{$b} <=> $global{$a}
			|| $a cmp $b } keys %score;
		my ($bestRaw) = sort { $raws{$best}{$b} <=> $raws{$best}{$a} || $a cmp $b } keys %{ $raws{$best} };

		# every artist the album really belongs to: a guest on one track out of
		# twelve does not make the album a collaboration
		my $max = $score{$best};
		my @artists;
		for my $n (sort { $score{$b} <=> $score{$a} || $a cmp $b } keys %score) {
			next if $score{$n} < 0.2 * $max;
			push @artists, {
				name       => $n,
				weight     => $score{$n},
				confidence => $max ? sprintf('%.2f', 100 * $score{$n} / $max) : 0,
			};
		}
		my $total = 0;
		$total += $score{$_} for keys %score;

		$out{$album} = {
			artist     => $best,
			artists    => \@artists,
			raw        => $bestRaw,
			confidence => $total ? sprintf('%.2f', 100 * $score{$best} / $total) : 0,
			variants   => scalar keys %score,
			trusted    => (scalar keys %trustedScore) ? 1 : 0,
		};
	}
	return \%out;
}

# The artists named by one credit.
# Returns a list of [ name, isTrusted ] pairs.
#   a trusted credit           -> one single artist, never split
#   any other credit           -> the names the heuristic finds
sub _entitiesFor {
	my ($raw, $style, $canon, $trusted) = @_;
	return () unless defined $raw;
	my $t = _trustedMatch($raw, $trusted);
	if ($t) {
		# the trusted name as the user typed it, with "Last, First" and the
		# case normalized but nothing else touched
		my $display = normalizeArtistName($t, 'full');
		$display = $t unless defined $display && $display ne '';
		return ([ $display, 1 ]);
	}
	my @out;
	for my $entity (splitArtistNames($raw)) {
		my $n = _canonical($entity, $style, $canon);
		push @out, [ $n, 0 ] if defined $n && $n ne '';
	}
	return @out;
}

# canonical name of one raw spelling, honouring the user correction
sub _canonical {
	my ($raw, $style, $canon) = @_;
	my $c = $canon->{ _fold($raw) };
	return $c if defined $c && $c ne '';
	return normalizeArtistName($raw, $style);
}

# preload the canonical/approved names of every known spelling (one query)
sub _artistCanonicalMap {
	my %map;
	for my $r (@{ _rows('SELECT variant, canonical, approved FROM artist_variants') }) {
		my $v = $r->[0];
		my $c = (defined $r->[2] && $r->[2] ne '') ? $r->[2]
		      : ((defined $r->[1] && $r->[1] ne '') ? $r->[1] : '');
		$map{$v} = $c;
	}
	return \%map;
}

# Canonical name of one raw spelling, honouring a user approval.
sub artistCanonical {
	my ($raw, $style) = @_;
	my $variant = _fold($raw);
	my $dbh = _dbh();
	if ($dbh) {
		my ($approved) = $dbh->selectrow_array(
			'SELECT approved FROM artist_variants WHERE variant=?', undef, $variant);
		return $approved if $approved;
		my ($canonical) = $dbh->selectrow_array(
			'SELECT canonical FROM artist_variants WHERE variant=?', undef, $variant);
		return $canonical if $canonical;
	}
	return normalizeArtistName($raw, $style);
}

# --------------------------------------------------------- contributor roles
#
# The library credits people in several roles: artist, composer, conductor,
# band, album artist, track artist.  Each role has its own canonical name:
# "Bach" is not the same string when it is credited as the composer.

# The string token of a role number.
my %ROLE_TOKEN = (
	1 => 'PLUGIN_LIBRARYMAPPER_ROLE_ARTIST',
	2 => 'PLUGIN_LIBRARYMAPPER_ROLE_COMPOSER',
	3 => 'PLUGIN_LIBRARYMAPPER_ROLE_CONDUCTOR',
	4 => 'PLUGIN_LIBRARYMAPPER_ROLE_BAND',
	5 => 'PLUGIN_LIBRARYMAPPER_ROLE_ALBUMARTIST',
	6 => 'PLUGIN_LIBRARYMAPPER_ROLE_TRACKARTIST',
);
sub roleToken { my $r = shift || 0; return $ROLE_TOKEN{ 0 + $r } || ''; }

# The roles a name can be credited under, most specific first.
sub roleList {
	return [ sort { $a <=> $b } keys %ROLE_TOKEN ];
}

# The canonical name of a contributor in one role.
#   the user mapping wins, then the artist spelling table (artists only),
#   then the automatic normalization.
sub roleCanonical {
	my ($raw, $role, $style) = @_;
	return '' unless defined $raw && $raw ne '';
	$role = 1 unless $role && $role =~ /^\d+$/;
	my $variant = _fold($raw);
	my $dbh = _dbh();
	if ($dbh) {
		my ($mapped) = $dbh->selectrow_array(
			'SELECT canonical FROM contributor_mappings WHERE role=? AND variant=?',
			undef, $role, $variant);
		return $mapped if defined $mapped && $mapped ne '';
		if ($role == 1) {
			my ($approved) = $dbh->selectrow_array(
				'SELECT approved FROM artist_variants WHERE variant=?', undef, $variant);
			return $approved if defined $approved && $approved ne '';
			my ($canonical) = $dbh->selectrow_array(
				'SELECT canonical FROM artist_variants WHERE variant=?', undef, $variant);
			return $canonical if defined $canonical && $canonical ne '';
		}
	}
	# a composer or a conductor keeps every part of the name: "Johann
	# Sebastian Bach" must not become "Johann Bach"
	my $st = ($role == 2 || $role == 3) ? 'full' : ($style || 'firstlast');
	return normalizeArtistName($raw, $st);
}

# The user mappings of one role: { variant => canonical }.
sub contributorMappings {
	my ($role) = @_;
	my %map;
	for my $r (@{ _rows('SELECT variant, canonical FROM contributor_mappings WHERE role=?', $role || 1) }) {
		$map{ $r->[0] } = $r->[1];
	}
	return \%map;
}

# Export the full mapping as downloadable JSON.
#
# The file carries the proposals of the keyword rules too, not only the
# mappings the user approved: the exported file is the working material the
# user edits and uploads back.  A proposal that the user did not touch stays
# a proposal (""), an approved one stays approved.
sub exportMapping {
	return undef unless _dbh();
	my $data = {
		format     => 'librarymapper-mapping',
		version    => 4,
		generated  => scalar localtime(),
		groups     => _rows('SELECT name, sort_order, is_default FROM genre_groups'),
		# [ variant, proposed_group, approved, approved_by ]
		variants   => _rows('SELECT variant, proposed_group, approved, approved_by FROM genre_variants'),
		# the pinned guessing rules: [ ord, group, keywords ]
		genreRules => _rows('SELECT ord, group_name, keywords FROM genre_rules ORDER BY ord'),
		# [ variant, canonical, approved ]
		artists    => _rows('SELECT variant, canonical, approved FROM artist_variants'),
		# [ role, variant, canonical ]
		contributors => _rows('SELECT role, variant, canonical FROM contributor_mappings'),
		trusted    => _rows('SELECT name FROM trusted_artists'),
	};
	return _json($data);
}

# The mapping as a plain text list: one line per entry.
#
#   artist  miles davis            => Miles Davis
#   composer bach, johann sebastian => Johann Sebastian Bach
#   genre   jazz                   => Jazz
#
# The type may be left out (artist is then assumed) and the "=>" may be
# replaced by "|".  A line without a value removes the entry.
#
# This is the format the user edits in a text editor and pastes back into
# the parameter page: it is far easier to work with than the JSON file.
sub exportList {
	return '' unless _dbh();
	my @out;
	for my $r (@{ _rows('SELECT variant, approved, canonical FROM artist_variants
	                     WHERE approved<>"" OR canonical<>""') }) {
		my ($variant, $approved, $canonical) = @$r;
		my $value = (defined $approved && $approved ne '') ? $approved : $canonical;
		next unless defined $value && $value ne '';
		push @out, "artist  $variant => $value";
	}
	for my $r (@{ _rows('SELECT role, variant, canonical FROM contributor_mappings
	                     WHERE canonical<>"" ORDER BY role, variant') }) {
		my ($role, $variant, $canonical) = @$r;
		my $type = _roleType($role);
		next unless $type;
		push @out, "$type  $variant => $canonical";
	}
	for my $r (@{ _rows('SELECT variant, approved FROM genre_variants WHERE approved<>"" ORDER BY variant') }) {
		push @out, "genre   $r->[0] => $r->[1]";
	}
	return join("\n", @out) . (@out ? "\n" : '');
}

# The name of a role in the list format ('' for an unknown role).
sub _roleType {
	my $role = shift || 0;
	return 'artist'      if $role == 1;
	return 'composer'    if $role == 2;
	return 'conductor'   if $role == 3;
	return 'band'        if $role == 4;
	return 'albumartist' if $role == 5;
	return 'trackartist' if $role == 6;
	return '';
}

# The role number of a type in the list format (1 = artist).
sub _typeRole {
	my $type = shift || '';
	return 1 unless $type ne '';
	return 1 if $type eq 'artist';
	return 2 if $type eq 'composer';
	return 3 if $type eq 'conductor';
	return 4 if $type eq 'band';
	return 5 if $type eq 'albumartist';
	return 6 if $type eq 'trackartist';
	return 0;
}

# Read a list and apply it to the current mapping.
#   $mode = 'modify'  - add or change the listed entries
#   $mode = 'delete'  - remove the listed entries
# Returns { added, changed, removed, errors => [ ... ] }.
sub importList {
	my ($text, $mode) = @_;
	my $dbh = _dbh() or return { added => 0, changed => 0, removed => 0, errors => ['no database'] };
	$mode = 'modify' unless $mode && $mode eq 'delete';

	my $stats = { added => 0, changed => 0, removed => 0, errors => [] };
	for my $line (split /\r?\n/, (defined $text ? $text : '')) {
		$line =~ s/^\s+|\s+$//g;
		next if $line eq '';
		next if $line =~ /^[#;]/;                  # a comment
		my ($type, $key, $value);
		if ($line =~ /^([A-Za-z]+)\s+(.*)$/ && _typeRole(lc $1)) {
			$type = lc $1;
			$line = $2;
		}
		if ($line =~ /^([^=>|]*?)\s*(?:=>|\|)\s*(.*)$/) {
			($key, $value) = ($1, $2);
		}
		else {
			$key = $line;
			$value = '';
		}
		$key =~ s/^\s+|\s+$//g;
		$value =~ s/^\s+|\s+$//g;
		# the file carries characters: the database speaks UTF-8 bytes
		$key = _bytes($key);
		$value = _bytes($value);
		next if $key eq '';

		my $role = _typeRole($type);
		if ($role == 0) {
			push @{ $stats->{'errors'} }, "unknown type '$type' for '$key'";
			next;
		}

		if ($mode eq 'delete') {
			$stats->{'removed'} += _removeEntry($role, $key);
			next;
		}

		# an empty value in modify mode removes the entry
		if ($value eq '') {
			$stats->{'removed'} += _removeEntry($role, $key);
			next;
		}

		if ($role == 1) {
			# the artist spellings: the approved name is what the tree shows
			my $variant = _fold($key);
			my ($old) = $dbh->selectrow_array(
				'SELECT approved FROM artist_variants WHERE variant=?', undef, $variant);
			if (!defined $old) {
				$dbh->do('INSERT INTO artist_variants(variant, canonical, occurrences, approved) VALUES (?,?,?,?)',
					undef, $variant, $value, 0, $value);
				$stats->{'added'}++;
			}
			else {
				$dbh->do('UPDATE artist_variants SET approved=? WHERE variant=?', undef, $value, $variant);
				$stats->{'changed'}++;
			}
		}
		elsif ($role == 5 || $role == 6 || $role == 4) {
			# an album artist, a track artist or a band is an artist spelling
			$dbh->do('INSERT OR REPLACE INTO contributor_mappings(role, variant, canonical, updated_at) VALUES (?,?,?,?)',
				undef, $role, _fold($key), $value, time());
			$stats->{'changed'}++;
		}
		else {
			$dbh->do('INSERT OR REPLACE INTO contributor_mappings(role, variant, canonical, updated_at) VALUES (?,?,?,?)',
				undef, $role, _fold($key), $value, time());
			$stats->{'changed'}++;
		}
	}
	return $stats;
}

# Remove one entry from the mapping.  Returns the number of rows removed.
sub _removeEntry {
	my ($role, $key) = @_;
	my $dbh = _dbh() or return 0;
	my $n = 0;
	if ($role == 1) {
		$n += $dbh->do('UPDATE artist_variants SET approved="" WHERE variant=?', undef, _fold($key));
		$n += $dbh->do('DELETE FROM contributor_mappings WHERE role=1 AND variant=?', undef, _fold($key));
	}
	elsif ($role == 5) {
		$n += $dbh->do('UPDATE artist_variants SET approved="" WHERE variant=?', undef, _fold($key));
		$n += $dbh->do('DELETE FROM contributor_mappings WHERE role IN (4,5,6) AND variant=?', undef, _fold($key));
	}
	else {
		$n += $dbh->do('DELETE FROM contributor_mappings WHERE role=? AND variant=?', undef, $role, _fold($key));
	}
	return $n;
}

# Import a previously exported (or user-edited) mapping file.
#
# Both the old 3-column variant rows and the new 4-column ones are read.
sub importMapping {
	my ($text) = @_;
	my $dbh = _dbh() or return 0;
	my $data = _fromJson($text) or return 0;
	return 0 unless ($data->{format} // '') eq 'librarymapper-mapping';
	$dbh->begin_work;
	for my $g (@{ $data->{groups} || [] }) {
		$dbh->do('INSERT OR IGNORE INTO genre_groups(name, sort_order, is_default) VALUES (?,?,?)',
			undef, _bytes($g->[0]), $g->[1], $g->[2]);
	}
	if (exists $data->{genreRules} && ref $data->{genreRules}) {
		# the pinned rules travel whole: a file that carries them replaces
		# the ones of this server
		$dbh->do('DELETE FROM genre_rules');
		for my $r (@{ $data->{genreRules} }) {
			next unless ref $r && @$r >= 3;
			$dbh->do('INSERT OR REPLACE INTO genre_rules(ord, group_name, keywords) VALUES (?,?,?)',
				undef, ($r->[0] || 0) + 0, _bytes($r->[1]), _bytes($r->[2]));
		}
		# the compiled rules changed under the cache: forget it, the next
		# proposal recompiles from the table
		$RULES_CACHE = undef;
	}
	for my $v (@{ $data->{variants} || [] }) {
		# [ variant, approved, approved_by ]      (version 3)
		# [ variant, proposed, approved, approved_by ] (version 4)
		my ($variant, $approved, $approved_by);
		if (@$v >= 4) {
			($variant, my $proposed, $approved, $approved_by) = @$v;
			$dbh->do('UPDATE genre_variants SET proposed_group=?, approved=?, approved_by=? WHERE variant=?',
				undef, _bytes($proposed), _bytes(defined $approved ? $approved : ''),
				_bytes(defined $approved_by ? $approved_by : 'import'), _bytes($variant));
		}
		else {
			($variant, $approved, $approved_by) = @$v;
			$dbh->do('UPDATE genre_variants SET approved=?, approved_by=? WHERE variant=?',
				undef, _bytes(defined $approved ? $approved : ''),
				_bytes(defined $approved_by ? $approved_by : 'import'), _bytes($variant));
		}
	}
	for my $a (@{ $data->{artists} || [] }) {
		# [ variant, canonical, approved ]
		my ($variant, $canonical, $approved) = @$a;
		$dbh->do('UPDATE artist_variants SET canonical=?, approved=? WHERE variant=?',
			undef, _bytes($canonical), _bytes(defined $approved ? $approved : ''), _bytes($variant));
	}
	for my $c (@{ $data->{contributors} || [] }) {
		# [ role, variant, canonical ]
		my ($role, $variant, $canonical) = @$c;
		next unless defined $variant && $variant ne '';
		$dbh->do('INSERT OR REPLACE INTO contributor_mappings(role, variant, canonical, updated_at) VALUES (?,?,?,?)',
			undef, ($role || 1), _bytes($variant), _bytes(defined $canonical ? $canonical : ''), time());
	}
	for my $t (@{ $data->{trusted} || [] }) {
		# [ name ]
		my ($name) = @$t;
		next unless defined $name && $name ne '';
		$dbh->do('INSERT OR REPLACE INTO trusted_artists(name, added_at) VALUES (?,?)',
			undef, _bytes($name), time());
	}
	$dbh->commit;
	return 1;
}

# --- internal -------------------------------------------------------------

sub _rows {
	my ($sql, @bind) = @_;
	my $dbh = _dbh() or return [];
	return $dbh->selectall_arrayref($sql, undef, @bind) || [];
}
sub _dbh { return Plugins::LibraryMapper::Data::dbh(); }
sub _json { return Plugins::LibraryMapper::Data::to_json(@_); }
sub _fromJson { return Plugins::LibraryMapper::Data::from_json(@_); }

1;
