package Plugins::LibraryMapper::Data;

use strict;

use File::Basename qw(dirname);
use File::Spec;

use Slim::Utils::Log;
use Slim::Utils::Prefs;

my $log = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

my $DBH;   # dedicated plugin database handle

# Shared accessors used by Mapping.pm
sub dbh { return $DBH; }
sub to_json   { require JSON::XS; return JSON::XS::encode_json(@_); }
sub from_json { require JSON::XS; return JSON::XS::decode_json(@_); }

# ---------------------------------------------------------------- persist dir

sub dbPath {
	my $dir = $prefs->get('dataDir');
	if (!$dir) {
		# Lyrion's standard per-plugin persist directory (verified at first init)
		$dir = eval { Slim::Utils::Prefs::getPrefDir() }
		    || eval { Slim::Utils::Misc::getPrefsPath() }
		    || '/tmp/LibraryMapper';
		$dir = File::Spec->catdir($dir, 'LibraryMapper') if -d $dir;
	}
	return File::Spec->catfile($dir, 'librarymapper.db');
}

# ----------------------------------------------------------------- schema

my $SCHEMA = <<'SQL';
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS genre_groups (
	id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE,
	sort_order INTEGER DEFAULT 0, is_default INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS genre_variants (
	variant TEXT PRIMARY KEY,            -- folded display form
	occurrences INTEGER NOT NULL DEFAULT 0,   -- albums referencing it
	proposed_group TEXT, approved TEXT DEFAULT '', approved_by TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS genre_proposals (
	variant TEXT NOT NULL, part TEXT NOT NULL, pos INTEGER NOT NULL,
	group_name TEXT, PRIMARY KEY (variant, pos));
CREATE TABLE IF NOT EXISTS artist_variants (
	variant TEXT PRIMARY KEY, canonical TEXT,
	occurrences INTEGER NOT NULL DEFAULT 0, approved TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS albums_cache (
	album_id INTEGER PRIMARY KEY,
	name TEXT NOT NULL, artist_raw TEXT, genre_raw TEXT,
	year INTEGER, added INTEGER,       -- epoch seconds, from Lyrion index
	quality TEXT,                      -- hires | cd | lossy | unknown
	vpath_genre TEXT, vpath_artist TEXT, vpath_album TEXT);
CREATE INDEX IF NOT EXISTS idx_ac_group ON albums_cache(vpath_genre);
CREATE INDEX IF NOT EXISTS idx_ac_artist ON albums_cache(vpath_artist);
CREATE INDEX IF NOT EXISTS idx_ac_added ON albums_cache(added);
SQL

sub init {
	my $path = dbPath();
	mkdir dirname($path) unless -d dirname($path);
	$DBH = DBI->connect("dbi:SQLite:dbname=$path", '', '', {
		AutoCommit => 1, sqlite_use_immediate_transaction => 1
	}) or do { logError("LibraryMapper: cannot open dedicated db $path: $DBI::errstr"); return; };
	$DBH->do("PRAGMA journal_mode=WAL");
	for my $ddl (split /;\n/, $SCHEMA) {
		$DBH->do($ddl) or logError("LibraryMapper DDL failed: " . $DBI::errstr);
	}
	$log->info("LibraryMapper dedicated database: $path");
}

# ------------------------------------------------------------ initialization

# Schema-sensitive probes: Lyrion internal table/column names vary between
# versions; we probe once and remember what worked in meta.
sub _probe {
	my $dbh = Slim::Schema->storage->dbh;
	return $dbh;
}

sub _tryQueries {
	my ($dbh, @candidates) = @_;
	for my $sql (@candidates) {
		my $rows = eval { $dbh->selectall_arrayref($sql, { Slice => {} }, 3) };
		return $rows if $rows;
	}
	return undef;
}

# Runs the initialization scan: reads Lyrion's own index (Slim::Schema) and
# fills albums_cache + raw genre/artist variant lists. Query-only: no tag or
# file writes. Returns a stats hash for the parameter page.
sub runInitialization {
	my $dbh = _probe();
	my $stats = { started => time() };

	# --- probe joins once, remember which shapes worked ------------------
	my $genreJoin = _tryQueries($dbh,
		q{SELECT track_id, genre_id FROM genre_track LIMIT 2},
		q{SELECT track_id, genre_id FROM genres_track LIMIT 2},
		q{SELECT track_id, genre_id FROM track_genres LIMIT 2});
	if ($genreJoin) { $stats->{'genreJoin'} = 1; }

	my $hasAdded = _tryQueries($dbh,
		q{SELECT id, addedtime FROM tracks ORDER BY id DESC LIMIT 2},
		q{SELECT id, time FROM tracks ORDER BY id DESC LIMIT 2});
	$stats->{'addedColumn'} = $hasAdded ? (ref $hasAdded->[0] ? (exists $hasAdded->[0]{addedtime} ? 'addedtime' : 'time') : '') : '';

	# --- genres ------------------------------------------------------------
	my $gJoin = $stats->{'genreJoin'} ? 'genre_track' : undef;
	$gJoin ||= 'genres_track';
	my $genres = eval {
		$dbh->selectall_arrayref(qq{
			SELECT g.name, COUNT(DISTINCT t.album) AS albums
			FROM genres g
			JOIN $gJoin gt ON gt.genre_id = g.id
			JOIN tracks t ON t.id = gt.track_id
			GROUP BY g.name ORDER BY albums DESC}, { Slice => {} })
	} || [];
	for my $g (@$genres) {
		$DBH->do("INSERT OR IGNORE INTO genre_variants(variant, occurrences) VALUES (?, ?)",
			undef, _fold($g->{name}), $g->{albums});
	}
	$stats->{'genreVariants'} = scalar @$genres;

	# --- artists -----------------------------------------------------------
	my $artists = eval {
		$dbh->selectall_arrayref(qq{
			SELECT c.name, COUNT(DISTINCT t.album) AS albums
			FROM contributors c
			JOIN tracks t ON t.artist_id = c.id
			GROUP BY c.name ORDER BY albums DESC}, { Slice => {} })
	} || [];
	for my $a (@$artists) {
		$DBH->do("INSERT OR IGNORE INTO artist_variants(variant, canonical, occurrences) VALUES (?, ?, ?)",
			undef, _fold($a->{name}), _fold($a->{name}), $a->{albums});
	}
	$stats->{'artistVariants'} = scalar @$artists;

	# --- albums cache (artist/genre/year/added/quality) ---------------------
	my $addedExpr = $stats->{'addedColumn'} ? "t.$stats->{addedColumn}" : 'NULL';
	my $albums = eval {
		$dbh->selectall_arrayref(qq{
			SELECT me.id, me.title, me.year,
			       MAX($addedExpr) AS added,
			       MAX(t.samplerate) AS sr, MAX(t.lossless) AS lossless, MAX(t.bitrate) AS br
			FROM albums me
			JOIN tracks t ON t.album = me.id
			GROUP BY me.id, me.title, me.year}, { Slice => {} })
	} || [];
	$stats->{'albums'} = scalar @$albums;

	my $albumGenre = eval {
		$dbh->selectall_arrayref(qq{
			SELECT t.album, g.name, COUNT(*) AS c
			FROM tracks t
			JOIN $gJoin gt ON gt.track_id = t.id
			JOIN genres g ON g.id = gt.genre_id
			GROUP BY t.album, g.name}, { Slice => {} })
	} || [];
	my %ag;
	for my $r (@$albumGenre) {
		push @{ $ag{ $r->{album} } ||= [] }, [ $r->{name}, $r->{c} ];
	}

	$DBH->begin_work;
	for my $a (@$albums) {
		my $g = $ag{ $a->{id} };
		my $genreRaw = $g ? _majority($g) : '';
		my $quality = _quality($a);
		my $vPath = _virtualPath($a, $genreRaw);
		$DBH->do("INSERT OR REPLACE INTO albums_cache(album_id, name, artist_raw, genre_raw, year, added, quality, vpath_genre, vpath_artist, vpath_album)
			VALUES (?,?,?,?,?,?,?,?,?,?)",
			undef, $a->{id}, $a->{title}, $genreRaw ? $genreRaw->[0] : '', $genreRaw,
			$a->{year} || 0, $a->{added} || 0, $quality,
			$vPath->[0], $vPath->[1], $vPath->[2]);
	}
	$DBH->commit;

	$DBH->do("INSERT OR REPLACE INTO meta(key, value) VALUES ('lastInit', ?)", undef, time());
	$stats->{'duration'} = time() - $stats->{'started'};
	$stats->{'ok'} = 1;
	return $stats;
}

sub _fold { my $s = shift; return '' unless defined $s; $s =~ s/^\s+|\s+$//g; return lc $s; }
sub _majority {
	my $list = shift;
	my @sorted = sort { $b->[1] <=> $a->[1] } @$list;
	return $sorted[0];
}
sub _quality {
	my $a = shift;
	return 'lossy'  if defined $a->{'lossless'} && !$a->{'lossless'};
	return 'hires'  if $a->{'sr'} && $a->{'sr'} > 48400;
	return 'cd'     if $a->{'sr'} && $a->{'sr'} > 40000;
	return 'unknown';
}
sub _virtualPath {
	my ($a, $genreRaw) = @_;
	my $group   = Mapping::mappedGroup($genreRaw ? $genreRaw->[0] : '') // 'Unsorted';
	my $artist  = $a->{'artist_raw'} || '';
	my $year    = $a->{'year'} || '????';
	return [ $group, $artist, "$year - $a->{'title'}" ];
}

# ------------------------------------------------------------------ queries

sub status {
	my ($out) = @_;
	my ($lastInit) = $DBH->selectrow_array("SELECT value FROM meta WHERE key='lastInit'");
	$out = {
		dbPath    => dbPath(),
		lastInit  => $lastInit || 0,
		albums    => $DBH->selectrow_array('SELECT COUNT(*) FROM albums_cache'),
		genreVariants => $DBH->selectrow_array('SELECT COUNT(*) FROM genre_variants'),
		groups    => $DBH->selectrow_array('SELECT COUNT(*) FROM genre_groups'),
		mapped    => $DBH->selectrow_array('SELECT COUNT(*) FROM genre_variants WHERE approved<>""'),
	};
	return $out;
}

sub getGenreGroups {
	return $DBH->selectall_arrayref('SELECT id, name, sort_order, is_default FROM genre_groups ORDER BY sort_order, name', { Slice => {} });
}

sub topVariants {
	my $n = shift || 25;
	return $DBH->selectall_arrayref('SELECT variant, occurrences, proposed_group, approved FROM genre_variants ORDER BY occurrences DESC LIMIT ?', { Slice => {} }, $n );
}

# virtual browse: categories query only
sub browse {
	my %args = @_;
	my @where  = ('1=1');
	my @params;
	if (my $p = $args{'parent'}) {
		my @path = split /\|/, $p;    # genre|artist|album
		if ($path[0]) { push @where, 'vpath_genre = ?';  push @params, $path[0]; }
		if ($path[1]) { push @where, 'vpath_artist = ?'; push @params, $path[1]; }
	}
	if (my $t = $args{'time'}) {
		push @where, "added >= ?" and push @params, _timeStart($t) if $t ne 'all';
	}
	if (my $q = $args{'quality'}) {
		push @where, 'quality = ?' and push @params, $q if $q ne 'all';
	}
	my $sql = 'SELECT vpath_genre, vpath_artist, vpath_album, name, year FROM albums_cache WHERE ' . join(' AND ', @where);
	return $DBH->selectall_arrayref($sql, { Slice => {} }, @params);
}

sub _timeStart {
	my $what = shift;
	my $now = time();
	return $now - 86_400        if $what eq 'day';
	return $now - 7 * 86_400    if $what eq 'week';
	return $now - 30 * 86_400   if $what eq 'month';
	return $now - 365 * 86_400  if $what eq 'year';
	return 0;
}

1;
