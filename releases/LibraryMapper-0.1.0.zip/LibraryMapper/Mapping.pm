package Plugins::LibraryMapper::Mapping;

use strict;

use Plugins::LibraryMapper::Data;

# Keyword rule table: group -> patterns (case-insensitive, substring or full).
# The 10-20 group definitions here are seeds only — the user can edit
# groups and rules on the parameter page; proposals are suggestions.
my @RULES = (
	[ 'Jazz',       qr/\b(jazz|bebop|swing|fusion|bossa|scat)\b/i ],
	[ 'Classical',  qr/\b(classic|classic?al|classique|opera|baroque|romantic|sympho|chamber|concerto|renaissance)\b/i ],
	[ 'Rock',       qr/\b(rock|prog|punk|grunge|alternative|metal|indie|hard ?rock|psychedel)\b/i ],
	[ 'Pop',        qr/\b(pop|chanson|variety|variété|disco|synth-pop)\b/i ],
	[ 'Blues',      qr/\b(blues)\b/i ],
	[ 'Country',    qr/\b(country|bluegrass|honky|western)\b/i ],
	[ 'Hip-Hop',    qr/\b(hip.?hop|rap|trap|grime)\b/i ],
	[ 'Electronic', qr/\b(electro|techno|house|trance|ambient|dnb|drum.?n|jungle|synthwave|edm)\b/i ],
	[ 'Folk',       qr/\b(folk|celtic|world|ethnic|trad)\b/i ],
	[ 'Soul/R&B',   qr/\b(soul|r\.?&?b|funk|gospel|motown)\b/i ],
	[ 'Soundtrack', qr/\b(soundtrack|ost|score|bande originale|film music)\b/i ],
	[ 'Reggae',     qr/\b(reggae|dub|ska|dancehall)\b/i ],
	[ 'New Age',    qr/\b(new.?age|meditation|relaxation)\b/i ],
);

# Mapped group for a raw genre string (cache-side lookup), used by Data.pm.
sub mappedGroup {
	my $raw = shift || '';
	my ($group) = _dbh()->selectrow_array(
		'SELECT approved FROM genre_variants WHERE variant = ?', undef, _fold($raw));
	return $group;
}

sub _fold { my $s = shift || ''; $s =~ s/^\s+|\s+$//g; return lc $s; }

# Propose groups for all unmapped variants (cheap: no Lyrion access needed).
sub repropose {
	my $changed = 0;
	for my $v (@{ _rows('SELECT variant, occurrences FROM genre_variants WHERE approved=""') }) {
		my ($variant, $occ) = @$v;
		my ($group, $rule) = _propose($variant);
		next unless $group;
		_dbh()->do('UPDATE genre_variants SET proposed_group=?, rule=? WHERE variant=?',
			undef, $group, $rule, $variant);
		$changed++;
	}
	return $changed;
}

sub _propose {
	my $variant = shift;
	for my $r (@RULES) {
		my ($group, $pat) = @$r;
		return ($group, 'keyword') if $variant =~ $pat;
	}
	return (undef, undef);
}

# Validation report shown on the parameter page.
sub validate {
	my $rows = _rows('SELECT variant, occurrences, approved, approved_by FROM genre_variants');
	my $total = 0; my $mapped = 0;
	for my $r (@$rows) { $total += $r->[1]; $mapped += $r->[1] if $r->[2]; }
	return {
		variants_total  => scalar @$rows,
		coverage_pct    => $total ? sprintf('%.2f', 100 * $mapped / $total) : 0,
		unmapped_top    => _rows('SELECT variant, occurrences FROM genre_variants WHERE approved="" ORDER BY occurrences DESC LIMIT 15'),
	};
}

# Export the full mapping as downloadable JSON.
sub exportMapping {
	my $data = {
		format     => 'librarymapper-mapping',
		version    => 1,
		generated  => scalar localtime(),
		groups     => _rows('SELECT name, sort_order, is_default FROM genre_groups'),
		variants   => _rows('SELECT variant, approved, approved_by FROM genre_variants WHERE approved<>""'),
		artists    => _rows('SELECT variant, canonical FROM artist_variants WHERE canonical<>variant'),
	};
	return _json($data);
}

# Import a previously exported (or user-edited) mapping file.
sub importMapping {
	my ($text) = @_;
	my $data = _fromJson($text) or return 0;
	return 0 unless ($data->{format} // '') eq 'librarymapper-mapping';
	_dbh()->begin_work;
	for my $g (@{ $data->{groups} || [] }) {
		_dbh()->do('INSERT OR IGNORE INTO genre_groups(name, sort_order, is_default) VALUES (?,?,?)',
			undef, @$g);
	}
	for my $v (@{ $data->{variants} || [] }) {
		_dbh()->do('UPDATE genre_variants SET approved=?, approved_by=? WHERE variant=?',
			undef, $v->[1], defined $v->[2] ? $v->[2] : 'import', $v->[0]);
	}
	for my $a (@{ $data->{artists} || [] }) {
		_dbh()->do('UPDATE artist_variants SET canonical=? WHERE variant=?', undef, $a->[1], $a->[0]);
	}
	_dbh()->commit;
	return 1;
}

# --- internal -------------------------------------------------------------

sub _rows {
	my ($sql, @bind) = @_;
	return _dbh()->selectall_arrayref($sql, undef, @bind) || [];
}
sub _dbh { return Plugins::LibraryMapper::Data::dbh(); }
sub _json { return Plugins::LibraryMapper::Data::to_json(@_); }
sub _fromJson { return Plugins::LibraryMapper::Data::from_json(@_); }

1;
