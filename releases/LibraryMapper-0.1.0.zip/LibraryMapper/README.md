# LibraryMapper (LMS plugin)

Shareable **query-only** mapping workbench for Lyrion Music Server.
No file operations — ever. It builds a dedicated SQLite database
(`plugin persist dir/LibraryMapper/librarymapper.db`) from Lyrion's own
indexed library (`Slim::Schema`), lets you curate simplified genre groups
(10–20 groups from the raw genre list), consolidate album artists, and
browse the **virtual** target layout:

    Genre \ Artist \ Year - Album

with two extra filters that are part of the application:

- **Temporal filter** — albums added on the server in the last day/week/month/year
- **Quality filter** — Hi-Res (>48 kHz) / CD lossless / Lossy

## Pages
| URL | Purpose |
|---|---|
| `/plugins/LibraryMapper/index.html` | Virtual browse app (filters + drill-down) |
| `/plugins/LibraryMapper/settings/basic.html` | Parameter page: initialization, validation report, mapping upload/download |
| `/plugins/LibraryMapper/download.json` | Export the mapping file (JSON) |

## Deploy
Copy the `LibraryMapper` folder into Lyrion's `Plugins` directory and restart
Lyrion. On the QNAP this is inside the Lyrion application data folder
(`Plugins` dir configured in the server settings).

Status: **skeleton (M2)**. Schema-sensitive SQL probes Lyrion's table shapes
at init time (genre join table name, added-time column) and remembers what
works — but the first run against the real server must be verified (SSH to
192.168.1.90).

## Structure
- `install.xml` — plugin descriptor (Lyrion ≥ 7.9)
- `Plugin.pm` — page registration: app page, download endpoint, settings page
- `Settings.pm` — parameter page handler (init, repropose, upload)
- `Data.pm` — **dedicated SQLite DB** (schema, initialization scan from Slim::Schema, browse queries)
- `Mapping.pm` — genre rules/propose, validation, export/import JSON mapping files
- `Strings.pm`, `HTML/EN/...` — labels and templates
