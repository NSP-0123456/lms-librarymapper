package Plugins::LibraryMapper::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Log;
use Slim::Utils::Prefs;

use Plugins::LibraryMapper::Data;
use Plugins::LibraryMapper::Mapping;

my $log = logger('plugin.librarymapper');

sub name { 'PLUGIN_LIBRARYMAPPER' }
sub page { 'plugins/LibraryMapper/settings/basic.html' }

sub handler {
	my ($class, $client, $params, $callback) = @_;

	# --- initialization phase ------------------------------------------------
	if ($params->{'action'} && $params->{'action'} eq 'init') {
		my $stats = Plugins::LibraryMapper::Data::runInitialization();
		$params->{'initResult'} = $stats;
	}
	# --- upload mapping file (JSON pasted into the textarea) -----------------
	if ($params->{'action'} && $params->{'action'} eq 'upload') {
		my $text = $params->{'mappingInput'};
		$params->{'uploadResult'} = defined $text
			&& Plugins::LibraryMapper::Mapping::importMapping($text)
			? 'Imported successfully.'
			: 'Import failed: invalid JSON or incompatible structure.';
	}
	# --- repropose from rules -------------------------------------------------
	if ($params->{'action'} && $params->{'action'} eq 'repropose') {
		Plugins::LibraryMapper::Mapping::repropose();
	}

	$params->{'status'}   = Plugins::LibraryMapper::Data::status();
	$params->{'groups'}   = Plugins::LibraryMapper::Data::getGenreGroups();
	$params->{'variants'} = Plugins::LibraryMapper::Data::topVariants(25);

	openReview($params);
	$params->{'page'} = $class->page;

	return Slim::Web::HTTP::filltemplatefile($params->{'page'}, $params);
}

sub openReview {
	my $params = shift;
	my $valid  = Plugins::LibraryMapper::Mapping::validate();
	$params->{'validation'} = $valid;
}

1;
