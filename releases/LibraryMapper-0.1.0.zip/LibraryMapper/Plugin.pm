package Plugins::LibraryMapper::Plugin;

use strict;
use base qw(Slim::Plugin::Base);

use Slim::Web::Pages;
use Slim::Utils::Log;
use Slim::Utils::Prefs;

use Plugins::LibraryMapper::Data;
use Plugins::LibraryMapper::Mapping;

my $log   = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

$prefs->init({
	quality_default => 'all',
	time_default    => 'all',
});

sub initPlugin {
	my $class = shift;
	$class->SUPER::initPlugin(@_);

	Plugins::LibraryMapper::Data::init();

	# Main application page ("virtual browse")
	Slim::Web::Pages->addPageFunction(
		"plugins/LibraryMapper/index\.(?:htm|ml)?",
		\&pageApp
	);

	# Download endpoint: mapping file as JSON
	Slim::Web::Pages->addPageFunction(
		"plugins/LibraryMapper/download\.(?:htm|json)?",
		\&pageDownload
	);

	# Settings page (parameter page: init + validation + upload mapping)
	require Plugins::LibraryMapper::Settings;
	Plugins::LibraryMapper::Settings->addPage();

	logInfo("LibraryMapper initialized");
}

# ---------------------------------------------------------------- app page

sub pageApp {
	my ($client, $params) = @_;

	my $time    = $params->{'time'}    || $prefs->get('time_default');
	my $quality = $params->{'quality'} || $prefs->get('quality_default');

	my $view = Plugins::LibraryMapper::Data::browse(
		parent    => $params->{'parent'},     # e.g. "Blues|John Mayall|1970 - Empty Rooms" drill path
		time      => $time,
		quality   => $quality,
		q         => $params->{'q'},
	);

	$params->{'view'}         = $view;
	$params->{'time'}         = $time;
	$params->{'quality'}      = $quality;
	$params->{'template'}     = 'plugins/LibraryMapper/index.html';
}

# ------------------------------------------------------------ settings page

sub pageSettings {
	my ($client, $params) = @_;
	require Plugins::LibraryMapper::Settings;
	Plugins::LibraryMapper::Settings::handler($client, $params);
}

# ------------------------------------------------------------- download API

sub pageDownload {
	my ($client, $params) = @_;

	my $json = Plugins::LibraryMapper::Mapping::exportMapping();
	if (!$json) {
		$params->{'content_ref'} = \q({"error": "no mapping exists yet"});
		$params->{'content-type'} = 'application/json';
		return;
	}
	$params->{'content_ref'} = \$json;
	$params->{'content-type'} = 'application/json';
}

1;

__END__

=head1 LibraryMapper

LMS server plugin presenting a categories/query application over the indexed
library. Query-only: it never performs file operations. All logic is Perl so
the plugin is shareable without external tooling.

=over

=item /plugins/LibraryMapper/index.html   - virtual browse (Genre\Artist\Year-Album)

=item /plugins/LibraryMapper/settings/basic.html - parameter page (init, validation, uploads)

=item /plugins/LibraryMapper/download.json - export mapping file

=back

=cut
