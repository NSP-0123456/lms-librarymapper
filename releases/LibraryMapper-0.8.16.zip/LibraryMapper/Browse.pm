package Plugins::LibraryMapper::Browse;

use strict;

use MIME::Base64 ();

use Slim::Utils::Log qw(logger logError);
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(clientString string);

use Plugins::LibraryMapper::Data;

my $log   = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

use constant MODE => 'librarymapper';

# The virtual browse tree is exposed as a native LMS browse mode so that it
# shows up in "My Music" of every skin (Material Skin included) and can be
# walked with the standard LMS drill-down machinery.
#
# The drill-down path ("Genre|Artist|Year - Album") is carried in the
# "lm_path" parameter.  It is transported base64url encoded so that album
# titles containing spaces, commas, ampersands or colons survive every
# transport (CLI parameter lists, web query strings, JSON): a plain "|" in a
# request parameter would be read by Lyrion as a search tag.

sub feed {
	my ($client, $callback, $args, $pt) = @_;

	my $path = _path($args, $pt);

	# The native menu of the choices ("Filters & sorting"): a pick arrives as
	# "lm_set" (applied first, for the player that asks), the menu itself as
	# "lm_menu"; the typed expression arrives as "lm_expr_set" (the input of
	# a jive client) or as the "search" text of the item (XMLBrowser).
	my $set = _opt($args, $pt, 'lm_set');
	_applySet($client, $set) if $set ne '';
	my $typed = _opt($args, $pt, 'lm_expr_set');
	if ($typed eq '' && _opt($args, $pt, 'lm_expr_in') ne '') {
		$typed = defined $args->{'search'} ? $args->{'search'} : _opt($args, $pt, 'search');
	}
	if ($typed ne '' && $typed ne '__TAGGEDINPUT__') {
		Plugins::LibraryMapper::Data::setChoice($client, 'e', _chars($typed));
	}
	my $menu = _opt($args, $pt, 'lm_menu');
	if ($menu =~ /^sel(?:\.([a-z]))?$/) {
		my $group = $1;
		my $app = _opt($args, $pt, 'lm_app') ne '' ? 1 : 0;
		my $items = $group
			? _choiceMenu($client, $path, $group, $app)
			: _selectionsMenu($client, $path, $app);
		$callback->({ items => $items, sorted => 1 }, undef);
		return;
	}

	# The choices are the ones of the player that asks (its own, the ones of
	# the server otherwise); the parameters lm_order, lm_time, ... stay
	# honoured for the callers that send them (the CLI, the tests).
	my $order      = _param($args, 'lm_order')        || _param($args, 'order')
	                || _choice($client, 'order_default')   || 'alpha';
	my $groupOrder = _param($args, 'lm_group_order') || _choice($client, 'group_order')
	                || 'alpha';
	my $time       = _param($args, 'lm_time')        || _choice($client, 'time_default')
	                || 'all';
	my $quality    = _param($args, 'lm_quality')     || _choice($client, 'quality_default')
	                || 'all';

	# The number of items of a level: the choice of the user travels with the
	# request, so that it holds for the whole drill-down.  It is carried as a
	# *choice* ("default" included), never as the resolved number: when the
	# user has chosen nothing, the preference of the plugin decides, and that
	# must stay so down the tree.  The query itself resolves the choice (see
	# Data::_limitOf, which falls back to the preference for "default").
	my $limit = _limitMode(_param($args, 'lm_limit'));

	# The expression of the walk travels like the other choices.  It is free
	# text (spaces, commas, colons), which would break the "tag:value" list
	# of a CLI parameter: the tree carries it URL-encoded and the request
	# decodes it.  With no choice of its own, the preference of the
	# parameter page holds.
	my $expr = _param($args, 'lm_expr');
	if ($expr ne '') {
		$expr = _urldec($expr);
	}
	else {
		$expr = _choice($client, 'expr_default') || '';
	}

	# The transliteration of the name filter travels as a plain flag; it is
	# pinned on every item, an explicit "off" must survive the drill-down
	# just like an "on".
	my $ft = _param($args, 'lm_ft');
	$ft = ($ft ne '' ? $ft : (_choice($client, 'translit_default') ? 1 : 0));
	$ft = $ft ? 1 : 0;

	# The count of the albums of the draw (the "Random" level): a choice of
	# the page like the others (registered when the page of the step opens),
	# the preference of the parameter page otherwise.
	my $rnd = _randomMode(_param($args, 'lm_rnd'), $client);

	# The choices travel no more: every level reads the preferences at its
	# request (the fallbacks above) — a pick applies to the whole tree, the
	# level the user came from included.  The parameters lm_order, lm_time,
	# ... stay honoured for the callers that send them (the CLI, the tests),
	# but the tree itself pins nothing.

	my $view = Plugins::LibraryMapper::Data::browse(
		client     => $client,
		parent     => $path,
		time       => $time,
		quality    => $quality,
		order      => $order,
		groupOrder => $groupOrder,
		list       => $limit,
		filter     => _param($args, 'filter'),
		expr       => $expr,
		filterTranslit => $ft,
		randomCount    => $rnd,
	);

	my $type = $view->{'type'} || 'level';
	# The status of the queue is a snapshot taken when the level is fetched:
	# the tree has no poll of its own (and Material's Back re-serves a cached
	# level).  The page of the plugin polls queue.json and stays live.
	my $qstatus = ($type eq 'albums' || $type eq 'tracks')
		? Plugins::LibraryMapper::Data::queueStatus($client)
		: { albumStatus => {}, trackStatus => {} };
	my @items;

	# A scan at work (the one of the plugin, or the one of the server the
	# plugin waits for) says so on top of the level: the tree is empty, or
	# not up to date, until it is done.
	my $scan = scanLine($client);
	push @items, { name => _italic($scan), title => _italic($scan), type => 'text' }
		if $scan ne '';

	# The walk rows come first (the header line stands at the end, see
	# below): the level the user lands on starts right at the top of the
	# list.
	if ($type eq 'level') {
		for my $row (@{ $view->{'rows'} }) {
			my $next = $path ? $path . '|' . $row->{'key'} : $row->{'key'};
			# the pseudo entries of the shortcuts are no genres at all: they
			# are shown under a name that says it.  "All artists" (key "*")
			# stands on top and lists every artist of the library; the
			# "%%" row lists every album matching the selections, whatever
			# the artist — the library-wide shortcut at the top of the tree
			# ("All albums"), the aggregate of the genre walked into
			# elsewhere ("Selected albums", see _levelLabel); "Random"
			# (key "@@") is the draw of a few albums, the count beside its
			# name.  The group of the albums that carry no genre is not a
			# genre either: it is shown under a name that says it too.
			my $label = _levelLabel($client, $row, $path);
			# the numbers beside the name: the artists and the albums of the
			# line, "(art: aaa, alb: xxx)" in round brackets — the planning of
			# the next step reads the two of them on the lines of the tree
			# (the draw already carries its own count in its name).  The gaps
			# before the two numbers are no-break spaces: the text of a row
			# goes through HTML in the skins, a run of plain spaces would
			# collapse to one.
			my $nb = "\x{A0}\x{A0}";
			$label .= ' (art:' . $nb . ($row->{'art'} || 0) . ', alb:' . $nb . $row->{'n'} . ')'
				if $row->{'n'} && !$row->{'random'} && (!$path || $row->{'allalbums'});
			# the first level is the level of the genre groups: every group
			# carries its icon (t\make_genre_icons.ps1)
			my $icon = $path ? undef : _genreIcon($row->{'unclassified'} ? '' : $row->{'key'});
			push @items, _levelItem($next, $label, $icon);
		}
	}
	elsif ($type eq 'albums') {
		for my $row (@{ $view->{'rows'} }) {
			# the path carries the album id: an album that belongs to several
			# artists is filed under each of them
			my $next = join('|', $row->{'vpath_genre'}, $row->{'vpath_artist'}, $row->{'album_id'});
			my $label = ($row->{'year'} ? $row->{'year'} . ' - ' : '') . _chars($row->{'name'});
			# a guessed group (the albums of the artist, or the words of the
			# title) is a guess, not a fact: it carries the low-confidence
			# marker, the way the proposals of the genres do
			$label .= ' (?)'
				if ($row->{'genre_mode'} || '') eq 'artist'
				|| ($row->{'genre_mode'} || '') eq 'title'
				|| ($row->{'genre_mode'} || '') eq 'fallback';
			# the total duration of the album (the longest of the buckets of
			# the encodings), when the scan found one.  The middle dot is
			# written as the code point U+00B7 and not as a literal of the
			# file: the source is no UTF-8 text for perl, a literal of two
			# bytes would be read as the characters "Â·" when the label
			# (characters) meets it (bytes) — the trap of the double
			# encoding, seen on the pilot.
			$label .= '  ' . "\x{B7}" . '  ' . $row->{'durationText'} if $row->{'durationText'};
			# the second line: the original genre, then the original album
			# artist.  U+2192 is written as a code point for the same reason
			# as the middle dot above — the source is no UTF-8 text for perl.
			my $line2 = _albumLine2($row);
			# the tooltip: every tag as NAME:value, STATUS standing in its
			# alphabetical place with the value of the snapshot
			my $flat = Plugins::LibraryMapper::Data::tagLine(
				$row->{'tagPairs'},
				$qstatus->{'albumStatus'}{ $row->{'album_id'} } || '------');
			push @items, _albumItem($next, $label, $row, $line2, $flat);
		}
	}
	elsif ($type eq 'tracks') {
		for my $row (@{ $view->{'rows'} }) {
			my $status = $qstatus->{'trackStatus'}{ $row->{'track_id'} } || '------';
			push @items, _trackItem($row, $status);
		}
	}

	# The header comes last, as it did before the choices experiment: the
	# level the user lands on comes first, so the tree of the app opens on
	# its content at once — a header on top would make the app open on the
	# lone line of the selections.  The line shows the selections in use
	# (read out of the preferences at each request) and opens the page of
	# the plugin, where they can be changed.
	# the native menu of the choices, for the clients that show no HTML page
	# (Squeezer, the jive players): it stands just before the header
	push @items, _selectionsItem($client, $path);
	push @items, _headerItem($client, $path);

	# The "items" action walks one level down.  The path of the level is
	# carried by the "lm_path" parameter, which every item sets itself.  The
	# choices travel no more: a level carries the path only, the choices are
	# read from the preferences at every request (see above).
	my %actions = (
		commonVariables => [ 'lm_path' => 'id' ],
		items => {
			command     => [ 'browselibrary', 'items' ],
			fixedParams => { mode => MODE },
		},
	);

	$callback->({ items => \@items, actions => \%actions, sorted => 1 }, undef);
}

# The line of the selections, the last row of every level: the value of each
# choice, joined by a middle dot, as they stand in the preferences — and it
# opens the page of the plugin (filters + help), where they can be changed.
#
# The page and the tree share one source of truth: the preferences.  The URL
# carries no choice and no rnd — the page falls back to the preferences
# itself, so an old, remembered URL cannot re-register stale values over the
# picks of the tree (the page of the older releases wrote every choice it was
# handed into the preferences, so an old URL undid the picks of the tree).
# The level the user came from travels as "parent", so the page opens back on
# the step of that level (its breadcrumb and its filter scope).
#
# The URL is relative and of the "html" kind, so the Material skin opens the
# page *inside* the application, in an embedded window (its openWebLink
# embeds the relative links of the local server and opens only the external
# http(s) ones); the classic skins follow the same link.  A plain URL needs
# no replacement: the placeholders of the skins ({client}, ...) are not used.
sub _headerItem {
	my ($client, $path) = @_;
	my $order   = _choiceCurrent('o', $client);
	my $time    = _choiceCurrent('t', $client);
	my $quality = _choiceCurrent('q', $client);
	my $limit   = _choiceCurrent('c', $client);

	my $text = join(' ' . "\x{B7}" . ' ',
		_orderLabel($client, $order),
		_timeLabel($client, $time),
		_qualityLabel($client, $quality),
		_limitLabel($client, $limit),
	);

	# The query of the URL, in the "key=value" form: only the level and the
	# rail flag.  The first parameter is joined with a "?" (an older build
	# glued "&rail=1" onto a query-less URL, and the flag never reached the
	# page as a parameter).
	my @q;
	push @q, 'parent=' . _urlenc($path) if defined $path && $path ne '';
	# The rail (opt-in, parameter page): with it the page asks the Material
	# skin to dock itself beside the browse list instead of covering the
	# whole window; the small script at the end of the page does the rest.
	# Without the choice the page is the plain window it always was.
	push @q, 'rail=1' if $prefs->get('embedded_rail');
	my $url = '/plugins/LibraryMapper/index.html' . (@q ? '?' . join('&', @q) : '');

	return {
		name    => $text,
		title   => $text,
		id      => 'lm_header',
		type    => 'weblink',
		weblink => $url,
		icon    => _menuIcon('state'),
		# An attempt to give the header a "Play next" button that appends a
		# few random albums: the name of the "album_id" parameter (any value,
		# even 0) is what the Material skin looks for to show the button,
		# and the command is our own, which picks the albums and adds them.
		# The skin may still not build the button for a "weblink" item — the
		# page of the plugin keeps a link of its own for that.
		itemActions => {
			add => {
				command => [ 'librarymapper', 'randomadd' ],
				params  => {
					album_id => 0,
					n        => (_choice($client, 'random_default') || 10),
					lm_mode  => ($prefs->get('random_mode') || 'ar'),
				},
			},
		},
	};
}

# a plain (not playable) entry of the virtual tree: a genre group, or an
# artist within a genre group.  A genre group carries its icon, an artist
# none ($icon undef there).  The walk carries the path only: the choices are
# read out of the preferences by the level that answers, no level pins them.
sub _levelItem {
	my ($path, $label, $icon) = @_;
	my $enc = _encode($path);
	my %item = (
		name        => $label,
		title       => $label,
		id          => $enc,
		type        => 'link',
		url         => \&feed,
		passthrough => [ { lm_path => $enc } ],
		itemActions => {
			items => _goAction($enc),
		},
	);
	$item{'icon'} = $icon if $icon;
	return \%item;
}

# The icon of a genre group: the one the user uploaded on the parameter page
# when the group has one (served by the icon endpoint), or an instrument
# drawing of the shipped icons8 pack otherwise (t\make_genre_icons.ps1).
# The path is relative: the client resolves it against the root of the server
# (Slim::Web::ImageProxy::proxiedImage lets the local paths through).
sub _genreIcon {
	my ($key) = @_;
	if (Plugins::LibraryMapper::Data::customIconFile($key)) {
		return 'plugins/LibraryMapper/icon.png?name=' . _urlenc($key);
	}
	return 'plugins/LibraryMapper/html/images/genre/'
		. Plugins::LibraryMapper::Data::genreIconFile($key) . '.png';
}

# The second line of an album: the raw genre and the raw album artist, as
# the scan read them (not the group and the filed artist of the walk).  A
# plain text arrow: an OPML item has no HTML and no inline drawing.
sub _albumLine2 {
	my ($row) = @_;
	my $genre  = _chars($row->{'genre_raw'} || '');
	my $artist = _chars($row->{'artist_raw'} || '');
	return '' unless $genre || $artist;
	return $genre . ' ' . "\x{2192}" . ' ' . $artist if $genre && $artist;
	return $genre || $artist;
}

# an album: it can be played as such (Lyrion knows the album) and it can be
# opened to show its tracks
sub _albumItem {
	my ($path, $label, $row, $line2, $flat) = @_;
	my $enc = _encode($path);
	# line1/line2 are the two-line form the skins that support it draw;
	# name carries the one-line fallback (label, then the second line) for
	# the skins that read only name, and title the tooltip of all the tags.
	my %item = (
		name        => $label . ($line2 ? '  ' . "\x{B7}" . '  ' . $line2 : ''),
		title       => ($flat || $label),
		line1       => $label,
		line2       => $line2,
		id          => $enc,
		type        => 'playlist',
		playlist    => \&feed,
		url         => \&feed,
		passthrough => [ { lm_path => $enc } ],
		itemActions => {
			items  => _goAction($enc),
			play   => _playlistAction('load',   'album_id', $row->{'album_id'}),
			add    => _playlistAction('add',    'album_id', $row->{'album_id'}),
			insert => _playlistAction('insert', 'album_id', $row->{'album_id'}),
		},
	);
	# The cover art: the URL /music/<id>/cover wants the id of a *track*,
	# not the id of the album: the art of an album hangs on one of its
	# tracks (the "artwork" column of the albums table of Lyrion).
	my $art = $row->{'artwork_track_id'} || 0;
	if ($art) {
		$item{'artwork_track_id'} = $art;
		$item{'image'}            = 'music/' . $art . '/cover';
	}
	return \%item;
}

# one track of an album: the row carries its own status (Playing, the
# 1-based index in the queue, or ------).  Album rows carry none.
sub _trackItem {
	my ($row, $status) = @_;
	my $title = _chars($row->{'title'});
	$status = '------' unless defined $status && $status ne '';
	return {
		name  => $status . '  ' . "\x{B7}" . '  ' . $title,
		title => $title,
		id    => $row->{'track_id'},
		type  => 'audio',
		play  => $row->{'url'},
		url   => $row->{'url'},
		itemActions => {
			play   => _playlistAction('load',   'track_id', $row->{'track_id'}),
			add    => _playlistAction('add',    'track_id', $row->{'track_id'}),
			insert => _playlistAction('insert', 'track_id', $row->{'track_id'}),
		},
	};
}

# the action used to walk one level down: browselibrary items mode:librarymapper
# with the path carried in the lm_path parameter — the path only, the choices
# are read out of the preferences by the level that answers
sub _goAction {
	my ($enc) = @_;
	return {
		command     => [ 'browselibrary', 'items' ],
		fixedParams => { mode => MODE, lm_path => $enc },
	};
}

# the value a group of choices currently holds, straight from the
# preferences (the strings the values of "default" resolve to are what the
# parameter page saves).  The line of the selections of the tree reads the
# four groups here; the choices themselves are picked on the page of the
# plugin only.
sub _choiceCurrent {
	my ($sec, $client) = @_;
	if    ($sec eq 'o') { return _choice($client, 'order_default')   || 'alpha'; }
	elsif ($sec eq 'g') { return _choice($client, 'group_order')     || 'alpha'; }
	elsif ($sec eq 't') { return _choice($client, 'time_default')    || 'all'; }
	elsif ($sec eq 'q') { return _choice($client, 'quality_default') || 'all'; }
	elsif ($sec eq 'c') { return _limitMode(_choice($client, 'listLimit')); }
	elsif ($sec eq 'r') { return _randomMode('', $client); }
	elsif ($sec eq 'u') { return _choice($client, 'showUnclassified') ? 1 : 0; }
	elsif ($sec eq 'f') { return _choice($client, 'translit_default') ? 1 : 0; }
	elsif ($sec eq 'e') { my $e = _choice($client, 'expr_default'); return defined $e ? $e : ''; }
	return '';
}

# The value of one preference of the walk for the player (Data::choice).
sub _choice {
	my ($client, $pref) = @_;
	return Plugins::LibraryMapper::Data::choice($client, $pref);
}

# ------------------------------------------------- the menu of the choices
#
# A native OPML submenu, for the clients that show no HTML page (Squeezer,
# the jive players): every choice of the page of the plugin, written for the
# player that asks (Data::setChoice).  It travels with two plain-ASCII
# parameters, carried like "lm_path": "lm_menu" (sel | sel.<group>) and
# "lm_set" (<group>.<value> | reset).

# Apply one "lm_set": "<group>.<value>" or "reset".
sub _applySet {
	my ($client, $set) = @_;
	if ($set eq 'reset') {
		Plugins::LibraryMapper::Data::resetChoices($client);
		return;
	}
	return unless $set =~ /^([a-z])\.(.*)$/s;
	my ($g, $v) = ($1, $2);
	$v = _urldec($v) if $g eq 'e';
	Plugins::LibraryMapper::Data::setChoice($client, $g, $v);
}

# The line of a scan at work: "Initial scan 42% · Reading the tracks" while
# the plugin builds its database (the tree stays empty until the first scan
# is done), "Scan …" when it brings it up to date, or the scan of the server
# itself, the plugin scans after it.  Empty when nothing runs.  Plain
# characters: the tree sets it in italics (_italic), the page in <i>.
sub scanLine {
	my ($client) = @_;
	my $s = eval { Plugins::LibraryMapper::Data::scanStatus() } || {};
	if (($s->{'state'} || '') eq 'running') {
		my $text = _label($client, $s->{'initial'}
			? 'PLUGIN_LIBRARYMAPPER_SCAN_INITIAL' : 'PLUGIN_LIBRARYMAPPER_SCAN_UPDATE');
		$text .= ' ' . int($s->{'progress'} || 0) . '%';
		$text .= ' ' . "\x{B7}" . ' ' . _label($client, $s->{'step'})
			if $s->{'step'} && $s->{'step'} =~ /^PLUGIN_LIBRARYMAPPER_S_PHASE_/;
		return $text;
	}
	my $lms = eval {
		Slim::Music::Import->can('stillScanning') && Slim::Music::Import->stillScanning()
	};
	return '' unless $lms;
	my $text = _label($client, 'PLUGIN_LIBRARYMAPPER_SCAN_SERVER');
	my $pct = eval {
		my $p = Slim::Schema->rs('Progress')->search(
			{ type => 'importer', active => 1 }, { order_by => 'start DESC' })->first;
		$p && $p->total ? int($p->done * 100 / $p->total) : undef;
	};
	$text .= ' ' . $pct . '%' if defined $pct;
	return $text;
}

# Italics in plain text: the rows of a level are plain text for every
# client (Squeezer would show an HTML tag as it is), so the latin letters
# are written with the italic letters of Unicode (Mathematical Sans-Serif
# Italic); an accent stays on its letter as a combining mark.  The other
# scripts, the digits and the signs are left as they are.
sub _italic {
	my ($s) = @_;
	return '' unless defined $s;
	require Unicode::Normalize;
	$s = Unicode::Normalize::NFD($s);
	$s =~ s/([A-Z])/chr(0x1D608 + ord($1) - 65)/ge;
	$s =~ s/([a-z])/chr(0x1D622 + ord($1) - 97)/ge;
	return $s;
}

# The row that opens the menu, on every level.
sub _selectionsItem {
	my ($client, $path) = @_;
	my $enc = _encode($path);
	my $text = "\x{2699} " . _label($client, 'PLUGIN_LIBRARYMAPPER_FILTERS_MENU');
	return {
		name        => $text,
		title       => $text,
		id          => $enc,
		type        => 'link',
		url         => \&feed,
		passthrough => [ { lm_path => $enc, lm_menu => 'sel' } ],
		itemActions => { items => _menuAction($enc, 'sel') },
		icon        => _menuIcon('filters'),
	};
}

# The icons of the menu and of the line of the state (t\make_menu_icons.ps1);
# the path is relative, like the one of the genre icons.
my %GROUP_ICON = (
	o => 'order', g => 'group', t => 'dates', q => 'quality', c => 'count',
	r => 'random', u => 'unclassified', f => 'accents', e => 'expr',
);
sub _menuIcon {
	return 'plugins/LibraryMapper/html/images/menu/' . $_[0] . '.png';
}

# The action of a row of the menu: browselibrary items, the path of the level
# the menu was opened from, the menu to show and the pick to apply.
sub _menuAction {
	my ($enc, $menu, $set, %more) = @_;
	my %p = ( mode => MODE, %more );
	$p{'lm_menu'} = $menu if defined $menu && $menu ne '';
	$p{'lm_path'} = $enc if defined $enc && $enc ne '';
	$p{'lm_set'}  = $set if defined $set && $set ne '';
	return {
		command     => [ 'browselibrary', 'items' ],
		fixedParams => \%p,
	};
}

# A row of the menu.  $next names the window the client opens after the pick
# ("grandparent": back to the list, reloaded; "parent": back one level, reloaded).
sub _menuRow {
	my ($enc, $text, $menu, $set, $next, %more) = @_;
	my %pt = %more;
	$pt{'lm_menu'} = $menu if defined $menu && $menu ne '';
	$pt{'lm_path'} = $enc if defined $enc && $enc ne '';
	$pt{'lm_set'}  = $set if defined $set && $set ne '';
	my %item = (
		name        => $text,
		title       => $text,
		id          => $enc,
		type        => 'link',
		url         => \&feed,
		passthrough => [ \%pt ],
		itemActions => { items => _menuAction($enc, $menu, $set, %more) },
	);
	$item{'nextWindow'} = $next if $next;
	# the browse library drops the key of the item for a plain link: it is
	# also set on the action itself, which the jive clients read
	$item{'itemActions'}{'items'}{'nextWindow'} = $next if $next;
	return \%item;
}

# The name of the current value of a group, in the language of the client.
sub _valueLabel {
	my ($client, $g, $v) = @_;
	return _orderLabel($client, $v)   if $g eq 'o' || $g eq 'g';
	return _timeLabel($client, $v)    if $g eq 't';
	return _qualityLabel($client, $v) if $g eq 'q';
	return _limitLabel($client, $v)   if $g eq 'c';
	return "$v"                       if $g eq 'r';
	if ($g eq 'u') {
		return _label($client, $v ? 'PLUGIN_LIBRARYMAPPER_SHOWN' : 'PLUGIN_LIBRARYMAPPER_HIDDEN');
	}
	if ($g eq 'f') {
		return _label($client, $v ? 'PLUGIN_LIBRARYMAPPER_ON' : 'PLUGIN_LIBRARYMAPPER_OFF');
	}
	if ($g eq 'e') {
		return $v ne '' ? _chars($v) : _label($client, 'PLUGIN_LIBRARYMAPPER_EXPR_NONE');
	}
	return "$v";
}

my %GROUP_TOKEN = (
	o => 'PLUGIN_LIBRARYMAPPER_ORDER',
	g => 'PLUGIN_LIBRARYMAPPER_GROUP_ORDER',
	t => 'PLUGIN_LIBRARYMAPPER_TIME_FILTER',
	q => 'PLUGIN_LIBRARYMAPPER_QUALITY_FILTER',
	c => 'PLUGIN_LIBRARYMAPPER_LIST',
	r => 'PLUGIN_LIBRARYMAPPER_RANDOM_COUNT',
	u => 'PLUGIN_LIBRARYMAPPER_UNCLASSIFIED',
	f => 'PLUGIN_LIBRARYMAPPER_IGNORE_ACCENTS',
	e => 'PLUGIN_LIBRARYMAPPER_EXPR',
);

# The title of the menu: it names the player the choices belong to.
sub _menuTitle {
	my ($client) = @_;
	my $name = '';
	$name = eval { $client->name } || '' if $client && ref $client;
	return _label($client, 'PLUGIN_LIBRARYMAPPER_FILTERS_SERVER') if $name eq '';
	my $t = _label($client, 'PLUGIN_LIBRARYMAPPER_FILTERS_FOR');
	$t =~ s/%s/$name/ or $t .= ' ' . $name;
	return $t;
}

# The menu: a heading row (whose player), then one row per group.
sub _selectionsMenu {
	my ($client, $path, $app) = @_;
	my $enc = _encode($path);
	my @items;

	# In the application (Apps), the menu *is* the whole application: a
	# shortcut to the choices, no tree.  There a pick answers the menu itself
	# and goes back to it ("parent" from a list of values, "refresh" for a
	# row of the menu), since no list of the tree lies behind it.
	my @app = $app ? ( lm_app => 1 ) : ();
	my $back = $app ? 'sel' : '';
	my ($nRow, $nSub) = $app ? ('refresh', 'parent') : ('parent', 'grandparent');

	# the title row: back to the list, which reads the new choices (in the
	# application: a plain heading that names the player)
	if ($app) {
		push @items, { name => _menuTitle($client), title => _menuTitle($client), type => 'text',
			icon => _menuIcon('player') };
		# the way to the tree itself (My Music > Simplified View): a plain
		# row of the tree, no lm_menu, no lm_app
		push @items, _menuRow('', "\x{2192} " . _label($client, 'PLUGIN_LIBRARYMAPPER_VIEW'), '', '', '');
		$items[-1]{'icon'} = _menuIcon('view');
		# a scan at work: the tree is not ready yet, the application says so
		my $scan = scanLine($client);
		push @items, { name => _italic($scan), title => _italic($scan), type => 'text' }
			if $scan ne '';
	}
	else {
		push @items, _menuRow($enc, "\x{2190} " . _menuTitle($client), '', '', 'parent');
		$items[-1]{'icon'} = _menuIcon('player');
	}

	for my $g (qw(o g t q c r)) {
		my $text = _label($client, $GROUP_TOKEN{$g}) . ': '
			. _valueLabel($client, $g, _choiceCurrent($g, $client));
		push @items, _menuRow($enc, $text, "sel.$g", '', '', @app);
		$items[-1]{'icon'} = _menuIcon($GROUP_ICON{$g});
	}

	# A pick never relies on the button Back: the native clients (Squeezer)
	# keep the windows they opened, and Back shows them as they were — the
	# old value in the menu, the old order in the list.  A pick therefore
	# answers the *level* itself (no lm_menu: the list read again with the
	# new choice), and asks the client to go back to the window of the list
	# and to load it again ("parent" from the menu, "grandparent" from a
	# list of values or from the input of the expression).  A client that
	# ignores nextWindow still opens the fresh list.

	# the two switches
	for my $g (qw(u f)) {
		my $cur = _choiceCurrent($g, $client);
		my $text = _label($client, $GROUP_TOKEN{$g}) . ': ' . _valueLabel($client, $g, $cur);
		push @items, _menuRow($enc, $text, $back, $g . '.' . ($cur ? 0 : 1), $nRow, @app);
		$items[-1]{'icon'} = _menuIcon($GROUP_ICON{$g});
	}

	# the expression: a text input, and a row that clears it when one is set
	my $expr = _choiceCurrent('e', $client);
	my $etext = _label($client, $GROUP_TOKEN{'e'}) . ': ' . _valueLabel($client, 'e', $expr);
	my $eact = _menuAction($enc, $back, '', lm_expr_set => '__TAGGEDINPUT__', @app);
	$eact->{'nextWindow'} = $nSub;
	push @items, {
		name        => $etext,
		title       => $etext,
		id          => $enc,
		type        => 'search',
		url         => \&feed,
		passthrough => [ { lm_expr_in => 1, ($enc ne '' ? (lm_path => $enc) : ()),
		                   ($app ? (lm_menu => 'sel', @app) : ()) } ],
		itemActions => { items => $eact },
		nextWindow  => $nSub,
		icon        => _menuIcon('expr'),
	};
	if ($expr ne '') {
		push @items, _menuRow($enc, _label($client, 'PLUGIN_LIBRARYMAPPER_EXPR_CLEAR'),
			$back, 'e.', $nRow, @app);
		$items[-1]{'icon'} = _menuIcon('clear');
	}

	if (Plugins::LibraryMapper::Data::hasOwnChoices($client)) {
		push @items, _menuRow($enc, _label($client, 'PLUGIN_LIBRARYMAPPER_RESET_PLAYER'),
			$back, 'reset', $nRow, @app);
		$items[-1]{'icon'} = _menuIcon('reset');
	}
	return \@items;
}

# The entry of the application (Apps): the menu of the choices, nothing else.
# A request that already carries a state of its own (a row of the menu, a
# pick) is the plain feed.
sub appFeed {
	my ($client, $callback, $args, $pt) = @_;
	my $own = 0;
	for my $name (qw(lm_menu lm_set lm_expr_set lm_expr_in lm_path)) {
		$own = 1, last if _opt($args, $pt, $name) ne '';
	}
	$pt = { %{ ref $pt eq 'HASH' ? $pt : {} }, lm_menu => 'sel', lm_app => 1 } unless $own;
	return feed($client, $callback, $args, $pt);
}

# The list of the values of one group; the current one carries a check mark.
# A pick writes the value and goes back to the list, reloaded (Squeezer caches its windows).
sub _choiceMenu {
	my ($client, $path, $g, $app) = @_;
	my $def = $Plugins::LibraryMapper::Data::CHOICES{$g};
	return _selectionsMenu($client, $path, $app) unless $def && !$def->{'free'};
	my @app = $app ? ( lm_app => 1 ) : ();
	my $enc = _encode($path);
	my $cur = _choiceCurrent($g, $client);
	# the limit of a player that chose nothing shows the value of the server
	$cur = _limitMode(_choice(undef, 'listLimit')) if $g eq 'c' && $cur eq 'default';
	my @items;
	for my $v (@{ $def->{'values'} }) {
		my $mark = ("$cur" eq "$v") ? "\x{2713} " : "\x{2003} ";
		push @items, _menuRow($enc, $mark . _valueLabel($client, $g, $v),
			($app ? 'sel' : ''), "$g.$v", ($app ? 'parent' : 'grandparent'), @app);
	}
	return \@items;
}

sub _playlistAction {
	my ($cmd, $tag, $id) = @_;
	# The name of the parameter is the tag itself ("album_id", "track_id"):
	# the Material skin looks for exactly those names in the params of the
	# action (hasPlayableId) to decide whether an item is playable and so
	# whether it shows the Play/Play next/Append buttons.  A generic name
	# ("tag") hides the playability and the buttons stay away.
	return {
		command     => [ 'playlistcontrol' ],
		fixedParams => { cmd => $cmd, "$tag" => $id },
	};
}

# ------------------------------------------------------------------ helpers

# Resolve the drill-down path.  Priority:
#   1. the item passthrough (raw path, used by the classic web UI)
#   2. the lm_path parameter (base64url encoded)
# Both carry the same encoded path, so the order does not matter much; the
# decoding is done in every case.
sub _path {
	my ($args, $pt) = @_;

	if ($pt && defined $pt->{'lm_path'} && $pt->{'lm_path'} ne '') {
		return _decode($pt->{'lm_path'});
	}

	if ($args && $args->{'params'} && defined $args->{'params'}->{'lm_path'}) {
		return _decode($args->{'params'}->{'lm_path'});
	}

	if ($pt && $pt->{'searchTags'}) {
		for my $tag (@{ $pt->{'searchTags'} }) {
			next unless $tag =~ /^lm_path:(.*)$/;
			return _decode($1);
		}
	}

	return '';
}

# Read one request parameter, wherever it is carried.
sub _param {
	my ($args, $name) = @_;
	return '' unless $args;
	return $args->{'params'}->{$name}
		if $args->{'params'} && defined $args->{'params'}->{$name};
	if (ref $args eq 'HASH' && defined $args->{$name}) {
		return $args->{$name};
	}
	return '';
}

# A parameter of the menu: the passthrough of the item (the web UI), the
# request (the jive clients, the CLI), or the search tags of the browse
# library.
sub _opt {
	my ($args, $pt, $name) = @_;
	if ($pt && ref $pt eq 'HASH') {
		return $pt->{$name} if defined $pt->{$name} && $pt->{$name} ne '';
		if ($pt->{'searchTags'}) {
			for my $tag (@{ $pt->{'searchTags'} }) {
				return $1 if $tag =~ /^\Q$name\E:(.*)$/s;
			}
		}
	}
	my $v = _param($args, $name);
	return defined $v ? $v : '';
}

# One label of the strings of the server, in the language of the client.
sub _label {
	my ($client, $token) = @_;
	my $text = '';
	if ($client) {
		eval { $text = clientString($client, $token) || ''; };
	}
	$text = '' unless defined $text && $text ne '';
	if ($text eq '') {
		eval { $text = string($token) || ''; };
	}
	return $text || $token;
}

# The label of one row of the level of the genre groups: the pseudo entries
# ("Random", the "%%" aggregate, "All artists", the group without genre)
# carry their own name, the genre groups the name of the group itself.  The
# "%%" row is named by its scope: the library-wide shortcut at the top of
# the tree is "All albums", the aggregate of the genre walked into — the
# first row of the artist list of one genre, the albums of the whole genre
# under the selections — is "Selected albums".  Guard clauses, no nested
# ternary chain — one flag read at most, and no paren counting left to the
# reader.
sub _levelLabel {
	my ($client, $row, $path) = @_;
	$path = '' unless defined $path;
	return _label($client, 'PLUGIN_LIBRARYMAPPER_RANDOM') . ' (' . $row->{'n'} . ')'
		if $row->{'random'};
	if ($row->{'allalbums'}) {
		return _label($client, 'PLUGIN_LIBRARYMAPPER_SELECTED')   if $path ne '';
		return _label($client, 'PLUGIN_LIBRARYMAPPER_ALL_ALBUMS');
	}
	return _label($client, 'PLUGIN_LIBRARYMAPPER_ALL_ARTISTS')  if $row->{'all'};
	return _label($client, 'PLUGIN_LIBRARYMAPPER_UNCLASSIFIED') if $row->{'unclassified'};
	return _chars($row->{'key'});
}

sub _encode {
	my $s = shift;
	return '' unless defined $s && $s ne '';
	# the path is a text: it is encoded as UTF-8 bytes before it is put in
	# base64, so that the name of an artist keeps its accents on the way
	utf8::encode($s) if utf8::is_utf8($s);
	my $b = MIME::Base64::encode_base64($s, '');
	$b =~ tr{+/}{-_};
	$b =~ s/=+$//;
	return $b;
}

# The name of a value in the language of the client.
sub _orderLabel {
	my ($client, $v) = @_;
	my %map = (
		alpha     => 'PLUGIN_LIBRARYMAPPER_ORDER_ALPHA',
		newer     => 'PLUGIN_LIBRARYMAPPER_ORDER_NEWER',
		older     => 'PLUGIN_LIBRARYMAPPER_ORDER_OLDER',
		added     => 'PLUGIN_LIBRARYMAPPER_ORDER_ADDED',
		count     => 'PLUGIN_LIBRARYMAPPER_GROUP_COUNT',
		countasc  => 'PLUGIN_LIBRARYMAPPER_GROUP_COUNTASC',
		longest   => 'PLUGIN_LIBRARYMAPPER_ORDER_LONGEST',
		shortest  => 'PLUGIN_LIBRARYMAPPER_ORDER_SHORTEST',
		unsorted  => 'PLUGIN_LIBRARYMAPPER_ORDER_UNSORTED',
	);
	return _label($client, $map{$v} || 'PLUGIN_LIBRARYMAPPER_ORDER_ALPHA');
}

sub _timeLabel {
	my ($client, $v) = @_;
	my %map = (
		all   => 'PLUGIN_LIBRARYMAPPER_T_ALL',
		day   => 'PLUGIN_LIBRARYMAPPER_T_DAY',
		week  => 'PLUGIN_LIBRARYMAPPER_T_WEEK',
		month => 'PLUGIN_LIBRARYMAPPER_T_MONTH',
		year  => 'PLUGIN_LIBRARYMAPPER_T_YEAR',
	);
	return _label($client, $map{$v} || 'PLUGIN_LIBRARYMAPPER_T_ALL');
}

sub _qualityLabel {
	my ($client, $v) = @_;
	my %map = (
		all     => 'PLUGIN_LIBRARYMAPPER_Q_ALL',
		hires   => 'PLUGIN_LIBRARYMAPPER_Q_HIRES',
		cd      => 'PLUGIN_LIBRARYMAPPER_Q_CD',
		lossy   => 'PLUGIN_LIBRARYMAPPER_Q_LOSSY',
		dsd     => 'PLUGIN_LIBRARYMAPPER_Q_DSD',
		unknown => 'PLUGIN_LIBRARYMAPPER_Q_UNKNOWN',
	);
	return _label($client, $map{$v} || 'PLUGIN_LIBRARYMAPPER_Q_ALL');
}

sub _urlenc {
	my $s = shift || '';
	$s =~ s/([^a-zA-Z0-9_.\-~])/sprintf('%%%02X', ord($1))/ge;
	return $s;
}

# The inverse of _urlenc, for the free text of the expression: anything that
# holds a space stays out of the plain form of the CLI parameters, and the
# encoder leaves no space behind; a value with a space is therefore taken as
# raw text (the passthrough of the web UI carries it unencoded).
sub _urldec {
	my ($s) = @_;
	return '' unless defined $s;
	return $s if $s =~ /\s/;
	$s = _chars($s);
	$s =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
	return $s;
}

# The *choice* of the number of items carried by a request: "default" when no
# explicit choice is there (or when a value is unknown), the choice itself
# otherwise.  The tree always carries a choice, never the resolved number,
# so that "default" keeps meaning "the preference of the parameter page
# decides" down the whole drill-down.
sub _limitMode {
	my ($value) = @_;
	return 'default' unless defined $value && $value ne '';
	return 'unlimited' if $value eq 'unlimited' || $value eq 'all' || $value eq '0';
	return $value      if $value =~ /^\d+$/ && $value > 0;
	return 'default';
}

# The *choice* of the number of the albums of the draw ("Random"): a number
# between 1 and 100, the preference of the parameter page otherwise.
sub _randomMode {
	my ($value, $client) = @_;
	return 0 + $value if defined $value && $value =~ /^\d+$/ && $value >= 1 && $value <= 100;
	my $pref = _choice($client, 'random_default') || '';
	return 0 + $pref if $pref =~ /^\d+$/ && $pref >= 1 && $pref <= 100;
	return 10;
}

# The name of a limit, in the language of the client.  The limit travels as
# a *choice* ("default" included), so its name is that choice.
sub _limitLabel {
	my ($client, $value) = @_;
	return _label($client, 'PLUGIN_LIBRARYMAPPER_DEFAULT')   if $value eq 'default';
	return _label($client, 'PLUGIN_LIBRARYMAPPER_UNLIMITED') if $value eq 'unlimited';
	return $value;
}

# The names of the database are UTF-8 bytes.  The server writes a byte
# string as Latin-1, which would show "Jules BillÃ©": the names are therefore
# given to the server as characters, so that they are encoded once.
sub _chars {
	my $s = shift;
	return '' unless defined $s;
	utf8::decode($s) unless utf8::is_utf8($s);
	return $s;
}
sub _decode {
	my $s = shift;
	return '' unless defined $s && $s ne '';
	return $s if $s =~ /\|/;                 # already a raw path
	$s =~ tr{-_}{+/};
	$s .= '=' x ((4 - length($s) % 4) % 4);
	my $d = eval { MIME::Base64::decode_base64($s) };
	return '' unless defined $d;
	# the path stays UTF-8 bytes: that is the language of the database
	return $d;
}

1;
