# LibraryMapper (LMS plugin)

Shareable **query-only** mapping workbench for Lyrion Music Server.
No file operations — ever. It builds a dedicated SQLite database
(`plugin persist dir/LibraryMapper/librarymapper.db`) from Lyrion's own
indexed library (`Slim::Schema`), lets you curate simplified genre groups
(10–20 groups from the raw genre list), consolidate album artists, and
browse the **virtual** target layout:

    Genre \ Artist \ Year - Album

with two extra filters that are part of the application:

- **Temporal filter** — albums added on the server in the last day/week/month/year
- **Quality filter** — Hi-Res (>48 kHz) / CD lossless / Lossy / **1bit Hi-Res
  (DSF/DFF)** / Unknown

## Pages
| URL | Purpose |
|---|---|
| `My Music > Simplified View` | The same drill-down, as a native browse mode of the server (every skin) |
| `/plugins/LibraryMapper/index.html` | Virtual browse app (filters + drill-down) |
| `/plugins/LibraryMapper/settings/basic.html` | Parameter page: initialization, validation report, mapping upload/download, trusted artists |
| `/plugins/LibraryMapper/download.json` | Export the mapping file (JSON) |

## The number of items that are shown
A level of the tree is cut at the limit of the plugin. The choice lives in
**two places that hold the same value**: the `Items shown` selector of the
virtual browse page, and the parameter page. **Default** means that the
parameter page decides. The same five values are offered by the selector of
the page and by the parameter page. The selector is in bold and its label in
the accent colour of the skin, and the header of the page wraps, so that the
selector is not pushed out of sight in the narrow window of the Material skin.

## The line of the selections
The **last** row of every level is the line of the selections:
`<order> · <dates> · <quality> · <count>` — the choices in use, read out of
the preferences at each request. It opens the page of the plugin (filters +
help), where they can be changed.

**The choices are global.** The sorting of the artists and of the albums comes
from the **Order** selector of the page, the order of the genre groups from
the separate **Group order** selector: picking anything on the page and
pressing **OK** writes the preferences of the plugin, and **every level the
tree fetches afterwards reads them at its own request** — the picks apply to
the whole tree at once. The rows of the tree carry the walk path only; no
`lm_order`, `lm_time`, `lm_quality` or `lm_limit` travels any more, and the
URL the header line carries holds no choice either (the page falls back to
the preferences itself), so a remembered link can no longer re-register an
old value over the picks. The request parameters stay honoured for the
callers that send them (the CLI, the tests).

One honest exception: the **Back** of the Material skin re-serves the
snapshot of the previous level it kept in its page stack, without any request
— a level reached through Back keeps showing the list as it was before the
picks until it is entered again. No server can invalidate that snapshot; the
skins fetch everything else anew.

### The Uncategorised chip of the selbox
The row of the chips of the header box carries a third button beside **[Help]**
and **[Playlist]**: **Uncategorised**, with a ring that fills when the virtual
group is shown. It is a shortcut to the parameter page, not a filter of its
own: a click writes the shared `showUnclassified` preference and reloads the
page, so the **genre list, the My Music tree and the checkbox of the parameter
page all change together**. The virtual group is a top-level entry — on a
deeper level the chip still shows and keeps its pressed state, but the group
itself becomes visible when the list of the genres is opened again.

The click sends a *one-shot* `unc=0|1` on the address. No form field, no link
and no `extraQ` carries it: a request without `unc` (a form submit, a
breadcrumb, the bare URL of the tree header) simply keeps the preference as it
stands, so a remembered link can never re-register an old value. Only `0`
and `1` are accepted; anything else is ignored. The rest of the address (the
walk path, the player, `rail`, the choices already in the query string) is
kept as it is.

## Choices per player, and the native menu (Squeezer)

Every choice of the walk (album order, group order, dates, quality, items per
list, random draw, Uncategorised, ignore accents, expression) belongs to the
**player that asks**: a player keeps its own values (client preferences), a
player with none uses the values of the server — the ones the settings page
edits, which are therefore *the defaults of the players*. With no player (the
CLI, a headless server, a page opened without a player) the server values are
read and written.

The native clients (Squeezer on Android, the jive players) show no HTML: the
line of the selections and the settings page do nothing there. Every level of
the tree therefore carries a row **⚙ Filters & sorting** just before the line
of the selections. It opens a native menu titled after the player:

- one row per choice list (order, group order, dates, quality, items per list,
  random draw): it opens the list of the values, the current one is marked ✓;
  a pick writes it for the player and goes straight back to the list, reloaded (so the Back button of Squeezer never shows a stale value)
- two switches (Uncategorised, ignore accents) that flip in place
- the expression, a text input, with a *Clear* row when one is set
- *Reset this player to the server defaults*, when the player has values of its own
- the first row (← title) goes back to the list, which reads the new choices

The menu travels in plain-ASCII parameters carried like `lm_path`:
`lm_menu` (`sel` | `sel.<group>`), `lm_set` (`<group>.<value>` | `reset`) and
`lm_expr_set` (the typed expression). The groups: `o` order, `g` group order,
`t` dates, `q` quality, `c` items per list, `r` random draw, `u` Uncategorised,
`f` ignore accents, `e` expression. From the CLI:

    librarymapper items 0 50 lm_menu:sel
    <playerid> librarymapper items 0 50 lm_menu:sel.q lm_set:q.hires

The settings page (scan, mapping upload, genre rules, icons) stays web-only:
open `http://<server>:9001/settings/` in the browser of the phone.
## The rail (experimental, Material skin only)
An opt-in box on the parameter page ("Open the page beside the list"). When
ticked, the **line of the selections** carries `rail=1`: Materials loads the
page in its fullscreen dialog as always, but a small script on the page — same
origin, so it may look at the parent document — docks the dialog to the
**right half of the window** (42vw, full width on a narrow window): the
browse list stays visible at the left and keeps the touches. Everything works
by HTML5 DOM manipulation of the parent, **no skin file is modified**; if any
element is missing (skin update, other skin, page opened standalone), the
script gives up and the page stays the plain window it always was.

## The header of the tree
Restored as the **last** row of every level (as it stood before the choices
experiment): the level the user lands on comes first, so the tree opens on
its content at once. The line shows the current selections and opens the page.

## The sorts of the tree
Two selectors set the sorts: **Order** (the levels below the groups) and
**Group order** (the genre groups themselves). The Order selector offers one
entry per dimension, and **every level sorts by the dimension that applies
to it**:

| Order | Artists of a group | Albums of an artist |
|---|---|---|
| Alphabetical | sort key (last name first) | album name |
| Newest first | date the last album was added | release year, newest first |
| Oldest first | idem, least recent first | release year, oldest first |
| Recently added first | date the last album was added | date the album was added |
| Most albums first | album count | (stays alphabetical) |
| Fewest albums first | idem, fewest first | (stays alphabetical) |
| Longest first | total playing time of the artist | album duration, longest first |
| Shortest first | idem, least music first | album duration, shortest first |
| **Unsorted** | the rows as they come | the rows as they come |

A tie is always settled alphabetically. **Group order** sorts only the genre
groups (Alphabetical / Most albums first / Fewest albums first / Unsorted).

**Unsorted means no sort at all**: the list is shown in the order the query
holds as it comes, no ORDER BY is written. One row is added anyway: when the
expression carries a `sort:` term, the Order selector shows **Unsorted** —
the sort of the page is the one of the expression, so no fixed choice stands.

## The entries on top of the list
The top of the list carries three pseudo entries **before** the genre groups:

The lines of the tree carry their **two numbers** in parentheses:
`(art:  30, alb:  189)` — the artists and the albums of the line, under the
selections in use (the count bracket of the pseudo rows *All artists* and
*All albums*, of the genre groups of the top level, and of the *Selected
albums* row of a walk; the group rows keep the albums that carry no artist of
their own — only the number of albums stands for them). The gaps before the
two numbers are **no-break spaces**, so the skins' HTML does not collapse
them to one. The *Random* row keeps its draw count in its name. Every row of
the walk that is **one artist** carries its album count alone: *Miles Davis
(3)*. The **level table of the page** shows the same two
numbers in two columns on the level of the groups (the tiny header
`art | alb`), and keeps its one album-count column on the level of the
artists — every artist is counted by its albums there.

- **All artists** — the double quaver ♬, with the album count of the whole
  library. It is not a genre: it opens the list of **every artist of the
  library**, whatever group their albums belong to (the albums without a
  genre included, the setting *Show the Uncategorised fallback*
  notwithstanding). The walk below it keeps its own path — an album reached
  through "All artists" is never re-filed under a real genre.
- **All albums** — the double quaver ♬ as well. It opens the list of **every
  album that matches the selections** (the time filter, the quality filter,
  the order, the expression), **whatever the artist** — one single row per
  album, so an album filed under several artists is listed once (the walks
  list it under every artist of it). Every album keeps `All albums` in its
  path, so the drill-down of every skin walks on there and is never re-filed
  under a real genre. The same aggregate row also stands on top of the
  **artist list of one genre** — there it is named **Selected albums**, and
  its count honours the expression as well.
- **Random (n)** — the double quaver ♬ too. The dice 🎲 of the browse page
  opens **a limited draw of n albums** matching the selections and the
  expression, whatever the artist; the count is the choice beside the dice
  (5 / 10 / 20 / 50 / 100, remembered like the other choices). The walk below
  the draw carries on like any album level. A draw is its own order: the
  sort of the expression does not take part in it (a sorted draw would
  always pick the same albums).

While a scan is at work, an **italic line** stands above everything else:
*Initial scan 42% · Reading the tracks* while the plugin builds its database
for the first time (the tree stays empty until it is done), *Scan …* when it
brings it up to date, *Library scan of the server …* while the server itself
scans (the plugin scans after it). The tree, the application (third row) and
the page all show it. The rows of the tree are plain text for every client
(Squeezer would show an HTML tag as it is), so the tree writes the latin
letters with the italic letters of Unicode (`Browse.pm::_italic`); the page
uses `<i>`. The line is read when the level is fetched: go back and in again
to see the percentage move.

## The icons of the genre groups
Every genre group carries a small icon in the tree (Simplified View) and on
the page (genre level). By default it is a **transparent** instrument drawing,
one muted colour per group — violet violin for Classical, amber saxophone for
Jazz, red guitar for Rock... The drawings come from the **Windows 8** set of
Icons8 (free with a link back to `icons8.com`), recoloured by
`t\make_genre_icons.ps1` (run it with `-White` to have them all in white).
Custom groups and the groups without a fitting instrument in the pack
(Country, Reggae) show the neutral treble clef. The three pseudo entries at
the top of the list — *All artists*, *All albums* and *Random* — carry the **double
quaver** ♬ instead (`notes.png`, drawn by the same script from the Unicode
glyph, no icon-set download involved). The full credits are in
`html/images/genre/CREDITS.txt`.

**Your own icons**: on the parameter page (*Genre group icons*) a **zip
archive** can be uploaded — one icon per genre group, named after the group
(`Jazz.png`, `Classical.png`...; png, gif, ico, jpg; a single loose icon file
is accepted as well). The archive is unpacked into the icon folder of the
plugin (`prefs/LibraryMapper/icons/`, beside the database: it survives a
restart), and every uploaded icon replaces the shipped drawing of that group.
The name of a file goes through the same folding as the group itself
(`Soul R&B.png` answers for the group "Soul/R&B"), and a customary group name
also finds its icon (`Metal.png` for the rock group). The group of the albums
without a genre is named `Unclassified.png` (`Default.png` is accepted; the
ship of the group is replaced the same way). Groups without an uploaded file
keep the shipped drawing. *Remove the uploaded icons* puts the shipped
drawings back in place.

## The quality classes
The class of an album (or of a track) is computed when the library is scanned:

| Class | What it is |
|---|---|
| `hires` | the samplerate is above 48 kHz |
| `cd` | the samplerate is above 40 kHz (CD and above) |
| `lossy` | the server reports the track as not lossless |
| `dsd` | the one bit files (`.dsf` and `.dff`) — **1bit Hi-Res** |
| `unknown` | the server reports nothing about the track |

The one bit files are a class of their own: the server reports them with a
samplerate of 2.8 MHz (a DSD64) or more, which would put them into the
hi-res class, but they are not a "96 kHz" of the PCM world — they are a
different technology. Two witnesses tell that a track is one of them: the
size of a sample (one bit) and the name of the file. An album is one bit
when **all** of its tracks are; a mixed album keeps the class of its other
tracks.

## The names
The names come out of the database as UTF-8 bytes and are handed to the
server as characters: the server writes a byte string as Latin-1, which
would show `Jules BillÃ©` instead of `Jules Billé`. The pages of the plugin
bring their own colours (the colours of the theme of the skin when they are
there), so that they stay readable in the light theme and in the dark theme.

## The order of the artists
The artists are not sorted by the name as it is written: **a person is filed
under its last name, a group under the name it carries**.

    "Claude Nougaro"        -> "nougaro claude"   (a person)
    "Nougaro, Claude"       -> "nougaro"          (the inverted form)
    "Metallica"             -> "metallica"        (a group)
    "The Beatles"           -> "beatles"          (the leading article is skipped)
    "Miles Davis Quintet"   -> "miles davis"      (the ensemble word is skipped)
    "Peyceré Trío"          -> "peycere"          (Trío is seen as trio)

The rules, in the order they are applied:

1. **a comma** means the name is already inverted — the part before the comma
   is the key (`Nougaro, Claude` → N). A group is not read that way: in
   `Earth, Wind & Fire` the comma is only a separator
2. **an ensemble word** — in several languages, and with or without the accent
   (`Trío`, `Dúo`, `Orquesta`, `Quatuor`, `Orquestra`…): the *how many players*
   words (duo, duet, trio, quartet, quintet, sextet… in English, French, German,
   Spanish, Italian, Dutch, the Scandinavian, Polish, Czech, Hungarian, Finnish,
   the Russian transliterations…), the *orchestra* words (orchestra, orchester,
   orquesta, orkester, orkiestra…), the *band* and *group* words (band, banda,
   groupe, gruppo, gruppe, grupo, conjunto, zespół, zenekar, yhtye…), the *choir*
   words (chorus, choir, chor, cor, koor, sbor, kuoro, chœur…), *big band*,
   *symphony*, *philharmonic*, *ensemble*, *collective*… and the *guest* words
   (feat., ft., and, et, with) —
   makes it a group: the ensemble word is skipped and the rest is sorted as it
   stands (`Miles Davis Quintet` → `Miles Davis` → **M**). The words are
   matched on the folded name, so `Peyceré Trío` is filed under `peycere`
   (**P**), not under **T**
3. **exception — a word that is the whole name**: a group can be called just
   `Trio` or `Duet` (a French group, a French jazz duo); when nothing is left
   after skipping the ensemble words, the word is the name itself and is kept
3. **`&`, `+` or `/`** in the name makes it a group (`AC/DC` → `ac dc`)
4. **a leading "The"** is skipped (`The Beatles` → `Beatles`)
5. **otherwise it is a person**: the last name comes first and the suffixes
   (Jr., Sr., II, III, IV, PhD, MD) are ignored (`Claude Nougaro` →
   `nougaro claude` → **N**)

A group whose name is a single word (`Metallica`) is filed under that word, so
`Metallica` and `Miles Davis Quintet` both live under **M**, while the person
`Miles Davis` lives under **D**.

The album artist name is not shortened when the name carries an ensemble word:
`Miles Davis Quintet` stays `Miles Davis Quintet` (it is not turned into
`Miles Quintet`).

## Transliteration
A name that is not written in Latin letters is transliterated first, so that it
is filed under a readable letter and not after the "z":

| Script | Rule | Example |
|---|---|---|
| Cyrillic | letter by letter | `Шарль Азе` → `aze sharl` |
| Hebrew | letter by letter | `אביב` → `abyb` |
| Japanese | the kana are romanized from the name Unicode gives them, so no code point is written by hand | `中島りゆき` → `riyuki` |
| Chinese | the name is filed under its family name, taken from a table of the 217 most common ones | `王明` → `wang`, `欧阳修` → `ouyang` |

A name that cannot be transliterated (a Japanese name written in kanji only) is
filed at the end, under a stable key built from its code points: the order stays
the same from one run to the other.

The Chinese table is generated by `t/gen_zh_table.pl`, which checks every code
point — two names sharing one code point is an easy mistake to make.

## The artist filter
At the artist level a **regular expression** narrows the list down. It is
matched against the artist names, case insensitively:

    ^Miles              the artists whose name starts with "Miles"
    Davis$              the artists whose name ends with "Davis"
    (Quintet|Trio)      the ensembles

An invalid expression is ignored and reported on the page.

On the parameter page the same search can match the **name as written**, or its
**sort key** ("davis, miles" — the key the artist is filed under: the last name
first, both in lower case). The key is matched the same way (regular
expression, case insensitive unless the case sensitive box is ticked), so
`s,d ` finds every person filed under a surname starting with d. The result
table shows the sort key of every row either way.

At the artist level a check box **Translit** folds both the pattern and the
names: `edith` finds **Édith Piaf**. With the box on, the pattern is also
compared with the computed **sort key** of every name, so a name written in
another alphabet is found by its Latin letters: `chaikovski` finds
**Чайковский** (filed as `chaikovskii`), whose plain name holds no Latin
letter at all. The box is part of the choices the page remembers.

## The expression
On every level but the tracks, a fold of the form holds a small **expression**
— a list of conditions written with spaces between them (every term must be
true), and an optional sort:

    year:1980..1990             a range of years (the two dots)
    87                          the years "87" and "1987" are the same
    duration:>45:00             the album is longer than 45 minutes
                                ("1:02:00", "45:00" or plain seconds)
    duration:900-3000           a numeric range (the dash, no dots)
    count:>=2                   the artist has at least 2 albums
    year:=1969  year:1969       the exact year (the ":" may carry the
                                comparison: year:>2000 is read as year>2000)
    year:!=2012                 different from
    genre:(Jazz,Pop)            one tag of the list (on the strings the
                                tags of the albums carry)
    sgenre:(Jazz,Pop)           one **group** of the list — the group the
                                album is filed at (the Simplified View);
                                the value is read as a TEXT, never as a
                                pattern (sgenre:Jaz. finds nothing)
    genre:chamber               the genre as **the TAG carries it**: the
    genre:conc.*o               value is a regular expression, matched
                                without anchors and without case —
                                genre:chamber finds "Chamber Music";
                                genre:conc.*o finds "Concerto",
                                "concertino" and "Conceto". The list form
                                genre:(rock,opera) matches any of the
                                patterns, the negated genre!=conc keeps
                                what does not match (the albums without
                                a tag stay away from that one)
    title:~love                 "like": the tag contains the text
    artist:"miles davis"        a value with spaces, in quotes
    track:nirvana               the album holds a track whose **title**
                                matches: a regular expression, like the
                                genre tag ("suite" finds "Nirvana Suite";
                                the list track:(pat1,pat2) matches any of
                                the patterns, the negated track!=pat
                                keeps the albums without such a track).
                                When such an album is opened, the level of
                                the tracks shows the **matching tracks
                                only** — the other terms of the expression
                                chose the album, they are not read there
    trackN:5                    the album holds a track whose **number** is
    trackN:5..7                 5 (a "1/20" form is read as its first
    trackN>4                    number, the scan keeps only it): a
                                comparison, a range 5..7, a list
                                trackN:(5,7,9); the negated trackN!=1 keeps
                                the albums where no track carries the
                                number. The opened album shows the
                                matching tracks only, as above. The
                                "Disc.Track" form of the multi-disc
                                albums ("2.05") is read as the **track of
                                the disc** — the scan folds it itself
                                (the track is the number after the dot,
                                the disc keeps the first one when the
                                file carries none), and the term folds
                                the value it is given the same way: a
                                list and a range are folded member by
                                member
    sartist:chaikovski          the **sort key** of the artist (the artists
                                level only): the name transliterated and
                                filed under its last name — "Чайковский"
                                is filed as "chaikovskii". The value is a
                                regular expression on that key (sartist:me
                                keeps every artist whose key holds "me";
                                the forms sartist=pat, sartist~:pat and
                                sartist~pat are read the same way). The
                                key is computed in perl, never in the SQL
    sort:duration-,title        the results are ordered by duration
                                descending, then by title
    sort:sartist                the artists are ordered by their sort key
                                ("sartist-" turns the order around)

The tags of each level: **year, duration, title, artist, genre, sgenre,
track, trackN, quality, added** on the albums and the genre groups (the
`added` tag takes values like `2023`, `2023-06` or `2023-06-15`; `genre` is
the tag, `sgenre` is the group of the Simplified View; `track` and `trackN`
read the tracks of the album — a title matching, a number matching — and the
opened album shows the matching tracks only); on the artists level:
**artist, count, duration, year, added** (the conditions on the count, the
total duration and the last year of the artist apply to the whole artist,
not to one album). An unknown tag or an unreadable value is reported on the
page and **ignored** — the walk stays whole.

A `sort:` replaces the order the walk would have used; a sort on the
albums of the artists ("sort:duration-") is the order of the albums, a
sort on the artists level ("sort:count-") is the order of the artists.
While such a sort is in use, the **Order** selector of the page shows
**Unsorted** — the sort of the expression is the one of the walk, so no
fixed choice of the list stands (and choosing Unsorted itself means: no
sort at all, the rows as they come).
The next to the page a **Help** fold under the expression field opens the
list of the keywords (the same list, in every language — the keys are keys).

The expression travels with the walk like the other choices of the page, and
the tree carries it too. It applies **before** the number of items is cut.

## Random albums
The 🎲 **Random albums** link next to the OK button picks a few albums (the
filters and the expression of the page stay in force) and **appends them to
the playlist** of the player the page is opened for. A count (5 / 10 / 25 /
50 / 100) and a **prefix** select sit beside the link; the prefix says what
an album contributes to the playlist and in which order the albums are
picked:

`[no label]`
- **`ar`** — albums drawn at random, added whole (the default)
- **`a_`** — the first albums of the current order of the page, added whole
- **`ft`** — the first track of *N* albums drawn at random
- **`fa`** — the first track of *N* albums in the current order of the page
- **`rr`** — one track drawn at random in each of *N* albums drawn at random

An album is always picked **once**: no album comes into the list twice. The
prefix and the count are remembered like the other choices of the page, and
a change of the two selects is written into the link at once (no round trip
needed before pressing the button). The same service is reachable from the
command line (`librarymapper randomadd n:10 lm_mode:ft`); the header of the
tree tries to reach it as well, but a skin decides on its own whether it
shows that button.

## The pane of the queue
The **[Playlist]** key on the line of the expression (beside the [Help] chip)
opens a **pane at the right edge of the page** with the current queue of the
player the page is opened for. The header carries the name of the player, the
**transport** and the **Clear**: the stop and the pause are the glyphs of the
usual keys and carry no word — one key holds the stop (filled ⏹) and the play
(▶), the other the pause (⏸) and the continue (▷, the outline triangle);
the word of **Clear** stays alone at the right end. A **✕ at the far right of the header
closes the pane** (the [Playlist] key toggles it back); the state glyph of the
header shows the mode of the player (▶ / ❚❚ / ⏹). Every row carries its
**left arrow (←)**: it plays that track now (`playlist jump`), the order of
the queue never changes. The pane follows the queue (a poll at every four
seconds while it is open) and marks the track in play; the class of quality
of every row comes from the database of the plugin. Every key and marker is a
**tiny inline drawing** built by the page itself, never a font glyph — a
drawing renders the same in every browser (some fonts miss the keys of the
transport or print them out of the wrong font) and takes the colour of the
page (currentColor).

The [Help] chip left the fold of the expression and came up on the line
itself: both chips stay reachable when the fold of the expression is closed.

## The album rows: original tags and the state of the queue

Both surfaces — the album list of the browse page **and** `My Music →
Simplified View` — show each album on two lines. The second line is the
**original genre tag** followed by the **original album artist**, separated by
a small arrow:

```
1959 - Kind of Blue
Bebop → Miles Davis
```

The arrow is a tiny inline SVG on the page and the plain `→` in the tree, never
a font glyph (the dingbat that shape is missing from some engines and printed
as a blank box). An OPML item has no second line in every skin: the tree also
hands `line1` / `line2` to the skins that support them and keeps `name` as a
**one-line fallback** (`1959 - Kind of Blue · Bebop → Miles Davis`) for the
others.

### The card of tags over a cover

Hover the cover on the page (or give it the focus with the keyboard) and a
floating card opens: **two columns, 11px monospace**, one `NAME:value` pair per
cell, a `|` drawn between the columns. Every original tag of the album is
there, **sorted alphabetically by tag name**; a tag that occurs more than once
keeps the order of the scan. `GENRE` can therefore appear several times — an
album whose tracks disagree shows **every raw spelling**, not only the
majority one. The other pairs are `ALBUMARTIST`, `ARTIST`, `ALBUM`, `YEAR`,
`DURATION`, `QUALITY`, `ADDED`, `TRACKS`, and the Simplified View values
`SV_GENRE`, `SV_ARTIST` (plus `SV_MODE` when the group was derived). The `SV_`
keys are drawn with a lighter key: they are the **virtual filing**, not tags
read from the files. `SV_GENRE` is always the group the album is **really
filed at** — even when the walk went through a pseudo group (All albums,
All artists, Random, whose own pseudo key `%%` / `*` / `@@` only builds the
path of the drill-down). `STATUS` stands in its alphabetical place.

The **path of the files** closes the card (0.8.11): the folder of the album
relative to the root of the library (`PATH:Jazz/Miles Davis/1959 - Kind of
Blue`), not alphabetical, a plain line at the bottom in a smaller font on
the page card. The root is the `mediadir` / `mediadirs` of the server; a
file scanned outside of those keeps its absolute path. In the native tree
it is the last segment of the flat tooltip string. On the tracks level of
the page, hovering a track row shows the path of its own file (the `title`
attribute). Nothing is stored: the path is computed from the url of one
representative track at every read.

The tree cannot draw a card or change the font: an OPML item has only `title`,
so it receives the same list as one flat `NAME:value | NAME:value` string.

### Playing, #N and ------

`STATUS` (the card, the tree's `title`) and the **status cell of every track
row** carry one of three states, in this order of priority:

| State | When |
|---|---|
| `Playing` | the player is in play/pause and the current track is this track, or belongs to this album |
| `#N` | the 1-based index of the **first queued track of the album** in the queue (the track's own index on a track row) |
| `------` | nothing of this album is in the queue |

A stopped player is never `Playing`: its tracks keep their `#N`. **Album rows
carry no status column and no badge**; only track rows do. On the page the state
is **live** — the same `queue.json` poll that feeds the [Playlist] pane repaints
the cells and the open card every four seconds — while the tree takes a
**snapshot** when it fetches the level (and Material's *Back* re-serves the
snapshot it kept of that level).

Both surfaces read the same `Data::queueStatus`; the old reader of
`pageQueue` was folded into it so the queue pane, the cells and the tooltip
can never disagree.

### The store of the raw tags

`album_tags` keeps **every raw `GENRE` spelling** of every album, in the order
the scan met it. It is a table of its own on purpose: `init()` can create it
without rebuilding (and emptying) the `albums_cache` of an already installed
server. On a server updated from an earlier release the table is empty until
the **next library scan** — until then the tooltip falls back to the single
`genre_raw` of `albums_cache` and shows one (possibly empty) `GENRE:` pair.

## Album durations
The album list shows the **total duration** of the album — on the page in its
own column, in the tree beside the name of the album. The libraries often
carry the same album in two encodings in one folder (the mp3 copies of the
flac files): the duration is computed **per encoding** (one bit files, lossless,
lossy/other) and the **longest** bucket is shown, not their sum.

The visibility of the entry of the application in the **Apps** list is a box on
the parameter page: at the very moment it is saved, the Apps menu of the
players, of the Material skin and of the web interface shows or hides the
entry — the server does not have to be restarted. The entry of **My Music**
(the Simplified View) is always there. The application opens the menu
*Filters & sorting* of the player only (`Browse::appFeed`, and `lm_menu:sel
 lm_app:1` in `cmdAppItems`): a pick there comes back to that menu; its second row (→ Simplified View)
opens the tree. The icons of the menu and of the line of the state are drawn by
`t\make_menu_icons.ps1` (`html/images/menu/`).

## The choices of the page are remembered
Every choice made on the page (the temporal and quality filters, the order,
the order of the groups, the number of items, the expression and the toggle
of the accents) is written into the preferences of the plugin — the ones the
tree reads as well: the next time the page is opened — with the *Back* of
the skin, from another machine — the same filters are in place. The page and
the tree hold **one shared state**: the page reads the preferences when its
request carries no choice (the link the tree's header line carries none), and
writes them again at every OK of the form. To browse everything again,
choose **Any date** / **Any quality** in the form. The expression and the
toggle of the accents are only *written* when the form submits (a plain link
keeps the value that stands).

In the tree each genre group shows the **number of its albums** in
parentheses beside the name.

## The breadcrumb
The walk of the page is shown as a **breadcrumb** above the form —
`LibraryMapper › Jazz › Miles Davis › 1959 - Kind of Blue`. Every step is
**clickable and goes back to its level** (Home, the genre, the artist): each
link carries the path *up to that level alone*, so going back never gets
stuck deeper than the step that was clicked. The step that is in use is in
bold. **Every step carries the order and the filters that are in use as a
tooltip** (`Added: ... | Quality: ... | Order: ... | Items shown: ...`) — go
back to an earlier step, change a filter in the form of that step and OK
re-drills from there with the new choice.

## Album artists
- Spellings are merged into one canonical name (`"miles davis"`, `"Davis, Miles"` → `Miles Davis`).
- A collaboration credited in one string (`"Claude Nougaro & David Lynx"`) is filed under **each** of its artists.
- **Trusted names** (uploaded on the parameter page, one name per line) are always
  one single album artist: the credit is never split and the albums credited to
  them are filed under them alone — no guest, no other collaborator.

## The groups and the guessing
The plugin proposes the broad group of every raw genre tag by **keyword rules**,
the strongest first (the word *blues* alone decides the group, so *blues rock*,
*chicago blues* and *rhythm and blues* all stand in **Blues**). The rules match
whole words of the **normalized** spelling: without accents, without punctuation,
without a word that only says "music" — `"Blues-Rock"` and `"blues rock"` are the
same words.

The albums that carry **no genre** (an empty tag, or a tag that only says
"unknown") get a **derived** group, with the **low-confidence marker `(?)`**
after the year of the album:

| The album | The group it is given | Why |
|---|---|---|
| tagged, a spelling the rules recognize (or the user already filed) | the tag (or the filing) | no guess |
| tagged, a spelling **no rule recognizes** | **Uncategorised**, until the user approves the spelling on the parameter page | `(?)` mode "fallback" |
| no tag, the artist is not Various Artists and has tagged albums | the group most of the artist's albums stand in | `(?)` mode "artist" |
| no tag, a compilation (Various Artists, Sampler...) or an artist without tagged albums | the group of the words of its **title** | `(?)` mode "title" |
| no tag and no clue at all | **Uncategorised** | no marker |

**Uncategorised** is the common virtual fallback for empty or placeholder genre
tags and for tags with no mapped group (its internal key remains `Unsorted`). It
is hidden by default; enable **Show the Uncategorised fallback** on the parameter
page, or press the **Uncategorised** chip of the selbox (see above), to display
it. Both write the same preference. Approving a raw spelling moves its albums
out of the fallback immediately. Albums without an artist credit, genuine
compilations, and the usual VA spellings (`Various`, `VA`, `Sampler`, …) share
the **Various Artists** virtual artist.

A guess never feeds another guess: the pass counts only the **tagged** albums of
an artist whose group is a *real* group (an unapproved spelling counts for none
of it), so two refreshes in a row give the same tree.

**The list of the rules** (parameter page): a single ordered list, one line per
group, `Group : word ; word`. The first line that matches wins. The words are
whole words of the normalized form (several words allowed: `bal musette`; a
word ending with `*` also matches the words that start with it: `classic*`).
The built-in list carries the style families too (`trip hop` Electronic,
`big band` Jazz, `new wave` Rock, `cabaret` and `vocal` Pop, `medieval` and
`klavier*` Classical, `flamenco` and `salsa` Regional Music...), so only
spellings no family recognizes stay in Uncategorised.
A line without words is the **fallback**: it closes the order, every spelling
no line matched lands in its group (by default `Unsorted`, displayed as
**Uncategorised**), and no line
after a fallback line can ever match — the page reports them. A list that
carries its own fallback line is applied **alone** (the built-in lines stay
out); a list without one stays **additive**, the built-in lines follow it.
The empty list is the built-in one again; the page shows it (and the download
serves it) whenever nothing is stored. The list is downloadable
(`plugins/LibraryMapper/genre-rules.txt`) and can be uploaded back (file or
textarea); it travels in the JSON mapping file (`genreRules`), so it carries
over to another server.

## Deploy
The plugin is published as a plugin repository, so Lyrion installs it by
itself: **Settings → Advanced → Plugins**, *Plugin repositories*, add
`https://raw.githubusercontent.com/NSP-0123456/lms-librarymapper/main/extensions.xml`,
then tick **LibraryMapper** and apply. The server downloads the release,
checks its SHA1 and installs it at the next restart. (Copying the folder into
the `Plugins` directory also works, but the repository keeps the version up to
date.)

The first line of the settings page names the version and the date of the
release (`LibraryMapper v0.8.9 · 2026-11-26 10:41`): `t\make_release.ps1`
writes them into `release.txt` beside `install.xml` (local time of the build
machine); without that file the version of `install.xml` stands alone.

The plugin keeps its dedicated SQLite database in the **preferences folder of
the server** (`prefs/LibraryMapper/librarymapper.db`): that folder survives a
restart and is not wiped with the cache. The database is rebuilt by the
initialization phase; the mapping can be exported and imported as JSON.

After the first initialization, the cache refreshes automatically when LMS
finishes a library scan (both the `rescan done` and `library changed` events
are handled). The temporal filters use the `added_time` recorded by LMS for
the album's tracks, not the modification date of their folder.

## Structure
- `install.xml` — plugin descriptor (Lyrion ≥ 7.9)
- `Plugin.pm` — page registration: app page, download endpoint, settings page, browse node
- `Browse.pm` — the native browse mode ("Simplified View"): the drill-down path travels base64url encoded
- `Settings.pm` — parameter page handler (init, repropose, upload, trusted artists)
- `Mapping.pm` — genre rules/propose, the pinned guessing rules, the derivation of the albums without genre, validation, artist resolution, trusted names, export/import JSON mapping files
- `Data.pm` — **dedicated SQLite DB** (schema, initialization scan from Slim::Schema including the genre groups of the albums without genre, the `album_tags` store of every raw spelling, the pairs of the tooltip, `queueStatus` for the queue pane / the status cells / the tree, browse queries)
- `SortKey.pm` — the alphabetical order of the artists and the transliteration (no server dependency, unit tested)
- `Upload.pm` — multipart/form-data parser (Lyrion only parses urlencoded bodies)
- `Strings.pm`, `HTML/EN/...` — labels and templates

## Tests
Run them on any machine with perl, no music server needed:

    pwsh -NoProfile -File t\run_tests.ps1

    perl t\sortkey_check.pl      # the order of the artists, the transliteration
    perl t\strings_check.pl      # the strings file against the Lyrion parser rules
    perl t\compile_check.pl      # every module compiles
    perl t\template_check.pl     # the template of the application page renders
    perl t\album_rows_check.pl   # the second line, the card of tags, the queue status, the OPML items
    perl t\browse_feed_check.pl  # the header at the end of the feed, the walk without choices
    perl t\icon_check.pl         # the genre icons and the uploaded icon pack
