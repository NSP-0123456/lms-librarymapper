package Plugins::LibraryMapper::Plugin;

use strict;
use base qw(Slim::Plugin::OPMLBased);

use Slim::Web::Pages;
use Slim::Web::HTTP;
use Slim::Utils::Log qw(logger logError logWarning);
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(clientString string);
use POSIX qw(strftime);

use Plugins::LibraryMapper::Data;
use Plugins::LibraryMapper::Mapping;

my $log   = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

# The name of the application: it is the name of the command that opens it
# and the name of the entry in the "Apps" section of the skins.
use constant PLUGIN_TAG => 'librarymapper';

$prefs->init({
	quality_default => 'all',
	time_default    => 'all',
	order_default   => 'alpha',
	group_order     => 'alpha',
	listLimit       => 100,
	expr_default    => '',
	translit_default => 0,
	random_default  => 10,
	random_mode     => 'ar',
	artistNameStyle => 'firstlast',
	showUnclassified => 0,
	show_app        => 1,
	embedded_rail   => 0,
	searchKey       => 'name',
});

sub initPlugin {
	my $class = shift;

	# Every part of the plugin is guarded: a plugin error must never keep the
	# music server from starting.  Each step logs its own failure.
	eval {
		Plugins::LibraryMapper::Data::init();
		1;
	} or do { logError("LibraryMapper: database init failed: $@"); };

	# Main application page ("virtual browse")
	eval {
		Slim::Web::Pages->addPageFunction(
			"plugins/LibraryMapper/index\.(?:htm|ml)?",
			\&pageApp
		);

		# Download endpoint: mapping file as JSON
		Slim::Web::Pages->addPageFunction(
			"plugins/LibraryMapper/download\.(?:htm|json)?",
			\&pageDownload
		);

		# Download endpoint: the mapping as an editable plain text list.
		# The name does not start with "download" so that it cannot match
		# the JSON endpoint above.
		Slim::Web::Pages->addPageFunction(
			"plugins/LibraryMapper/mapping-list\.(?:txt|list)?",
			\&pageDownloadList
		);

		# The progress of the background scan: the parameter page reads it
		# and shows the bar, the way the server information page does.
		Slim::Web::Pages->addPageFunction(
			"plugins/LibraryMapper/progress\.(?:json)?",
			\&pageProgress
		);

		# The numbers of the parameter page: when a scan has finished, the
		# script of the page asks for these in the place of a reload of the
		# whole page (the page would flicker, and every list would be built
		# again for nothing).
		Slim::Web::Pages->addPageFunction(
			"plugins/LibraryMapper/status\.(?:json)?",
			\&pageStatusJson
		);

		# The icons the user uploaded on the parameter page: they do not live
		# in the HTML folder of the plugin (which is rewritten at every update
		# of the plugin) but in the icon folder beside the database, so a page
		# hands them out one by one ("icon.png?name=<genre group>").
		Slim::Web::Pages->addPageFunction(
			"plugins/LibraryMapper/icon\.(?:png|gif|ico|htm|html)?",
			\&pageIcon
		);

		# The 🎲 link: append a few random albums to the playlist (with the
		# filters the page shows), then render the browse page again.
		Slim::Web::Pages->addPageFunction(
			"plugins/LibraryMapper/random-add\.(?:htm|ml)?",
			\&pageRandomAdd
		);

		# The queue of the player: the pane of the page asks for it (the rows
		# of the playlist, the track in play, the mode of the player).
		Slim::Web::Pages->addPageFunction(
			"plugins/LibraryMapper/queue\.(?:json)?",
			\&pageQueue
		);

		# The transport of the pane: stop, play, pause, continue, clear, and
		# the jump of a row (the key "jump" of a row plays the track now).
		Slim::Web::Pages->addPageFunction(
			"plugins/LibraryMapper/player\.(?:json)?",
			\&pagePlayer
		);
		1;
	} or do { logError("LibraryMapper: page registration failed: $@"); };

	# Settings page (parameter page: init + validation + upload mapping)
	eval {
		require Plugins::LibraryMapper::Settings;
		Plugins::LibraryMapper::Settings->new();
		1;
	} or do { logError("LibraryMapper: settings page failed: $@"); };

	# --- native browse mode: "Simplified View" inside My Music --------------
	eval {
		require Plugins::LibraryMapper::Browse;
		require Slim::Menu::BrowseLibrary;

		# the drill-down path travels in "lm_path": make it a top level argument
		# so that it survives the Lyrion browse parameter handling
		push @Slim::Menu::BrowseLibrary::topLevelArgs, 'lm_path'
			unless grep { $_ eq 'lm_path' } @Slim::Menu::BrowseLibrary::topLevelArgs;

		# The tree is offered once, in My Music.  The order of the albums and
		# the filters are chosen in the header of the tree itself (the first
		# line opens the page of the plugin).
		my $node = {
			id    => 'myMusicLibraryMapper',
			name  => 'PLUGIN_LIBRARYMAPPER_VIEW',
		};
		my %params = ( mode => 'librarymapper' );
		Slim::Menu::BrowseLibrary->registerNode({
			id           => $node->{'id'},
			type         => 'link',
			name         => $node->{'name'},
			params       => \%params,
			feed         => \&Plugins::LibraryMapper::Browse::feed,
			icon         => 'html/images/genres.png',
			jiveIcon     => 'html/images/genres.png',
			homeMenuText => $node->{'name'},
			condition    => \&Slim::Menu::BrowseLibrary::isEnabledNode,
			weight       => 28,   # just before the genres (30)
			cache        => 1,
		});
		1;
	} or do { logError("LibraryMapper: browse node registration failed: $@"); };

	# classic skins: My Music entry pointing at the standard LMS browse page
	eval {
		Slim::Web::Pages->addPageLinks('browse', {
			'PLUGIN_LIBRARYMAPPER_VIEW' =>
				'clixmlbrowser/clicmd=browselibrary+items&linktitle=PLUGIN_LIBRARYMAPPER_VIEW&mode=librarymapper/',
		});
		1;
	} or do { logError("LibraryMapper: home page link failed: $@"); };

	# --- the library changed: a file was added or removed --------------------
	# The server sends this event after every scan of the library.  The tree of
	# the plugin is brought up to date in the background: the music server
	# keeps answering while it works.
	eval {
		require Slim::Control::Request;
		Slim::Control::Request::subscribe(\&_libraryChanged, [['library'],['changed']]);
		1;
	} or do { logError("LibraryMapper: the library-changed subscription failed: $@"); };

	# CLI helpers (used for scripted initialization and diagnostics)
	eval {
		require Slim::Control::Request;
		Slim::Control::Request::addDispatch(
			[ 'librarymapper', 'init' ],   [ 0, 1, 1, \&cmdInit ] );
		Slim::Control::Request::addDispatch(
			[ 'librarymapper', 'status' ], [ 0, 1, 1, \&cmdStatus ] );
		Slim::Control::Request::addDispatch(
			[ 'librarymapper', 'browse' ], [ 0, 1, 1, \&cmdBrowse ] );
		Slim::Control::Request::addDispatch(
			[ 'librarymapper', 'query' ],  [ 0, 1, 1, \&cmdQuery ] );
		Slim::Control::Request::addDispatch(
			[ 'librarymapper', 'map' ],    [ 0, 1, 1, \&cmdMap ] );
		Slim::Control::Request::addDispatch(
			[ 'librarymapper', 'refresh' ], [ 0, 1, 1, \&cmdRefresh ] );
		Slim::Control::Request::addDispatch(
			[ 'librarymapper', 'randomadd' ], [ 0, 1, 1, \&cmdRandomAdd ] );
		1;
	} or do { logError("LibraryMapper: CLI dispatch failed: $@"); };

	# --- the application itself ------------------------------------------------
	# The plugin is an OPML application: it is listed in the "Apps" section of
	# the web interface and of the Material skin, and it opens there.
	eval {
		require Plugins::LibraryMapper::Browse;
		require Slim::Control::Request;

		$class->SUPER::initPlugin(
			feed   => \&Plugins::LibraryMapper::Browse::feed,
			tag    => PLUGIN_TAG,
			is_app => 1,
			weight => 10,
		);

		# The contents of the application must open even when no player is
		# connected to the server.  The standard dispatch of an OPML
		# application asks for a client, this one does not.
		Slim::Control::Request::addDispatch(
			[ PLUGIN_TAG, 'items', '_index', '_quantity' ],
			[ 0, 1, 1, \&cmdAppItems ] );
		1;
	} or do { logError("LibraryMapper: the application registration failed: $@"); };

	$log->info("LibraryMapper initialized");
}

# --------------------------------------------- the mode of the 🎲 button
# The five prefixes of the random button (ar, a_, ft, fa, rr).  A value of
# the request that is none of them is not one: the choice falls back to the
# preference of the parameter page, then to drawing whole albums (the
# behaviour the button always had).
my %RANDOM_MODES = map { $_ => 1 } qw(ar a_ ft fa rr);

sub _randomMode {
	my ($value) = @_;
	return $value    if defined $value && $RANDOM_MODES{$value};
	my $pref = $prefs->get('random_mode') || '';
	return $pref     if $RANDOM_MODES{$pref};
	return 'ar';
}

# ----------------------------------------------- visibility of the Apps entry
# The "Apps" list of the server (the menu of My Apps on players, the
# application tile of the web interface) asks this of every application at
# the very moment the list is built: the box of the settings page acts at
# once, the server does not have to be restarted.  The one of "My Music"
# (the Simplified View) stays in place all the time.
sub condition {
	my $client = shift;
	my $on = eval { $prefs->get('show_app') } || 0;
	return $on ? 1 : 0;
}

# ------------------------------------------------------- the application menu

# The items of the application.  They are the levels of the virtual tree, the
# same ones that "My Music > Simplified View" shows, so that the application
# and the tree of the library always look the same.
sub cmdAppItems {
	my $request = shift;

	my $index    = $request->getParam('_index')   || 0;
	my $quantity = $request->getParam('_quantity') || 100;

	# The state of the tree (the path, the order, the filters and the number
	# of items) travels with the request of the application: the parameters
	# of the item that was picked are handed over to the browse library.
	my @tags = ( 'mode:librarymapper', 'menu:browselibrary' );
	for my $name (qw(lm_path lm_order lm_group_order lm_time lm_quality lm_limit lm_expr lm_ft search)) {
		my $value = $request->getParam($name);
		next unless defined $value && $value ne '';
		push @tags, "$name:$value";
	}

	# The tree is the tree of the browse library in the mode "librarymapper":
	# it is asked for here and its items are handed over as they are.
	my $req = Slim::Control::Request::executeRequest(undef,
		[ 'browselibrary', 'items', $index, $quantity, @tags ]);

	my $items = $req->getResult('item_loop') || [];

	my $i = 0;
	for my $item (@$items) {
		# "input" is the text input window of a "search" item, "nextWindow"
		# the window the client opens after a pick; without their copy the
		# app would lose both.  The tree carries no such item today, the
		# copy stays for the callers that could send one.
		for my $key (qw(text type icon actions commonParams addAction input nextWindow)) {
			next unless exists $item->{$key};
			$request->addResultLoop('item_loop', $i, $key, $item->{$key});
		}
		$i++;
	}

	$request->addResult('count', scalar @$items);
	$request->setStatusDone();
}

# ---------------------------------------------------------------- app page

sub pageApp {
	my ($client, $params, $cb, $httpClient, $response) = @_;

	$log->debug("pageApp requested: parent=" . ($params->{'parent'} // ''));

	my $time  = $params->{'time'}    || $prefs->get('time_default');
	my $qualt = $params->{'quality'} || $prefs->get('quality_default');
	my $order = $params->{'order'}   || $prefs->get('order_default');
	my $group = $params->{'group'}   || $prefs->get('group_order') || 'alpha';
	# The number of items of a level: "default" means that the preference of
	# the plugin decides (Data::_limitOf falls back to it).
	my $list  = $params->{'list'} || 'default';
	my $filter = $params->{'filter'} || '';

	# The expression of the walk: a free text the user types on the page.
	# Like the other choices it falls back to the preference when the
	# request carries nothing — the page and the tree now share one source
	# of truth (the URL of the page row of the choices carries no choice any
	# more).  It is remembered, still, only when the request carries it at
	# all: a plain form submit writes the box, a link without it keeps the
	# value that stands.
	my $expr = defined $params->{'expr'} ? $params->{'expr'}
	         : ($prefs->get('expr_default') || '');
	$expr =~ s/\s+$//;
	$expr =~ s/^\s+//;
	my $ft = exists $params->{'ft'} ? ($params->{'ft'} ? 1 : 0)
	       : ($prefs->get('translit_default') ? 1 : 0);

	# The number of the albums of the 🎲 link: a choice of the form (5, 10,
	# 20, 50, 100), remembered like the other choices, but only registered
	# when the request carries it at all — a link without it keeps the
	# preference of the parameter page.
	if (exists $params->{'rnd'} && $params->{'rnd'} =~ /^\d+$/
			&& $params->{'rnd'} >= 1 && $params->{'rnd'} <= 100) {
		if (($prefs->get('random_default') || 10) != $params->{'rnd'} + 0) {
			$prefs->set('random_default', $params->{'rnd'} + 0);
		}
	}
	my $rnd = $params->{'rnd'};
	if ($rnd !~ /^\d+$/ || $rnd < 1 || $rnd > 100) {
		$rnd = $prefs->get('random_default') || 10;
	}
	$rnd += 0;

	# The choices of the page are remembered in the preferences of the
	# plugin — the same ones the tree reads when its request carries
	# nothing: opened again (the button "Back" of the skin comes back to
	# the page it was opened with), the page shows them, the tree carries
	# them.  Reset = choose "Any ..." in the form.  A value of the request
	# that is not a known choice is not remembered.
	my %known = map { $_ => 1 } qw(all day week month year);
	if ($params->{'time'} && $known{ $params->{'time'} }
			&& ($prefs->get('time_default') || '') ne $params->{'time'}) {
		$prefs->set('time_default', $params->{'time'});
	}
	%known = map { $_ => 1 } qw(all hires cd lossy dsd unknown);
	if ($params->{'quality'} && $known{ $params->{'quality'} }
			&& ($prefs->get('quality_default') || '') ne $params->{'quality'}) {
		$prefs->set('quality_default', $params->{'quality'});
	}
	%known = map { $_ => 1 } qw(alpha newer older added count countasc longest shortest);
	if ($params->{'order'} && $known{ $params->{'order'} }
			&& ($prefs->get('order_default') || '') ne $params->{'order'}) {
		$prefs->set('order_default', $params->{'order'});
	}
	%known = map { $_ => 1 } qw(alpha count countasc);
	if ($params->{'group'} && $known{ $params->{'group'} }
			&& ($prefs->get('group_order') || '') ne $params->{'group'}) {
		$prefs->set('group_order', $params->{'group'});
	}
	%known = map { $_ => 1 } qw(10 100 1000 unlimited);
	if ($params->{'list'} && $known{ $params->{'list'} }
			&& ($prefs->get('listLimit') // '') ne $params->{'list'}) {
		$prefs->set('listLimit', $params->{'list'} eq 'unlimited' ? 'unlimited' : $params->{'list'} + 0);
	}

	# The prefix of the 🎲 button: a choice of the form like the number,
	# registered when the request carries it at all (the link of the button
	# carries it, a plain render of the page keeps the value that stands).
	if (my $mode = $params->{'lm_mode'}) {
		if ($RANDOM_MODES{$mode} && ($prefs->get('random_mode') || 'ar') ne $mode) {
			$prefs->set('random_mode', $mode);
		}
	}
	my $mode = _randomMode($params->{'lm_mode'});

	# The expression only travels with a form submit (a GET with "expr" in
	# it): the empty text is remembered as "no expression", so that the box
	# "Reset = choose Any" rule of the choice lists holds for it too.
	if (exists $params->{'expr'} && ($prefs->get('expr_default') || '') ne $expr) {
		$prefs->set('expr_default', $expr);
	}
	if (exists $params->{'expr'} && ($prefs->get('translit_default') || 0) ne $ft) {
		$prefs->set('translit_default', $ft);
	}

	my $view = Plugins::LibraryMapper::Data::browse(
		parent     => $params->{'parent'},     # e.g. "Blues|John Mayall|1970 - Empty Rooms" drill path
		time       => $time,
		quality    => $qualt,
		order      => $order,                  # alpha | newer | older | added | count | countasc | longest | shortest
		groupOrder => $group,                  # alpha | count | countasc (order of the groups)
		list       => $list,                   # max items shown per list step
		filter     => $filter,                 # regular expression on the artists
		expr       => $expr,                   # the filter/sort expression of the walk
		filterTranslit => $ft,                 # the name filter ignores the accents
	);

	# The name of the quality class of every row, in the language of the
	# client: the rows of the albums and of the tracks carry the class
	# itself (hires, cd, lossy, dsd, unknown).
	for my $row (@{ $view->{'rows'} || [] }) {
		next unless defined $row->{'quality'};
		$row->{'qualityLabel'} = _qualityText($client, $row->{'quality'});
	}

	# The top level is the level of the genre groups: every group carries its
	# icon (an instrument of the icons8 pack, recoloured).  The path is
	# absolute: the page lives in the iframe of the skin, the image is served
	# beside it at /plugins/LibraryMapper/html/images/genre/.  When the user
	# has uploaded an icon for the group on the parameter page, that icon is
	# served in its place, by the icon endpoint.
	if (($view->{'type'} || '') eq 'level' && !($params->{'parent'} // '')) {
		for my $row (@{ $view->{'rows'} || [] }) {
			my $raw = $row->{'unclassified'} ? '' : $row->{'key'};
			if (Plugins::LibraryMapper::Data::customIconFile($raw)) {
				$row->{'icon'} = '/plugins/LibraryMapper/icon.png?name=' . _urlenc($raw);
			}
			else {
				$row->{'icon'} = '/plugins/LibraryMapper/html/images/genre/'
					. Plugins::LibraryMapper::Data::genreIconFile($raw)
					. '.png';
			}
		}
	}

	$params->{'view'}        = $view;
	$params->{'parentFilter'} = $params->{'parent'} || '';
	$params->{'time'}    = $time;
	$params->{'quality'} = $qualt;
	$params->{'order'}   = $order;
	$params->{'rnd'}     = $rnd;           # the count of the 🎲 link
	$params->{'mode'}    = $mode;          # the prefix of the 🎲 link
	$params->{'group'}   = $group;
	$params->{'list'}    = $list;
	$params->{'filter'}  = $filter;
	$params->{'expr'}    = $expr;
	$params->{'ft'}      = $ft;

	return Slim::Web::HTTP::filltemplatefile('plugins/LibraryMapper/index.html', $params);
}

# ------------------------------------------------------------ icon endpoint
# One icon of the user's pack, served from the icon folder beside the
# database ("icon.png?name=<genre group>"; the name arrives url encoded).
# When the group has no uploaded icon, the shipped drawing is served in its
# place, so that the answer is always a valid image.
sub pageIcon {
	my ($client, $params, $cb, $httpClient, $response) = @_;

	my $icon = Plugins::LibraryMapper::Data::iconBytes($params->{'name'} || '');

	if ($response) {
		$response->content_type($icon->{'type'});
	}
	return \ $icon->{'data'};
}

# percent-encoding of a genre group name in the URL of its icon (the group
# names are UTF-8 bytes out of the database: they are encoded as they are)
sub _urlenc {
	my $s = shift || '';
	$s =~ s/([^a-zA-Z0-9_.\-~])/sprintf('%%%02X', ord($1))/ge;
	return $s;
}

# The name of a quality class, in the language of the client.
my %QUALITY_TOKEN = (
	hires   => 'PLUGIN_LIBRARYMAPPER_Q_HIRES',
	cd      => 'PLUGIN_LIBRARYMAPPER_Q_CD',
	lossy   => 'PLUGIN_LIBRARYMAPPER_Q_LOSSY',
	dsd     => 'PLUGIN_LIBRARYMAPPER_Q_DSD',
	unknown => 'PLUGIN_LIBRARYMAPPER_Q_UNKNOWN',
);
sub _qualityText {
	my ($client, $class) = @_;
	my $token = $QUALITY_TOKEN{$class} || 'PLUGIN_LIBRARYMAPPER_Q_UNKNOWN';
	my $text = '';
	if ($client) {
		eval { $text = clientString($client, $token) || ''; };
	}
	$text = '' unless defined $text && $text ne '';
	if ($text eq '') {
		eval { $text = string($token) || ''; };
	}
	return $text || $token;
}

# ------------------------------------------------------------ settings page

sub pageSettings {
	my ($client, $params) = @_;
	require Plugins::LibraryMapper::Settings;
	Plugins::LibraryMapper::Settings::handler($client, $params);
}

# ---------------------------------------------------------- progress of the scan
# The parameter page asks for this while the background scan works.  The
# answer is a small JSON object: the state, the step and the percentage.
sub pageProgress {
	my ($client, $params, $cb, $httpClient, $response) = @_;

	my $scan = Plugins::LibraryMapper::Data::scanStatus();

	# the step is a token of a string of the plugin: it is translated here
	my $stepText = '';
	if ($scan->{'step'} && $scan->{'step'} =~ /^PLUGIN_/) {
		$stepText = eval {
			require Slim::Utils::Strings;
			Slim::Utils::Strings::string($scan->{'step'});
		} || $scan->{'step'};
	}

	# the state has a name too
	my %stateToken = (
		running => 'PLUGIN_LIBRARYMAPPER_S_SCANNING',
		done    => 'PLUGIN_LIBRARYMAPPER_S_SCAN_DONE',
		error   => 'PLUGIN_LIBRARYMAPPER_S_SCAN_FAILED',
		none    => 'PLUGIN_LIBRARYMAPPER_S_NOTRUN',
	);
	my $stateText = '';
	if (my $token = $stateToken{ $scan->{'state'} || 'none' }) {
		$stateText = eval {
			require Slim::Utils::Strings;
			Slim::Utils::Strings::string($token);
		} || $token;
	}

	my $json = Plugins::LibraryMapper::Data::to_json({
		state     => ($scan->{'state'}    || 'none'),
		stateText => $stateText,
		step      => ($scan->{'step'}     || ''),
		stepText  => $stepText,
		progress  => ($scan->{'progress'} || 0),
		started   => ($scan->{'started'}  || 0),
		finished  => ($scan->{'finished'} || 0),
		error     => ($scan->{'error'}    || ''),
		pending   => ($scan->{'pending'}  || 0),
	});

	if ($response) {
		$response->content_type('application/json');
	}

	return \$json;
}

# ------------------------------------------------ the numbers of the settings
# The small figures of the ledger of the parameter page (albums, resolved
# albums, artist and genre variants, trusted artists, mapped variants) in
# one JSON object.  The script of the page asks for them when a scan has
# finished, in the place of a reload of the whole page: a reload re-rendered
# every list of the page and made it flicker.
sub pageStatusJson {
	my ($client, $params, $cb, $httpClient, $response) = @_;

	my $status = Plugins::LibraryMapper::Data::status();

	if ($response) {
		$response->content_type('application/json');
	}

	my $json = Plugins::LibraryMapper::Data::to_json($status);

	return \$json;
}

# ------------------------------------------------------- random albums page
# The 🎲 link of the page: pick a few albums (with the time and the quality
# filters, and the expression, that the page shows) and append them to the
# playlist of the player the page is opened for.  The page then renders as
# the browse page with a line of confirmation.
sub pageRandomAdd {
	my ($client, $params, $cb, $httpClient, $response) = @_;

	my $n = ($params->{'n'} || $prefs->get('random_default') || 10) + 0;
	$n = 100 if $n > 100;
	$n = 10  if $n < 1;

	# The prefix of the button: what an album contributes (whole albums,
	# the first track of each, one random track of each) and in which order
	# the albums are picked (at random, or the current order of the page).
	my $mode = _randomMode($params->{'lm_mode'});

	my $pick = Plugins::LibraryMapper::Data::randomPick(
		n        => $n,
		mode     => $mode,
		time     => $params->{'time'}    || $prefs->get('time_default')    || 'all',
		quality  => $params->{'quality'} || $prefs->get('quality_default') || 'all',
		order    => $params->{'order'}   || $prefs->get('order_default')   || 'alpha',
		expr     => $params->{'expr'}    || '',
	);

	my $added = 0;
	if ($client) {
		my $kind = $pick->{'kind'} || 'album';
		for my $id (@{ $pick->{'ids'} || [] }) {
			my $req = eval {
				Slim::Control::Request::executeRequest($client, [
					'playlistcontrol', 'cmd:add',
					($kind eq 'track' ? 'track_id:' : 'album_id:') . $id ]);
				1;
			};
			$added++ if $req;
		}
	}
	$params->{'randomAdded'} = $added;

	return pageApp($client, $params, $cb, $httpClient, $response);
}

# ---------------------------------------------------- the queue of the player
# The pane of the page asks for this while it is open: the rows of the
# playlist of the player, the track in play and the mode.  The answer is a
# small JSON object; the class of quality of every track comes from the
# database of the plugin (the server hands no such column out).  A page
# without player (a headless server) answers an empty list.
sub pageQueue {
	my ($client, $params, $cb, $httpClient, $response) = @_;

	my %out = (
		player   => '', playerId => '', mode => '',
		count    => 0,  total    => 0, current => -1,
		tracks   => [],
	);

	if ($client) {
		eval {
			my $req = Slim::Control::Request::executeRequest(
				$client, [ 'status', '0', '1000', 'tags:gda' ]);
			# the result of the status query IS the hash itself (mode,
			# playlist_tracks, playlist_loop are top level keys — there is
			# no 'data' key inside it)
			my $data = ($req && eval { $req->getResults() }) || {};

			$out{'player'}   = eval { $client->name() } || '';
			$out{'playerId'} = eval { $client->id()   } || '';
			$out{'mode'}     = $data->{'mode'} || '';
			$out{'current'}  = defined $data->{'playlist_cur_index'}
					? $data->{'playlist_cur_index'} + 0 : -1;
			$out{'count'}    = ($data->{'playlist_tracks'} || 0) + 0;

			my (@rows, @ids);
			for my $t (@{ $data->{'playlist_loop'} || [] }) {
				next unless defined $t->{'id'};
				my $dur = $t->{'duration'};
				$dur = ($dur =~ /\A\S*\d\S*\z/) ? $dur + 0 : 0;
				push @rows, {
					index    => defined $t->{'playlist index'}
							? $t->{'playlist index'} + 0 : scalar @rows,
					id       => $t->{'id'} + 0,
					title    => $t->{'title'} || '',
					artist   => $t->{'artist'} || '',
					duration => $dur,
					quality  => 'unknown',
				};
				push @ids, $t->{'id'};
			}

			# the class of the encoding: the cache of the plugin knows it
			my $qual = Plugins::LibraryMapper::Data::trackQuality(\@ids);
			for my $r (@rows) {
				$r->{'quality'} = $qual->{ $r->{'id'} } || 'unknown';
				$out{'total'} += $r->{'duration'};
			}
			$out{'tracks'} = \@rows;
			1;
		} or do { logError("LibraryMapper: the read of the queue failed: $@"); };
	}

	if ($response) {
		$response->content_type('application/json');
	}

	my $json = Plugins::LibraryMapper::Data::to_json(\%out);
	return \$json;
}

# ------------------------------------------------- the transport of the queue
# The keys of the pane: stop, play, pause, continue, clear and the jump of a
# row.  Every key is one command of the player, never more (the pane does not
# change the order of the queue: the jump keeps it).
sub pagePlayer {
	my ($client, $params, $cb, $httpClient, $response) = @_;

	my %out = ( ok => 0, cmd => ($params->{'cmd'} || '') );
	my %cmdOf = (
		stop   => [ 'mode', 'stop' ],
		play   => [ 'mode', 'play' ],
		pause  => [ 'pause', '1' ],
		resume => [ 'pause', '0' ],
		# the [Vider] key: the clean of the queue lives in the family of the
		# "playlist" commands — "playlistcontrol" only accepts load, insert,
		# add and delete (an unknown cmd ends in setStatusBadParams, and the
		# request comes back without having done anything, without an error)
		clear  => [ 'playlist', 'clear' ],
	);

	if ($client) {
		eval {
			my $cmd = $out{'cmd'};
			if ($cmd eq 'jump') {
				my $i = ($params->{'index'} || 0) + 0;
				$i = 0 if $i < 0;
				Slim::Control::Request::executeRequest(
					$client, [ 'playlist', 'jump', $i ]);
			}
			elsif ($cmd eq 'playnow' || $cmd eq 'next' || $cmd eq 'append') {
				# the keys of the rows of the tree: play an item now (it
				# replaces the queue and plays it), slide it in after the
				# track in play (insert), or append it at the end (add).
				# The item is identified by its id in the library of the
				# server — a track, or a whole album.
				my $id   = ($params->{'id'}   || 0) + 0;
				my $kind = ($params->{'kind'} || '') eq 'album' ? 'album_id' : 'track_id';
				if ($id > 0) {
					my @cmd = ('playlistcontrol',
						'cmd:' . ($cmd eq 'playnow' ? 'load'
							: $cmd eq 'next' ? 'insert' : 'add'),
						"$kind:$id");
					# the load plays from the first track only when the
					# queue answers with an index to jump to
					push @cmd, 'play_index:0' if $cmd eq 'playnow';
					Slim::Control::Request::executeRequest($client, \@cmd);
				}
			}
			elsif ($cmdOf{$cmd}) {
				Slim::Control::Request::executeRequest($client, $cmdOf{$cmd});
			}
			$out{'ok'} = 1;
			1;
		} or do {
			logError("LibraryMapper: the command of the player failed: $@");
			$out{'ok'} = 0;
		};
	}

	if ($response) {
		$response->content_type('application/json');
	}

	my $json = Plugins::LibraryMapper::Data::to_json(\%out);
	return \$json;
}

# The library changed: the tree is updated in the background.
sub _libraryChanged {
	my ($client) = @_;
	eval {
		Plugins::LibraryMapper::Data::libraryChanged();
		1;
	} or do { logError("LibraryMapper: the update of the tree failed: $@"); };
}

# ------------------------------------------------------------- download API

sub pageDownload {
	my ($client, $params, $cb, $httpClient, $response) = @_;

	$log->debug("pageDownload requested");

	my $json = Plugins::LibraryMapper::Mapping::exportMapping()
		|| '{"error": "no mapping exists yet"}';

	if ($response) {
		$response->content_type('application/json');
		# the browser saves the file instead of showing it
		my $name = 'librarymapper-' . strftime('%Y-%m-%d', localtime()) . '.json';
		$response->header('Content-Disposition' => "attachment; filename=\"$name\"");
	}

	return \$json;
}

# The mapping as an editable plain text list: this is the file the user
# edits and pastes back into the parameter page.
sub pageDownloadList {
	my ($client, $params, $cb, $httpClient, $response) = @_;

	$log->debug("pageDownloadList requested");

	my $text = Plugins::LibraryMapper::Mapping::exportList();

	if ($response) {
		$response->content_type('text/plain; charset=utf-8');
		my $name = 'librarymapper-mapping-' . strftime('%Y-%m-%d', localtime()) . '.txt';
		$response->header('Content-Disposition' => "attachment; filename=\"$name\"");
	}

	return \$text;
}

# ------------------------------------------------------------------- CLI
# The scan runs in the background: the command answers at once.  The state of
# the scan is read back with "librarymapper status".
sub cmdInit {
	my $request = shift;
	my $started = Plugins::LibraryMapper::Data::startScan();
	$request->addResult('ok',      $started ? 1 : 0);
	$request->addResult('started', $started ? 1 : 0);
	$request->addResult('state',   Plugins::LibraryMapper::Data::scanStatus()->{'state'});
	$request->setStatusDone();
}

sub cmdStatus {
	my $request = shift;
	my $status = Plugins::LibraryMapper::Data::status();
	for my $k (keys %$status) {
		$request->addResult($k, $status->{$k});
	}
	$request->setStatusDone();
}

sub cmdBrowse {
	my $request = shift;
	my $path = $request->getParam('path') || '';
	my $view = Plugins::LibraryMapper::Data::browse(
		parent     => $path,
		time       => $request->getParam('time')    || $prefs->get('time_default'),
		quality    => $request->getParam('quality') || $prefs->get('quality_default'),
		order      => $request->getParam('order')   || $prefs->get('order_default'),
		groupOrder => $request->getParam('group')   || $prefs->get('group_order') || 'alpha',
		list       => $request->getParam('list')    || $prefs->get('listLimit'),
		filter     => $request->getParam('filter')  || '',
		expr       => $request->getParam('expr')    || $prefs->get('expr_default') || '',
		filterTranslit => ($request->getParam('ft') ne '' ? ($request->getParam('ft') ? 1 : 0)
		                   : ($prefs->get('translit_default') ? 1 : 0)),
	);
	$request->addResult('type',  $view->{'type'});
	# The pseudo entries keep their raw keys in the view ("*" = All artists,
	# "%%" = All albums, "@@" = Random): the title that leaves the JSON has
	# to be a plain name, it is what a skin shows for the level, never a key.
	my $title = $view->{'title'} || '';
	if    ($title eq '*')  { $title = string('PLUGIN_LIBRARYMAPPER_ALL_ARTISTS'); }
	elsif ($title eq '%%') { $title = string('PLUGIN_LIBRARYMAPPER_ALL_ALBUMS'); }
	elsif ($title eq '@@') { $title = string('PLUGIN_LIBRARYMAPPER_RANDOM'); }
	$request->addResult('title', $title);
	$request->addResult('count', scalar @{ $view->{'rows'} });
	if ($view->{'filter'}) {
		$request->addResult('filter', $view->{'filter'});
	}
	if ($view->{'filterError'}) {
		$request->addResult('filterError', 1);
	}
	my $i = 0;
	for my $row (@{ $view->{'rows'} }) {
		$request->addResultLoop('rows_loop', $i, 'json', Plugins::LibraryMapper::Data::to_json($row));
		$i++;
	}
	$request->setStatusDone();
}

# Regex search over the artists, composers and conductors.
#   librarymapper query pattern=^Miles role=1
# The result is numbered: the number is the reference used by "map".
sub cmdQuery {
	my $request = shift;
	my $pattern = $request->getParam('pattern') || '';
	my $role    = $request->getParam('role')    || 'all';
	my $key     = $request->getParam('key')     || 'name';
	# the target of the match: the name as written, or its sort key
	$key = ($key =~ /^sortkey$/i) ? 'sortkey' : 'name';
	my $res = Plugins::LibraryMapper::Data::queryContributors($pattern, $role,
		{ searchKey => $key });
	if ($res->{'error'}) {
		$request->addResult('error', $res->{'error'});
		$request->setStatusDone();
		return;
	}
	$request->addResult('count',   scalar @{ $res->{'rows'} });
	$request->addResult('pattern', $res->{'pattern'});
	$request->addResult('key',     $res->{'key'});
	my $i = 0;
	for my $row (@{ $res->{'rows'} }) {
		$request->addResultLoop('rows_loop', $i, 'json',
			Plugins::LibraryMapper::Data::to_json($row));
		$i++;
	}
	$request->setStatusDone();
}

# Apply a mapping to one row of the last query result.
#   librarymapper map nr=12 canonical="Miles Davis"
# The "canonical" value may also be the number of another row: it then means
# the name of that row.
sub cmdMap {
	my $request = shift;
	my $nr       = $request->getParam('nr');
	my $canonical = $request->getParam('canonical');
	$canonical = '' unless defined $canonical;
	my $ok = Plugins::LibraryMapper::Data::setContributorMapping($nr, $canonical);
	$request->addResult('ok',   $ok);
	$request->addResult('name', Plugins::LibraryMapper::Data::queryResultName($nr));
	$request->addResult('canonical', $canonical);
	$request->setStatusDone();
}

# Apply the mapping that is in the database now to the tree.  The change is
# visible at once: the server does not have to be restarted.
sub cmdRefresh {
	my $request = shift;
	my $n = Plugins::LibraryMapper::Data::refreshTree();
	$request->addResult('albums', $n);
	$request->setStatusDone();
}

# Append a few albums to the playlist of the player of the request, in the
# prefix the request carries (ar, a_, ft, fa, rr — see randomPick):
#   librarymapper randomadd n:10 lm_mode:ft time:all quality:all
sub cmdRandomAdd {
	my $request = shift;
	my $n = ($request->getParam('n') || $prefs->get('random_default') || 10) + 0;
	$n = 100 if $n > 100;
	$n = 10  if $n < 1;
	my $mode = _randomMode($request->getParam('lm_mode'));

	my $client = $request->client();
	unless ($client) {
		$request->addResult('error', 'no player in the request');
		$request->addResult('added', 0);
		$request->setStatusDone();
		return;
	}

	my $pick = Plugins::LibraryMapper::Data::randomPick(
		n      => $n,
		mode   => $mode,
		time   => $request->getParam('time')     || $prefs->get('time_default')    || 'all',
		quality => $request->getParam('quality') || $prefs->get('quality_default') || 'all',
		order  => $request->getParam('order')    || $prefs->get('order_default')   || 'alpha',
		expr   => $request->getParam('expr')     || '',
	);

	my $added = 0;
	if ($client) {
		my $kind = $pick->{'kind'} || 'album';
		for my $id (@{ $pick->{'ids'} || [] }) {
			my $req = eval {
				Slim::Control::Request::executeRequest($client, [
					'playlistcontrol', 'cmd:add',
					($kind eq 'track' ? 'track_id:' : 'album_id:') . $id ]);
				1;
			};
			$added++ if $req;
		}
	}

	$request->addResult('added', $added);
	$request->setStatusDone();
}

1;

__END__

=head1 LibraryMapper

LMS server plugin presenting a categories/query application over the indexed
library. Query-only: it never performs file operations. All logic is Perl so
the plugin is shareable without external tooling.

=over

=item My Music > Simplified View - native browse mode (Genre\Artist\Year-Album)

=item /plugins/LibraryMapper/index.html   - virtual browse (Genre\Artist\Year-Album)

=item /plugins/LibraryMapper/settings/basic.html - parameter page (init, validation, uploads)

=item /plugins/LibraryMapper/download.json - export mapping file

=back

=cut
