package Plugins::LibraryMapper::Browse;

use strict;

use MIME::Base64 ();

use Slim::Utils::Log qw(logger logError);
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(clientString string);

use Plugins::LibraryMapper::Data;

my $log   = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

use constant MODE => 'librarymapper';

# The virtual browse tree is exposed as a native LMS browse mode so that it
# shows up in "My Music" of every skin (Material Skin included) and can be
# walked with the standard LMS drill-down machinery.
#
# The drill-down path ("Genre|Artist|Year - Album") is carried in the
# "lm_path" parameter.  It is transported base64url encoded so that album
# titles containing spaces, commas, ampersands or colons survive every
# transport (CLI parameter lists, web query strings, JSON): a plain "|" in a
# request parameter would be read by Lyrion as a search tag.

sub feed {
	my ($client, $callback, $args, $pt) = @_;

	my $path = _path($args, $pt);

	# The order, the filters and the order of the groups travel with the
	# request: the node of "My Music" that the user picked carries them and
	# every item repeats them, so that the drill-down keeps them.
	my $order      = _param($args, 'lm_order')        || _param($args, 'order')
	                || $prefs->get('order_default')   || 'alpha';
	my $groupOrder = _param($args, 'lm_group_order') || $prefs->get('group_order')
	                || 'alpha';
	my $time       = _param($args, 'lm_time')        || $prefs->get('time_default')
	                || 'all';
	my $quality    = _param($args, 'lm_quality')     || $prefs->get('quality_default')
	                || 'all';

	my $view = Plugins::LibraryMapper::Data::browse(
		parent     => $path,
		time       => $time,
		quality    => $quality,
		order      => $order,
		groupOrder => $groupOrder,
		list       => $prefs->get('listLimit'),
		filter     => _param($args, 'filter'),
	);

	my $type = $view->{'type'} || 'level';
	my @items;

	if ($type eq 'level') {
		for my $row (@{ $view->{'rows'} }) {
			my $next = $path ? $path . '|' . $row->{'key'} : $row->{'key'};
			# the group of the albums that carry no genre is not a genre:
			# it is shown under a name that says it
			my $label = $row->{'unclassified'}
				? _label($client, 'PLUGIN_LIBRARYMAPPER_UNCLASSIFIED')
				: $row->{'key'};
			push @items, _levelItem($next, $label, $order, $groupOrder);
		}
	}
	elsif ($type eq 'albums') {
		for my $row (@{ $view->{'rows'} }) {
			# the path carries the album id: an album that belongs to several
			# artists is filed under each of them
			my $next = join('|', $row->{'vpath_genre'}, $row->{'vpath_artist'}, $row->{'album_id'});
			my $label = ($row->{'year'} ? $row->{'year'} . ' - ' : '') . $row->{'name'};
			push @items, _albumItem($next, $label, $row, $order, $groupOrder);
		}
	}
	elsif ($type eq 'tracks') {
		for my $row (@{ $view->{'rows'} }) {
			push @items, _trackItem($row);
		}
	}

	# The "items" action walks one level down.  The path of the level is
	# carried by the "lm_path" parameter, which every item sets itself.
	my %actions = (
		commonVariables => [ 'lm_path' => 'id' ],
		items => {
			command     => [ 'browselibrary', 'items' ],
			fixedParams => {
				mode           => MODE,
				lm_order       => $order,
				lm_group_order => $groupOrder,
			},
		},
	);

	$callback->({ items => \@items, actions => \%actions, sorted => 1 }, undef);
}

# a plain (not playable) entry of the virtual tree: a genre group or an
# artist within a genre group
sub _levelItem {
	my ($path, $label, $order, $groupOrder) = @_;
	my $enc = _encode($path);
	return {
		name        => $label,
		title       => $label,
		id          => $enc,
		type        => 'link',
		url         => \&feed,
		passthrough => [ { lm_path => $enc, lm_order => $order, lm_group_order => $groupOrder } ],
		itemActions => {
			items => _goAction($enc, $order, $groupOrder),
		},
	};
}

# an album: it can be played as such (Lyrion knows the album) and it can be
# opened to show its tracks
sub _albumItem {
	my ($path, $label, $row, $order, $groupOrder) = @_;
	my $enc = _encode($path);
	my %item = (
		name        => $label,
		title       => $label,
		id          => $enc,
		type        => 'playlist',
		playlist    => \&feed,
		url         => \&feed,
		passthrough => [ { lm_path => $enc, lm_order => $order, lm_group_order => $groupOrder } ],
		itemActions => {
			items  => _goAction($enc, $order, $groupOrder),
			play   => _playlistAction('load',   'album_id', $row->{'album_id'}),
			add    => _playlistAction('add',    'album_id', $row->{'album_id'}),
			insert => _playlistAction('insert', 'album_id', $row->{'album_id'}),
		},
	);
	# The cover art: the URL /music/<id>/cover wants the id of a *track*,
	# not the id of the album: the art of an album hangs on one of its
	# tracks (the "artwork" column of the albums table of Lyrion).
	my $art = $row->{'artwork_track_id'} || 0;
	if ($art) {
		$item{'artwork_track_id'} = $art;
		$item{'image'}            = 'music/' . $art . '/cover';
	}
	return \%item;
}

# one track of an album
sub _trackItem {
	my ($row) = @_;
	return {
		name  => $row->{'title'},
		title => $row->{'title'},
		id    => $row->{'track_id'},
		type  => 'audio',
		play  => $row->{'url'},
		url   => $row->{'url'},
		itemActions => {
			play   => _playlistAction('load',   'track_id', $row->{'track_id'}),
			add    => _playlistAction('add',    'track_id', $row->{'track_id'}),
			insert => _playlistAction('insert', 'track_id', $row->{'track_id'}),
		},
	};
}

# the action used to walk one level down: browselibrary items mode:librarymapper
# with the path carried in the lm_path parameter
sub _goAction {
	my ($enc, $order, $groupOrder) = @_;
	return {
		command     => [ 'browselibrary', 'items' ],
		fixedParams => {
			mode           => MODE,
			lm_path        => $enc,
			lm_order       => $order,
			lm_group_order => $groupOrder,
		},
	};
}

sub _playlistAction {
	my ($cmd, $tag, $id) = @_;
	return {
		command     => [ 'playlistcontrol' ],
		fixedParams => { cmd => $cmd, tag => $id },
	};
}

# ------------------------------------------------------------------ helpers

# Resolve the drill-down path.  Priority:
#   1. the item passthrough (raw path, used by the classic web UI)
#   2. the lm_path parameter (base64url encoded)
# Both carry the same encoded path, so the order does not matter much; the
# decoding is done in every case.
sub _path {
	my ($args, $pt) = @_;

	if ($pt && defined $pt->{'lm_path'} && $pt->{'lm_path'} ne '') {
		return _decode($pt->{'lm_path'});
	}

	if ($args && $args->{'params'} && defined $args->{'params'}->{'lm_path'}) {
		return _decode($args->{'params'}->{'lm_path'});
	}

	if ($pt && $pt->{'searchTags'}) {
		for my $tag (@{ $pt->{'searchTags'} }) {
			next unless $tag =~ /^lm_path:(.*)$/;
			return _decode($1);
		}
	}

	return '';
}

# Read one request parameter, wherever it is carried.
sub _param {
	my ($args, $name) = @_;
	return '' unless $args;
	return $args->{'params'}->{$name}
		if $args->{'params'} && defined $args->{'params'}->{$name};
	if (ref $args eq 'HASH' && defined $args->{$name}) {
		return $args->{$name};
	}
	return '';
}

# One label of the strings of the server, in the language of the client.
sub _label {
	my ($client, $token) = @_;
	my $text = '';
	if ($client) {
		eval { $text = clientString($client, $token) || ''; };
	}
	$text = '' unless defined $text && $text ne '';
	if ($text eq '') {
		eval { $text = string($token) || ''; };
	}
	return $text || $token;
}

sub _encode {
	my $s = shift;
	return '' unless defined $s && $s ne '';
	my $b = MIME::Base64::encode_base64($s, '');
	$b =~ tr{+/}{-_};
	$b =~ s/=+$//;
	return $b;
}

sub _decode {
	my $s = shift;
	return '' unless defined $s && $s ne '';
	return $s if $s =~ /\|/;                 # already a raw path
	$s =~ tr{-_}{+/};
	$s .= '=' x ((4 - length($s) % 4) % 4);
	my $d = eval { MIME::Base64::decode_base64($s) };
	return defined $d ? $d : '';
}

1;
