package Plugins::LibraryMapper::Mapping;

use strict;

use Plugins::LibraryMapper::Data;
use Plugins::LibraryMapper::SortKey;

# Keyword rule table: group -> patterns (case-insensitive, substring or full).
# The 10-20 group definitions here are seeds only - the user can edit
# groups and rules on the parameter page; proposals are suggestions.
my @RULES = (
	[ 'Jazz',       qr/\b(jazz|bebop|swing|fusion|bossa|scat)\b/i ],
	[ 'Classical',  qr/\b(classic|classic?al|classique|opera|baroque|romantic|sympho|chamber|concerto|renaissance)\b/i ],
	[ 'Rock',       qr/\b(rock|prog|punk|grunge|alternative|metal|indie|hard ?rock|psychedel)\b/i ],
	[ 'Pop',        qr/\b(pop|chanson|variety|variété|disco|synth-pop)\b/i ],
	[ 'Blues',      qr/\b(blues)\b/i ],
	[ 'Country',    qr/\b(country|bluegrass|honky|western)\b/i ],
	[ 'Hip-Hop',    qr/\b(hip.?hop|rap|trap|grime)\b/i ],
	[ 'Electronic', qr/\b(electro|techno|house|trance|ambient|dnb|drum.?n|jungle|synthwave|edm)\b/i ],
	[ 'Folk',       qr/\b(folk|celtic|world|ethnic|trad)\b/i ],
	[ 'Soul/R&B',   qr/\b(soul|r\.?&?b|funk|gospel|motown)\b/i ],
	[ 'Soundtrack', qr/\b(soundtrack|ost|score|bande originale|film music)\b/i ],
	[ 'Reggae',     qr/\b(reggae|dub|ska|dancehall)\b/i ],
	[ 'New Age',    qr/\b(new.?age|meditation|relaxation)\b/i ],
);

# Mapped group for a raw genre string (cache-side lookup), used by Data.pm.
sub mappedGroup {
	my $raw = shift || '';
	my $dbh = _dbh() or return '';
	# resolution order: approved group > proposed group > raw genre > Unsorted
	my ($group) = $dbh->selectrow_array(
		'SELECT CASE
			WHEN approved<>"" THEN approved
			WHEN proposed_group<>"" THEN proposed_group
			ELSE NULL END
		FROM genre_variants WHERE variant = ?', undef, _fold($raw));
	return $group if $group;
	my $trim = $raw;
	$trim =~ s/^\s+|\s+$//g;
	return $trim || 'Unsorted';
}

sub _fold { my $s = shift || ''; $s =~ s/^\s+|\s+$//g; return lc $s; }

# Propose groups for all unmapped variants (cheap: no Lyrion access needed).
sub repropose {
	my $dbh = _dbh() or return 0;
	my $changed = 0;
	for my $v (@{ _rows('SELECT variant, occurrences FROM genre_variants WHERE approved=""') }) {
		my ($variant, $occ) = @$v;
		my ($group, $rule) = _propose($variant);
		next unless $group;
		$dbh->do('UPDATE genre_variants SET proposed_group=? WHERE variant=?',
			undef, $group, $variant);
		$changed++;
	}
	return $changed;
}

sub _propose {
	my $variant = shift;
	for my $r (@RULES) {
		my ($group, $pat) = @$r;
		return ($group, 'keyword') if $variant =~ $pat;
	}
	return (undef, undef);
}

# Validation report shown on the parameter page.
sub validate {
	return { variants_total => 0, coverage_pct => 0, unmapped_top => [] } unless _dbh();
	my $rows = _rows('SELECT variant, occurrences, approved, approved_by FROM genre_variants');
	my $total = 0; my $mapped = 0;
	for my $r (@$rows) { $total += $r->[1]; $mapped += $r->[1] if $r->[2]; }
	return {
		variants_total  => scalar @$rows,
		coverage_pct    => $total ? sprintf('%.2f', 100 * $mapped / $total) : 0,
		unmapped_top    => _rows('SELECT variant, occurrences FROM genre_variants WHERE approved="" ORDER BY occurrences DESC LIMIT 15'),
	};
}

# --------------------------------------------------------------- artists

# Canonical display form of an artist name.
#   "john  lennon "           -> "John Lennon" (case kept from the source)
#   "Lennon, John"            -> "John Lennon"
#   "Miles Davis (feat. X)"   -> "Miles Davis"
#   "John Ronald Reuel Tolkien" -> "John Tolkien"  (style 'firstlast')
#   "AC/DC", "Earth, Wind & Fire" are left alone (bands, not persons)
sub normalizeArtistName {
	my ($raw, $style) = @_;
	return '' unless defined $raw && $raw ne '';
	my $s = $raw;
	$s =~ s/\x{00a0}/ /g;
	$s =~ s/[\(\[][^\)\]]*[\)\]]//g;               # drop (feat. ..) / [remaster]
	$s =~ s/\s+(?:feat\.?|ft\.?|featuring|with)\b.*$//i;
	$s =~ s/\s+/ /g;
	$s =~ s/^\s+|\s+$//g;
	$s =~ s/[.,;:_]+$//;
	# "Last, First" -> "First Last" (only for simple person-like names).
	# The captures must be copied out first: any further regex match would
	# reset $1/$2.
	if ($s =~ /^([^,]+),\s*([^,]+)$/) {
		my ($last, $first) = ($1, $2);
		if ($last !~ /[&+]/ && $first !~ /[&+|\/]/ && $first =~ /^\S+(\s\S+)?$/) {
			$s = "$first $last";
		}
	}
	if (($style || 'firstlast') eq 'firstlast') {
		my @tok = split /\s+/, $s;
		# an ensemble keeps its full name: "Miles Davis Quintet" must not
		# become "Miles Quintet"
		if (@tok > 2 && $s !~ /[&+|\/]/
		    && !Plugins::LibraryMapper::SortKey::hasDesignator($s)) {
			$s = "$tok[0] $tok[-1]";
		}
	}
	# a name written all in lower case is title cased ("miles davis" ->
	# "Miles Davis"); a name that already carries capitals is left alone
	# ("AC/DC", "Earth, Wind & Fire", "McDonald").
	if ($s !~ /[A-Z]/) {
		$s = join ' ', map { ucfirst lc $_ } split /\s+/, $s;
	}
	elsif ($s =~ /^[a-z]/) {
		$s = ucfirst $s;
	}
	return $s;
}

# ---------------------------------------------------------------- sort order

# The alphabetical order of the artists lives in its own module, so that it
# can be tested without a music server:
#   Plugins::LibraryMapper::SortKey::artistSortKey()
sub artistSortKey { return Plugins::LibraryMapper::SortKey::artistSortKey(@_); }
sub isBandName   { return Plugins::LibraryMapper::SortKey::isBandName(@_); }

# Resolve exactly one canonical artist per album so that the same album is
# never listed under several artist spellings.
#   $rows : [ { album => id, name => raw spelling, n => weight } ]
# Returns { album_id => { artist, raw, confidence, variants } }
# Split one artist credit into the individual artists it names.
#
#   "Claude Nougaro & David Lynx"  -> ("Claude Nougaro", "David Lynx")
#   "Earth, Wind & Fire"            -> ("Earth, Wind & Fire")   (band listing)
#   "Simon & Garfunkel"             -> ("Simon & Garfunkel")    (band, one word each)
#   "AC/DC"                         -> ("AC/DC")
#   "Miles Davis feat. John Coltrane" -> ("Miles Davis", "John Coltrane")
sub splitArtistNames {
	my ($raw) = @_;
	return () unless defined $raw && $raw ne '';
	my $s = $raw;
	$s =~ s/[\(\[][^\)\]]*[\)\]]//g;          # drop (feat. ..) / [remaster]
	$s =~ s/\s+/ /g;
	$s =~ s/^\s+|\s+$//g;
	return () unless $s ne '';

	# "Last, First" is a single person
	if (_isLastFirst($s)) {
		my ($last, $first) = split /,\s*/, $s, 2;
		return ("$first $last");
	}

	# a comma means a band listing ("Earth, Wind & Fire") - keep it whole
	return ($s) if $s =~ /,/;

	my @parts = split /\s*(?:&|\+|feat\.?|ft\.?|featuring|with|et|vs\.?)\s*/i, $s;
	@parts = grep { /\S/ } @parts;
	return ($s) unless @parts > 1;

	# only split when every part looks like a personal name (at least two
	# words): "Claude Nougaro & David Lynx" splits, "Simon & Garfunkel" does not
	for my $p (@parts) {
		my @w = split /\s+/, $p;
		return ($s) if @w < 2;
	}
	return @parts;
}

sub _isLastFirst {
	my $s = shift;
	return 0 unless $s =~ /^([^,]+),\s*([^,]+)$/;
	my ($last, $first) = ($1, $2);
	return 0 if $last =~ /[&+]/ || $first =~ /[&+|\/]/;
	return 0 unless $first =~ /^\S+(\s\S+)?$/;
	return 1;
}

# ------------------------------------------------------------ trusted artists

# A trusted name is an artist that is always ONE artist:
#   * the credit is never split ("Simon & Garfunkel" stays one entry),
#   * the albums credited to it are filed under it alone - no guest and no
#     other collaborator is listed next to it.
# The user uploads the list of such names on the parameter page.

# Matching keys of one artist name: the raw form and its normalized form.
#   "Miles Davis"  ->  "miles davis", "miles davis"
#   "Davis, Miles" ->  "davis, miles", "miles davis"
#   "Miles Davis feat. John Coltrane" -> "miles davis feat. john coltrane", "miles davis"
sub artistMatchKeys {
	my ($raw) = @_;
	my @keys;
	my $s = defined $raw ? $raw : '';
	$s =~ s/\x{00a0}/ /g;
	$s =~ s/\s+/ /g;
	$s =~ s/^\s+|\s+$//g;
	push @keys, lc $s if $s ne '';
	my $norm = normalizeArtistName($s, 'full');
	if (defined $norm && $norm ne '') {
		$norm =~ s/\s+/ /g;
		$norm =~ s/^\s+|\s+$//g;
		push @keys, lc $norm if $norm ne '' && !grep { $_ eq lc $norm } @keys;
	}
	return @keys;
}

# { matching key => the trusted name as the user typed it }
sub trustedKeyMap {
	my ($names) = @_;
	my %map;
	for my $n (@{ $names || [] }) {
		next unless defined $n;
		my $t = $n;
		$t =~ s/^\s+|\s+$//g;
		next unless $t ne '';
		for my $k (artistMatchKeys($t)) { $map{$k} = $t; }
	}
	return \%map;
}

# the trusted list kept in the plugin database
sub _trustedKeyMap {
	my $names = eval { Plugins::LibraryMapper::Data::trustedNames() };
	return trustedKeyMap($names);
}

# the trusted entry a credit matches, if any
sub _trustedMatch {
	my ($raw, $trusted) = @_;
	return undef unless $trusted && %$trusted;
	for my $k (artistMatchKeys($raw)) {
		return $trusted->{$k} if exists $trusted->{$k};
	}
	return undef;
}

# Resolve the artists of every album.
#   $rows : [ { album => id, name => raw spelling, n => weight } ]
# Returns { album_id => {
#              artist  => primary artist (the one the album is filed under),
#              artists => [ { name, weight, confidence } ],   # all entities
#              raw     => the most frequent original spelling,
#              confidence, variants } }
#
# An album is filed under every artist entity it names, so a collaboration
# ("Claude Nougaro & David Lynx") shows up under both artists.  Spellings of
# the same entity are merged into one canonical name, so the same album never
# appears under "Miles Davis", "miles davis" and "Davis, Miles".
sub resolveAlbumArtists {
	my ($rows, $style, $trustedNames) = @_;
	$style ||= 'firstlast';
	my %byAlbum;
	for my $r (@$rows) {
		next unless defined $r->{'album'};
		push @{ $byAlbum{ $r->{'album'} } }, $r;
	}

	# the user corrections (approved canonical names) win over the heuristic
	my $canon = _artistCanonicalMap();

	# the trusted names: one single artist, never split
	my $trusted = defined $trustedNames ? trustedKeyMap($trustedNames) : _trustedKeyMap();

	# global weight of each canonical name across the whole library
	my %global;
	for my $album (keys %byAlbum) {
		for my $r (@{ $byAlbum{$album} }) {
			for my $pair (_entitiesFor($r->{'name'}, $style, $canon, $trusted)) {
				$global{ $pair->[0] } += ($r->{'n'} || 1);
			}
		}
	}

	my %out;
	for my $album (keys %byAlbum) {
		my (%score, %raws, %trustedScore);
		for my $r (@{ $byAlbum{$album} }) {
			my $w = $r->{'n'} || 1;
			for my $pair (_entitiesFor($r->{'name'}, $style, $canon, $trusted)) {
				my ($entity, $isTrusted) = @$pair;
				$score{$entity} += $w;
				$raws{$entity}{ $r->{'name'} } += $w;
				$trustedScore{$entity} += $w if $isTrusted;
			}
		}
		next unless %score;

		# a trusted artist is the album artist of that album: it is listed
		# alone, no guest and no other collaborator next to it
		if (%trustedScore) {
			for my $entity (keys %score) {
				delete $score{$entity} unless $trustedScore{$entity};
			}
		}

		# the main artist: most credited, ties broken by library-wide weight
		my ($best) = sort { $score{$b} <=> $score{$a}
			|| $global{$b} <=> $global{$a}
			|| $a cmp $b } keys %score;
		my ($bestRaw) = sort { $raws{$best}{$b} <=> $raws{$best}{$a} || $a cmp $b } keys %{ $raws{$best} };

		# every artist the album really belongs to: a guest on one track out of
		# twelve does not make the album a collaboration
		my $max = $score{$best};
		my @artists;
		for my $n (sort { $score{$b} <=> $score{$a} || $a cmp $b } keys %score) {
			next if $score{$n} < 0.2 * $max;
			push @artists, {
				name       => $n,
				weight     => $score{$n},
				confidence => $max ? sprintf('%.2f', 100 * $score{$n} / $max) : 0,
			};
		}
		my $total = 0;
		$total += $score{$_} for keys %score;

		$out{$album} = {
			artist     => $best,
			artists    => \@artists,
			raw        => $bestRaw,
			confidence => $total ? sprintf('%.2f', 100 * $score{$best} / $total) : 0,
			variants   => scalar keys %score,
			trusted    => (scalar keys %trustedScore) ? 1 : 0,
		};
	}
	return \%out;
}

# The artists named by one credit.
# Returns a list of [ name, isTrusted ] pairs.
#   a trusted credit           -> one single artist, never split
#   any other credit           -> the names the heuristic finds
sub _entitiesFor {
	my ($raw, $style, $canon, $trusted) = @_;
	return () unless defined $raw;
	my $t = _trustedMatch($raw, $trusted);
	if ($t) {
		# the trusted name as the user typed it, with "Last, First" and the
		# case normalized but nothing else touched
		my $display = normalizeArtistName($t, 'full');
		$display = $t unless defined $display && $display ne '';
		return ([ $display, 1 ]);
	}
	my @out;
	for my $entity (splitArtistNames($raw)) {
		my $n = _canonical($entity, $style, $canon);
		push @out, [ $n, 0 ] if defined $n && $n ne '';
	}
	return @out;
}

# canonical name of one raw spelling, honouring the user correction
sub _canonical {
	my ($raw, $style, $canon) = @_;
	my $c = $canon->{ _fold($raw) };
	return $c if defined $c && $c ne '';
	return normalizeArtistName($raw, $style);
}

# preload the canonical/approved names of every known spelling (one query)
sub _artistCanonicalMap {
	my %map;
	for my $r (@{ _rows('SELECT variant, canonical, approved FROM artist_variants') }) {
		my $v = $r->[0];
		my $c = (defined $r->[2] && $r->[2] ne '') ? $r->[2]
		      : ((defined $r->[1] && $r->[1] ne '') ? $r->[1] : '');
		$map{$v} = $c;
	}
	return \%map;
}

# Canonical name of one raw spelling, honouring a user approval.
sub artistCanonical {
	my ($raw, $style) = @_;
	my $variant = _fold($raw);
	my $dbh = _dbh();
	if ($dbh) {
		my ($approved) = $dbh->selectrow_array(
			'SELECT approved FROM artist_variants WHERE variant=?', undef, $variant);
		return $approved if $approved;
		my ($canonical) = $dbh->selectrow_array(
			'SELECT canonical FROM artist_variants WHERE variant=?', undef, $variant);
		return $canonical if $canonical;
	}
	return normalizeArtistName($raw, $style);
}

# --------------------------------------------------------- contributor roles
#
# The library credits people in several roles: artist, composer, conductor,
# band, album artist, track artist.  Each role has its own canonical name:
# "Bach" is not the same string when it is credited as the composer.

# The string token of a role number.
my %ROLE_TOKEN = (
	1 => 'PLUGIN_LIBRARYMAPPER_ROLE_ARTIST',
	2 => 'PLUGIN_LIBRARYMAPPER_ROLE_COMPOSER',
	3 => 'PLUGIN_LIBRARYMAPPER_ROLE_CONDUCTOR',
	4 => 'PLUGIN_LIBRARYMAPPER_ROLE_BAND',
	5 => 'PLUGIN_LIBRARYMAPPER_ROLE_ALBUMARTIST',
	6 => 'PLUGIN_LIBRARYMAPPER_ROLE_TRACKARTIST',
);
sub roleToken { my $r = shift || 0; return $ROLE_TOKEN{ 0 + $r } || ''; }

# The roles a name can be credited under, most specific first.
sub roleList {
	return [ sort { $a <=> $b } keys %ROLE_TOKEN ];
}

# The canonical name of a contributor in one role.
#   the user mapping wins, then the artist spelling table (artists only),
#   then the automatic normalization.
sub roleCanonical {
	my ($raw, $role, $style) = @_;
	return '' unless defined $raw && $raw ne '';
	$role = 1 unless $role && $role =~ /^\d+$/;
	my $variant = _fold($raw);
	my $dbh = _dbh();
	if ($dbh) {
		my ($mapped) = $dbh->selectrow_array(
			'SELECT canonical FROM contributor_mappings WHERE role=? AND variant=?',
			undef, $role, $variant);
		return $mapped if defined $mapped && $mapped ne '';
		if ($role == 1) {
			my ($approved) = $dbh->selectrow_array(
				'SELECT approved FROM artist_variants WHERE variant=?', undef, $variant);
			return $approved if defined $approved && $approved ne '';
			my ($canonical) = $dbh->selectrow_array(
				'SELECT canonical FROM artist_variants WHERE variant=?', undef, $variant);
			return $canonical if defined $canonical && $canonical ne '';
		}
	}
	# a composer or a conductor keeps every part of the name: "Johann
	# Sebastian Bach" must not become "Johann Bach"
	my $st = ($role == 2 || $role == 3) ? 'full' : ($style || 'firstlast');
	return normalizeArtistName($raw, $st);
}

# The user mappings of one role: { variant => canonical }.
sub contributorMappings {
	my ($role) = @_;
	my %map;
	for my $r (@{ _rows('SELECT variant, canonical FROM contributor_mappings WHERE role=?', $role || 1) }) {
		$map{ $r->[0] } = $r->[1];
	}
	return \%map;
}

# Export the full mapping as downloadable JSON.
#
# The file carries the proposals of the keyword rules too, not only the
# mappings the user approved: the exported file is the working material the
# user edits and uploads back.  A proposal that the user did not touch stays
# a proposal (""), an approved one stays approved.
sub exportMapping {
	return undef unless _dbh();
	my $data = {
		format     => 'librarymapper-mapping',
		version    => 4,
		generated  => scalar localtime(),
		groups     => _rows('SELECT name, sort_order, is_default FROM genre_groups'),
		# [ variant, proposed_group, approved, approved_by ]
		variants   => _rows('SELECT variant, proposed_group, approved, approved_by FROM genre_variants'),
		# [ variant, canonical, approved ]
		artists    => _rows('SELECT variant, canonical, approved FROM artist_variants'),
		# [ role, variant, canonical ]
		contributors => _rows('SELECT role, variant, canonical FROM contributor_mappings'),
		trusted    => _rows('SELECT name FROM trusted_artists'),
	};
	return _json($data);
}

# The mapping as a plain text list: one line per entry.
#
#   artist  miles davis            => Miles Davis
#   composer bach, johann sebastian => Johann Sebastian Bach
#   genre   jazz                   => Jazz
#
# The type may be left out (artist is then assumed) and the "=>" may be
# replaced by "|".  A line without a value removes the entry.
#
# This is the format the user edits in a text editor and pastes back into
# the parameter page: it is far easier to work with than the JSON file.
sub exportList {
	return '' unless _dbh();
	my @out;
	for my $r (@{ _rows('SELECT variant, approved, canonical FROM artist_variants
	                     WHERE approved<>"" OR canonical<>""') }) {
		my ($variant, $approved, $canonical) = @$r;
		my $value = (defined $approved && $approved ne '') ? $approved : $canonical;
		next unless defined $value && $value ne '';
		push @out, "artist  $variant => $value";
	}
	for my $r (@{ _rows('SELECT role, variant, canonical FROM contributor_mappings
	                     WHERE canonical<>"" ORDER BY role, variant') }) {
		my ($role, $variant, $canonical) = @$r;
		my $type = _roleType($role);
		next unless $type;
		push @out, "$type  $variant => $canonical";
	}
	for my $r (@{ _rows('SELECT variant, approved FROM genre_variants WHERE approved<>"" ORDER BY variant') }) {
		push @out, "genre   $r->[0] => $r->[1]";
	}
	return join("\n", @out) . (@out ? "\n" : '');
}

# The name of a role in the list format ('' for an unknown role).
sub _roleType {
	my $role = shift || 0;
	return 'artist'      if $role == 1;
	return 'composer'    if $role == 2;
	return 'conductor'   if $role == 3;
	return 'band'        if $role == 4;
	return 'albumartist' if $role == 5;
	return 'trackartist' if $role == 6;
	return '';
}

# The role number of a type in the list format (1 = artist).
sub _typeRole {
	my $type = shift || '';
	return 1 unless $type ne '';
	return 1 if $type eq 'artist';
	return 2 if $type eq 'composer';
	return 3 if $type eq 'conductor';
	return 4 if $type eq 'band';
	return 5 if $type eq 'albumartist';
	return 6 if $type eq 'trackartist';
	return 0;
}

# Read a list and apply it to the current mapping.
#   $mode = 'modify'  - add or change the listed entries
#   $mode = 'delete'  - remove the listed entries
# Returns { added, changed, removed, errors => [ ... ] }.
sub importList {
	my ($text, $mode) = @_;
	my $dbh = _dbh() or return { added => 0, changed => 0, removed => 0, errors => ['no database'] };
	$mode = 'modify' unless $mode && $mode eq 'delete';

	my $stats = { added => 0, changed => 0, removed => 0, errors => [] };
	for my $line (split /\r?\n/, (defined $text ? $text : '')) {
		$line =~ s/^\s+|\s+$//g;
		next if $line eq '';
		next if $line =~ /^[#;]/;                  # a comment
		my ($type, $key, $value);
		if ($line =~ /^([A-Za-z]+)\s+(.*)$/ && _typeRole(lc $1)) {
			$type = lc $1;
			$line = $2;
		}
		if ($line =~ /^([^=>|]*?)\s*(?:=>|\|)\s*(.*)$/) {
			($key, $value) = ($1, $2);
		}
		else {
			$key = $line;
			$value = '';
		}
		$key =~ s/^\s+|\s+$//g;
		$value =~ s/^\s+|\s+$//g;
		next if $key eq '';

		my $role = _typeRole($type);
		if ($role == 0) {
			push @{ $stats->{'errors'} }, "unknown type '$type' for '$key'";
			next;
		}

		if ($mode eq 'delete') {
			$stats->{'removed'} += _removeEntry($role, $key);
			next;
		}

		# an empty value in modify mode removes the entry
		if ($value eq '') {
			$stats->{'removed'} += _removeEntry($role, $key);
			next;
		}

		if ($role == 1) {
			# the artist spellings: the approved name is what the tree shows
			my $variant = _fold($key);
			my ($old) = $dbh->selectrow_array(
				'SELECT approved FROM artist_variants WHERE variant=?', undef, $variant);
			if (!defined $old) {
				$dbh->do('INSERT INTO artist_variants(variant, canonical, occurrences, approved) VALUES (?,?,?,?)',
					undef, $variant, $value, 0, $value);
				$stats->{'added'}++;
			}
			else {
				$dbh->do('UPDATE artist_variants SET approved=? WHERE variant=?', undef, $value, $variant);
				$stats->{'changed'}++;
			}
		}
		elsif ($role == 5 || $role == 6 || $role == 4) {
			# an album artist, a track artist or a band is an artist spelling
			$dbh->do('INSERT OR REPLACE INTO contributor_mappings(role, variant, canonical, updated_at) VALUES (?,?,?,?)',
				undef, $role, _fold($key), $value, time());
			$stats->{'changed'}++;
		}
		else {
			$dbh->do('INSERT OR REPLACE INTO contributor_mappings(role, variant, canonical, updated_at) VALUES (?,?,?,?)',
				undef, $role, _fold($key), $value, time());
			$stats->{'changed'}++;
		}
	}
	return $stats;
}

# Remove one entry from the mapping.  Returns the number of rows removed.
sub _removeEntry {
	my ($role, $key) = @_;
	my $dbh = _dbh() or return 0;
	my $n = 0;
	if ($role == 1) {
		$n += $dbh->do('UPDATE artist_variants SET approved="" WHERE variant=?', undef, _fold($key));
		$n += $dbh->do('DELETE FROM contributor_mappings WHERE role=1 AND variant=?', undef, _fold($key));
	}
	elsif ($role == 5) {
		$n += $dbh->do('UPDATE artist_variants SET approved="" WHERE variant=?', undef, _fold($key));
		$n += $dbh->do('DELETE FROM contributor_mappings WHERE role IN (4,5,6) AND variant=?', undef, _fold($key));
	}
	else {
		$n += $dbh->do('DELETE FROM contributor_mappings WHERE role=? AND variant=?', undef, $role, _fold($key));
	}
	return $n;
}

# Import a previously exported (or user-edited) mapping file.
#
# Both the old 3-column variant rows and the new 4-column ones are read.
sub importMapping {
	my ($text) = @_;
	my $dbh = _dbh() or return 0;
	my $data = _fromJson($text) or return 0;
	return 0 unless ($data->{format} // '') eq 'librarymapper-mapping';
	$dbh->begin_work;
	for my $g (@{ $data->{groups} || [] }) {
		$dbh->do('INSERT OR IGNORE INTO genre_groups(name, sort_order, is_default) VALUES (?,?,?)',
			undef, @$g);
	}
	for my $v (@{ $data->{variants} || [] }) {
		# [ variant, approved, approved_by ]      (version 3)
		# [ variant, proposed, approved, approved_by ] (version 4)
		my ($variant, $approved, $approved_by);
		if (@$v >= 4) {
			($variant, my $proposed, $approved, $approved_by) = @$v;
			$dbh->do('UPDATE genre_variants SET proposed_group=?, approved=?, approved_by=? WHERE variant=?',
				undef, $proposed, (defined $approved ? $approved : ''),
				(defined $approved_by ? $approved_by : 'import'), $variant);
		}
		else {
			($variant, $approved, $approved_by) = @$v;
			$dbh->do('UPDATE genre_variants SET approved=?, approved_by=? WHERE variant=?',
				undef, (defined $approved ? $approved : ''),
				(defined $approved_by ? $approved_by : 'import'), $variant);
		}
	}
	for my $a (@{ $data->{artists} || [] }) {
		# [ variant, canonical, approved ]
		my ($variant, $canonical, $approved) = @$a;
		$dbh->do('UPDATE artist_variants SET canonical=?, approved=? WHERE variant=?',
			undef, $canonical, (defined $approved ? $approved : ''), $variant);
	}
	for my $c (@{ $data->{contributors} || [] }) {
		# [ role, variant, canonical ]
		my ($role, $variant, $canonical) = @$c;
		next unless defined $variant && $variant ne '';
		$dbh->do('INSERT OR REPLACE INTO contributor_mappings(role, variant, canonical, updated_at) VALUES (?,?,?,?)',
			undef, ($role || 1), $variant, (defined $canonical ? $canonical : ''), time());
	}
	for my $t (@{ $data->{trusted} || [] }) {
		# [ name ]
		my ($name) = @$t;
		next unless defined $name && $name ne '';
		$dbh->do('INSERT OR REPLACE INTO trusted_artists(name, added_at) VALUES (?,?)',
			undef, $name, time());
	}
	$dbh->commit;
	return 1;
}

# --- internal -------------------------------------------------------------

sub _rows {
	my ($sql, @bind) = @_;
	my $dbh = _dbh() or return [];
	return $dbh->selectall_arrayref($sql, undef, @bind) || [];
}
sub _dbh { return Plugins::LibraryMapper::Data::dbh(); }
sub _json { return Plugins::LibraryMapper::Data::to_json(@_); }
sub _fromJson { return Plugins::LibraryMapper::Data::from_json(@_); }

1;
