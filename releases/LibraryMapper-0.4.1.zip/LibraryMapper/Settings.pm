package Plugins::LibraryMapper::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Encode;

use Slim::Utils::Log qw(logger logError logWarning);
use Slim::Utils::Prefs;

use Plugins::LibraryMapper::Data;
use Plugins::LibraryMapper::Mapping;
use Plugins::LibraryMapper::Upload;

my $log   = logger('plugin.librarymapper');
my $prefs = preferences('plugin.librarymapper');

sub name { 'PLUGIN_LIBRARYMAPPER' }
sub page { 'plugins/LibraryMapper/settings/basic.html' }

sub handler {
	my ($class, $client, $params, $callback) = @_;

	# never let an error take the whole page (or the server) down
	my $ok = eval { $class->_handle($client, $params, $callback); 1 };
	unless ($ok) {
		logError("LibraryMapper settings: " . $@);
		$params->{'lmError'} = 1;
	}

	$params->{'status'}        = Plugins::LibraryMapper::Data::status();
	$params->{'groups'}        = Plugins::LibraryMapper::Data::getGenreGroups();
	$params->{'variants'}      = Plugins::LibraryMapper::Data::topVariants(25);
	$params->{'artistVariants'} = Plugins::LibraryMapper::Data::topArtistVariants(25);
	$params->{'ambiguous'}     = Plugins::LibraryMapper::Data::ambiguousAlbums(15);
	$params->{'trusted'}       = Plugins::LibraryMapper::Data::trustedArtists();

	openReview($params);
	$params->{'page'} = $class->page;

	return Slim::Web::HTTP::filltemplatefile($params->{'page'}, $params);
}

sub _handle {
	my ($class, $client, $params, $callback) = @_;

	# A file upload arrives as a multipart body.  Lyrion does not parse those
	# itself (it only reads "key=value" pairs), so we parse the raw body and
	# merge its fields into the parameters.
	my $upload;
	my $content = $params->{'content'};
	if (defined $content && length $content && length $content < 8 * 1024 * 1024
		&& index($content, 'Content-Disposition: form-data') >= 0) {
		$upload = Plugins::LibraryMapper::Upload::parse($content);
		if ($upload) {
			for my $k (keys %{ $upload->{'fields'} }) {
				$params->{$k} = $upload->{'fields'}->{$k} unless defined $params->{$k};
			}
		}
	}

	# --- initialization phase ------------------------------------------------
	if ($params->{'action'} && $params->{'action'} eq 'init') {
		my $stats = Plugins::LibraryMapper::Data::runInitialization();
		$params->{'initResult'} = $stats;
	}
	# --- upload mapping file (JSON pasted into the textarea) -----------------
	if ($params->{'action'} && $params->{'action'} eq 'upload') {
		my $text = $params->{'mappingInput'};
		$params->{'uploadResult'} = (defined $text
			&& Plugins::LibraryMapper::Mapping::importMapping($text)) ? 'ok' : 'fail';
	}
	# --- the mapping list: add / modify / remove entries --------------------
	if ($params->{'action'} && $params->{'action'} eq 'listModify') {
		my $stats = Plugins::LibraryMapper::Mapping::importList($params->{'mappingInput'}, 'modify');
		$params->{'listStats'} = $stats;
		$params->{'listResult'} = 'modified';
		# the tree follows the mapping
		Plugins::LibraryMapper::Data::reresolveArtists();
	}
	if ($params->{'action'} && $params->{'action'} eq 'listDelete') {
		my $stats = Plugins::LibraryMapper::Mapping::importList($params->{'mappingInput'}, 'delete');
		$params->{'listStats'} = $stats;
		$params->{'listResult'} = 'deleted';
		Plugins::LibraryMapper::Data::reresolveArtists();
	}
	# --- repropose from rules -------------------------------------------------
	if ($params->{'action'} && $params->{'action'} eq 'repropose') {
		Plugins::LibraryMapper::Mapping::repropose();
	}

	my $artistVariants = Plugins::LibraryMapper::Data::topArtistVariants(25);

	# --- approve canonical artist names --------------------------------------
	if ($params->{'action'} && $params->{'action'} eq 'artistSave') {
		my $n = 0;
		for my $v (@$artistVariants) {
			my $new = $params->{"canonical_$n"};
			$n++;
			next unless defined $new;
			$new =~ s/^\s+|\s+$//g;
			Plugins::LibraryMapper::Data::setArtistCanonical($v->{'variant'}, $new);
		}
		$params->{'artistResult'} = 'ok';
		$artistVariants = Plugins::LibraryMapper::Data::topArtistVariants(25);
		# the corrections change the tree: re-resolve from the cached credits
		Plugins::LibraryMapper::Data::reresolveArtists();
	}

	# --- trusted artists: names that are always one single album artist ------
	if (($params->{'action'} && $params->{'action'} eq 'trustedImport')
		|| ($params->{'trustedImport'} && !$params->{'trustedRemove'})) {
		my @names = _parseNameList($params->{'trustedNames'});
		if ($upload && $upload->{'files'}->{'trustedFile'}) {
			push @names, _parseNameList(_decode($upload->{'files'}->{'trustedFile'}->{'content'}));
		}
		my $replace = (($params->{'trustedMode'} || '') eq 'replace') ? 1 : 0;
		my $n = Plugins::LibraryMapper::Data::addTrustedArtists(\@names, $replace);
		$params->{'trustedResult'} = $n ? 'ok' : 'fail';
		$params->{'trustedCount'} = $n;
		# apply the new list to the tree right away
		if ($n) { Plugins::LibraryMapper::Data::reresolveArtists(); }
	}
	if ($params->{'action'} && $params->{'action'} eq 'trustedRemove') {
		Plugins::LibraryMapper::Data::removeTrustedArtist($params->{'trustedName'});
		$params->{'trustedResult'} = 'removed';
		Plugins::LibraryMapper::Data::reresolveArtists();
	}

	# --- contributor search (artist / composer / conductor) -----------------
	# The pattern is a regular expression.  The result is an ordered and
	# numbered list; the number is the reference of the row.
	#
	# The last result is kept in the database, so it survives the round trip
	# of a save: the page always shows the list the numbers belong to.
	$params->{'searchRows'} = Plugins::LibraryMapper::Data::lastQueryResults();
	if ($params->{'action'} && $params->{'action'} eq 'search') {
		# a regular expression may contain "&", "+" or "#": Lyrion splits the
		# body on those, so the pattern is read from the raw body
		my $pattern = _rawParam($content, 'pattern');
		$pattern = $params->{'pattern'} unless defined $pattern;
		my $role    = $params->{'role'};
		my $case    = $params->{'caseSensitive'};
		my $res = Plugins::LibraryMapper::Data::queryContributors($pattern, $role, {
			caseSensitive => ($case ? 1 : 0),
		});
		$params->{'searchResult'} = $res;
		$params->{'searchRows'}   = $res->{'rows'};
		$params->{'searchError'}  = $res->{'error'};
		$params->{'searchPattern'} = $pattern;
		$params->{'searchRole'}   = $role;
	}
	# --- apply the mappings of the result list -----------------------------
	if ($params->{'action'} && $params->{'action'} eq 'mapSave') {
		my $n = 0;
		for my $row (@{ $params->{'searchRows'} || [] }) {
			my $nr = $row->{'nr'};
			my $value = $params->{"map_$nr"};
			next unless defined $value;
			$value =~ s/^\s+|\s+$//g;
			# an unchanged cell is not a correction
			my $current = $row->{'mapping'};
			next if defined $current && $current eq $value;
			Plugins::LibraryMapper::Data::setContributorMapping($nr, $value);
			$n++;
		}
		$params->{'mapSaved'} = $n;
		# the cells now show the new mapping
		$params->{'searchRows'} = Plugins::LibraryMapper::Data::lastQueryResults();
	}

	# --- list limit preference ----------------------------------------------
	if ($params->{'saveSettings'} && defined $params->{'pref_listLimit'}) {
		my $lim = $params->{'pref_listLimit'};
		if ($lim =~ /^\d+$/ && $lim > 0) {
			$prefs->set('listLimit', 0 + $lim);
		}
	}
	# --- default filters ------------------------------------------------------
	if ($params->{'saveSettings'}) {
		for my $k (qw(time_default quality_default order_default group_order artistNameStyle)) {
			my $pref = 'pref_' . $k;
			next unless defined $params->{$pref};
			$prefs->set($k, $params->{$pref});
		}
		# the albums that carry no genre are not shown: the box is only
		# there when it is ticked
		$prefs->set('showUnclassified', $params->{'pref_showUnclassified'} ? 1 : 0);
	}
	$params->{'listLimit'} = $prefs->get('listLimit') || 100;
	$params->{'timeDefault'}    = $prefs->get('time_default')    || 'all';
	$params->{'qualityDefault'} = $prefs->get('quality_default') || 'all';
	$params->{'orderDefault'}   = $prefs->get('order_default')   || 'alpha';
	$params->{'groupOrder'}     = $prefs->get('group_order')     || 'alpha';
	$params->{'artistStyle'}    = $prefs->get('artistNameStyle') || 'firstlast';
	$params->{'showUnclassified'} = $prefs->get('showUnclassified') ? 1 : 0;
}

sub openReview {
	my $params = shift;
	my $valid  = Plugins::LibraryMapper::Mapping::validate();
	$params->{'validation'} = $valid;
}

# One parameter read from the raw request body.  Lyrion splits the body on
# "&", so a value that contains one is truncated: the raw body still has it
# complete (url encoded).
sub _rawParam {
	my ($body, $key) = @_;
	return undef unless defined $body && defined $key;
	return undef unless $body =~ /(?:\A|&)\Q$key\E=([^&]*)/;
	my $value = $1;
	$value =~ s/\+/ /g;
	$value =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge;
	return $value;
}

# One artist name per line; empty lines and #-comments are ignored.
sub _parseNameList {
	my ($text) = @_;
	return () unless defined $text;
	$text =~ s/^\x{FEFF}//;
	$text =~ s/^\xef\xbb\xbf//;
	my @out;
	for my $line (split /\r?\n/, $text) {
		$line =~ s/^\s+|\s+$//g;
		next if $line eq '';
		next if $line =~ /^#/;
		push @out, $line;
	}
	return @out;
}

# Uploaded files arrive as bytes: turn them into characters when possible.
sub _decode {
	my ($bytes) = @_;
	return '' unless defined $bytes;
	my $text = eval { Encode::decode('UTF-8', $bytes, Encode::FB_CROAK) };
	return defined $text ? $text : $bytes;
}

1;
